// Lingua Prototype 1 uses small scene switches and one shared state object.
const scenes = {
  login: document.getElementById("loginScene"),
  createCharacter: document.getElementById("createCharacterScene"),
  title: document.getElementById("titleScene"),
  story: document.getElementById("storyScene"),
  battle: document.getElementById("battleScene"),
  victory: document.getElementById("victoryScene")
};

const mainStoryDialogue = [
  {
    speaker: "ผู้พเนจร",
    text: "\"ที่นี่...คือที่ไหนกัน? ทำไมตัวอักษรถึงลอยอยู่เต็มไปหมด?\""
  },
  {
    speaker: "มาสเตอร์เวรีออน",
    text: "\"เจ้าตื่นขึ้นแล้ว ผู้พเนจร โลกแห่งนี้มีชื่อว่า Lingua โลกที่ถ้อยคำ ความหมาย และเวลาเชื่อมโยงกันด้วยพลังแกรมมาเรีย\""
  },
  {
    speaker: "มาสเตอร์เวรีออน",
    text: "\"แต่หลังจาก The Great Error แกนกลางของภาษาได้แตกออก ความหมายของสิ่งต่าง ๆ จึงเริ่มเลือนหาย\""
  },
  {
    speaker: "ผู้พเนจร",
    text: "\"ความหมาย...เลือนหาย? หมายความว่าสิ่งต่าง ๆ จะหายไปด้วยหรือ?\""
  },
  {
    speaker: "มาสเตอร์เวรีออน",
    text: "\"ใช่ ก่อนที่สิ่งใดจะมีตัวตน สิ่งนั้นต้องมีชื่อเสียก่อน คำที่ใช้เรียกคน สัตว์ สิ่งของ หรือสถานที่ เราเรียกว่า คำนาม\""
  },
  {
    speaker: "มาสเตอร์เวรีออน",
    text: "\"จงมองรอบตัวเจ้า หนังสือ ประตู แมว หรือโรงเรียน ล้วนมีชื่อ และชื่อนั้นคือจุดเริ่มต้นของความหมาย\""
  },
  {
    speaker: "ผู้พเนจร",
    text: "\"ถ้าฉันช่วยเรียกชื่อของสิ่งเหล่านั้นกลับมาได้ โลกนี้ก็จะฟื้นคืนใช่ไหม?\""
  },
  {
    speaker: "มาสเตอร์เวรีออน",
    text: "\"ถูกต้อง นี่คือก้าวแรกของเจ้า จงใช้พลังแกรมมาเรียเพื่อฟื้นคืนชื่อของสิ่งต่าง ๆ\""
  }
];

const prologueDialogue = [
  {
    speaker: "ระบบบรรยาย",
    text: "\"นานมาแล้ว โลก Lingua เคยมีแกนกลางของภาษาเพียงหนึ่งเดียว Grammar Core คือพลังที่เชื่อมถ้อยคำ ความหมาย และเวลาเข้าด้วยกัน\""
  },
  {
    speaker: "ระบบบรรยาย",
    text: "\"แต่ในวันที่ถูกเรียกว่า The Great Error แกนกลางนั้นแตกออกเป็นเศษเสี้ยว ปัจจุบัน อดีต และอนาคตเริ่มแยกจากกัน\""
  },
  {
    speaker: "ระบบบรรยาย",
    text: "\"เมื่อชื่อของสิ่งต่าง ๆ เริ่มเลือนหาย โลกทั้งใบจึงค่อย ๆ สูญเสียความหมาย\""
  },
  {
    speaker: "ระบบบรรยาย",
    text: "\"ท่ามกลางแสงสุดท้ายของแกรมมาเรีย เด็กคนหนึ่งได้ลืมตาขึ้นในหอคอยแห่ง Unity\""
  }
];

const namingDialogue = [
  {
    speaker: "มาสเตอร์เวรีออน",
    text: "\"เจ้าตื่นขึ้นท่ามกลางเศษถ้อยคำที่แตกสลาย... แต่ก่อนที่เจ้าจะก้าวไปข้างหน้า เจ้าต้องมีชื่อเสียก่อน\""
  },
  {
    speaker: "มาสเตอร์เวรีออน",
    text: "\"บอกข้ามาเถิด ผู้พเนจร เจ้าจะให้โลก Lingua เรียกเจ้าว่าอะไร?\"",
    requiresName: true
  }
];

const nounWords = [
  { word: "teacher", noun: true },
  { word: "cat", noun: true },
  { word: "book", noun: true },
  { word: "school", noun: true },
  { word: "run", noun: false },
  { word: "happy", noun: false },
  { word: "under", noun: false },
  { word: "quickly", noun: false }
];

const questions = [
  {
    text: "คำใดเป็นคำนาม?",
    options: ["jump", "apple", "slowly", "blue"],
    correct: "apple"
  },
  {
    text: "กลุ่มใดมีแต่คำนาม?",
    options: ["teacher, cat, school", "run, jump, swim", "happy, sad, tall", "quickly, slowly, loudly"],
    correct: "teacher, cat, school"
  },
  {
    text: "เลือกคำนามในประโยคนี้: The dog sleeps.",
    options: ["The", "dog", "sleeps"],
    correct: "dog"
  },
  {
    text: "คำใดใช้เรียกชื่อสถานที่?",
    options: ["school", "beautiful", "walk", "under"],
    correct: "school"
  }
];

const charms = [
  {
    id: "minorPower",
    name: "เครื่องรางพลังน้อย",
    effect: "ถ้าตอบถูก ดาเมจ +10%"
  },
  {
    id: "attackRune",
    name: "เครื่องรางรูนโจมตี",
    effect: "ถ้าตอบถูก ดาเมจ +25%"
  },
  {
    id: "tinyHeal",
    name: "เครื่องรางฟื้นฟูเล็ก",
    effect: "ถ้าตอบถูก ฟื้นฟูพลังชีวิต 8"
  },
  {
    id: "guardWord",
    name: "เครื่องรางคำพิทักษ์",
    effect: "ถ้าตอบผิด ลดดาเมจศัตรูครั้งถัดไป 30%"
  },
  {
    id: "focusGlyph",
    name: "เครื่องรางสัญลักษณ์สมาธิ",
    effect: "ทำให้ช่องสมบูรณ์แบบกว้างขึ้น"
  },
  {
    id: "grammariaSpark",
    name: "เครื่องรางประกายแกรมมาเรีย",
    effect: "ถ้าตอบถูก ได้แกรมมาเรียพิเศษ +5 หลังต่อสู้"
  }
];

const enemyAttackPatterns = {
  normal: {
    id: "normal",
    name: "ดูดกลืนชื่อ",
    announce: "วิญญาณไร้นามกำลังโจมตี!",
    hits: 1,
    baseDamage: 18,
    countdownOptions: [3, 5],
    shortStepDuration: 850,
    longStepDuration: 950,
    gaugeSpeed: 1150,
    gaugeZoneWidth: 22,
    gaugeZoneShrinkPerHit: 0,
    gaugeSpeedUpPerHit: 0
  },
  silentBarrage: {
    id: "silentBarrage",
    name: "Silent Barrage",
    announce: "Null Core uses Silent Barrage!",
    hits: 5,
    baseDamage: 8,
    countdownOptions: [3, 5],
    shortStepDuration: 820,
    longStepDuration: 920,
    gaugeSpeed: 1120,
    gaugeZoneWidth: 26,
    gaugeZoneShrinkPerHit: 3,
    gaugeSpeedUpPerHit: 80
  }
};

let playerData = null;

const playerStorage = {
  get(key) {
    return localStorage.getItem(key);
  },
  set(key, value) {
    localStorage.setItem(key, value);
  }
};

const state = {
  currentUser: null,
  dialogueIndex: 0,
  typewriterTimer: null,
  typewriterText: "",
  typewriterIndex: 0,
  isTypingDialogue: false,
  activeDialogue: [],
  awaitingName: false,
  isTransitioning: false,
  enemyTurnTimer: null,
  selectedNouns: new Set(),
  playerHp: 100,
  enemyHp: 80,
  grammaria: 0,
  sparkBonus: 0,
  currentQuestion: null,
  answerCorrect: false,
  selectedCharm: null,
  shield: 0,
  guardShield: 0,
  charge: null,
  parry: null,
  parryAttack: null
};

const els = {
  googleMockButton: document.getElementById("googleMockButton"),
  guestLoginButton: document.getElementById("guestLoginButton"),
  loginDisplayName: document.getElementById("loginDisplayName"),
  loginEmail: document.getElementById("loginEmail"),
  enterLinguaButton: document.getElementById("enterLinguaButton"),
  loginStatus: document.getElementById("loginStatus"),
  classNameSelect: document.getElementById("classNameSelect"),
  roomInput: document.getElementById("roomInput"),
  avatarPreview: document.getElementById("avatarPreview"),
  avatarPreviewText: document.getElementById("avatarPreviewText"),
  createCharacterButton: document.getElementById("createCharacterButton"),
  createStatus: document.getElementById("createStatus"),
  storyNameForm: document.getElementById("storyNameForm"),
  storyNameInput: document.getElementById("storyNameInput"),
  confirmNameButton: document.getElementById("confirmNameButton"),
  namePromptStatus: document.getElementById("namePromptStatus"),
  startButton: document.getElementById("startButton"),
  speakerName: document.getElementById("speakerName"),
  dialogueText: document.getElementById("dialogueText"),
  nextDialogueButton: document.getElementById("nextDialogueButton"),
  dialoguePanel: document.getElementById("dialoguePanel"),
  dialogueActions: document.getElementById("dialogueActions"),
  nounActivity: document.getElementById("nounActivity"),
  nounActivityVisual: document.getElementById("nounActivityVisual"),
  wordGrid: document.getElementById("wordGrid"),
  activityFeedback: document.getElementById("activityFeedback"),
  battleButton: document.getElementById("battleButton"),
  playerHpFill: document.getElementById("playerHpFill"),
  enemyHpFill: document.getElementById("enemyHpFill"),
  playerHpText: document.getElementById("playerHpText"),
  enemyHpText: document.getElementById("enemyHpText"),
  grammariaText: document.getElementById("grammariaText"),
  shieldText: document.getElementById("shieldText"),
  battleMessage: document.getElementById("battleMessage"),
  actionMenu: document.getElementById("actionMenu"),
  attackButton: document.getElementById("attackButton"),
  itemButton: document.getElementById("itemButton"),
  focusButton: document.getElementById("focusButton"),
  questionPanel: document.getElementById("questionPanel"),
  questionText: document.getElementById("questionText"),
  answerOptions: document.getElementById("answerOptions"),
  charmPanel: document.getElementById("charmPanel"),
  charmOptions: document.getElementById("charmOptions"),
  chargePanel: document.getElementById("chargePanel"),
  chargeBar: document.getElementById("chargeBar"),
  perfectZone: document.getElementById("perfectZone"),
  chargeMarker: document.getElementById("chargeMarker"),
  stopChargeButton: document.getElementById("stopChargeButton"),
  parryPanel: document.getElementById("parryPanel"),
  enemyAttackName: document.getElementById("enemyAttackName"),
  parryHitText: document.getElementById("parryHitText"),
  parryCountdown: document.getElementById("parryCountdown"),
  parryGaugeZone: document.getElementById("parryGaugeZone"),
  parryGaugeMarker: document.getElementById("parryGaugeMarker"),
  parryHitResult: document.getElementById("parryHitResult"),
  parryButton: document.getElementById("parryButton"),
  continueBattleButton: document.getElementById("continueBattleButton"),
  victoryGrammaria: document.getElementById("victoryGrammaria"),
  victoryExtra: document.getElementById("victoryExtra"),
  returnTitleButton: document.getElementById("returnTitleButton"),
  sceneTransition: document.getElementById("sceneTransition"),
  transitionText: document.getElementById("transitionText"),
  storyWanderer: document.getElementById("storyWanderer"),
  storyVerion: document.getElementById("storyVerion"),
  battlePlayer: document.getElementById("battlePlayer"),
  battleEnemy: document.getElementById("battleEnemy")
};

function showScene(name) {
  Object.values(scenes).forEach(scene => scene.classList.remove("active"));
  scenes[name].classList.add("active");
}

function runSceneTransition(message, onCovered) {
  if (state.isTransitioning) {
    return;
  }

  state.isTransitioning = true;
  els.transitionText.textContent = message;
  els.sceneTransition.classList.remove("hidden");

  requestAnimationFrame(() => {
    els.sceneTransition.classList.add("visible");
  });

  setTimeout(() => {
    onCovered();

    setTimeout(() => {
      els.sceneTransition.classList.remove("visible");

      setTimeout(() => {
        els.sceneTransition.classList.add("hidden");
        state.isTransitioning = false;
      }, 380);
    }, 260);
  }, 420);
}

function showOnlyBattlePanel(panelToShow) {
  [els.actionMenu, els.questionPanel, els.charmPanel, els.chargePanel, els.parryPanel, els.continueBattleButton]
    .forEach(panel => panel.classList.add("hidden"));

  if (panelToShow) {
    panelToShow.classList.remove("hidden");
  }
}

function setActionButtonsEnabled(isEnabled) {
  [els.attackButton, els.itemButton, els.focusButton].forEach(button => {
    button.disabled = !isEnabled;
  });
}

function clearEnemyTurnTimer() {
  if (state.enemyTurnTimer) {
    clearTimeout(state.enemyTurnTimer);
    state.enemyTurnTimer = null;
  }
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function sample(array, count) {
  const copy = [...array];
  const result = [];

  while (copy.length && result.length < count) {
    const index = Math.floor(Math.random() * copy.length);
    result.push(copy.splice(index, 1)[0]);
  }

  return result;
}

function normalizeEmail(email) {
  return email.trim().toLowerCase();
}

function getPlayerStorageKey(userIdOrEmail) {
  const normalized = normalizeEmail(userIdOrEmail);
  if (normalized === "guest" || normalized === "guest@lingua.local") {
    return "lingua_player_guest";
  }
  return `lingua_player_${normalized}`;
}

function getCurrentUser() {
  return state.currentUser;
}

function loginWithGoogleMock() {
  const displayName = els.loginDisplayName.value.trim();
  const email = normalizeEmail(els.loginEmail.value);

  if (!displayName || !email) {
    els.loginStatus.textContent = "กรุณากรอกชื่อผู้เล่นและอีเมล Gmail";
    return;
  }

  if (!email.endsWith("@gmail.com")) {
    els.loginStatus.textContent = "กรุณาใช้อีเมล Gmail สำหรับ mock login";
    return;
  }

  state.currentUser = {
    userId: email,
    email,
    displayName,
    isGuest: false
  };

  els.loginStatus.textContent = "กำลังโหลดข้อมูลผู้เล่น...";

  if (hasExistingPlayer(email)) {
    loadPlayerProfile(email);
    els.loginStatus.textContent = "พบข้อมูลเดิม กำลังเข้าสู่โลก Lingua";
    runSceneTransition("พบข้อมูลเดิม กำลังเข้าสู่โลก Lingua...", setupStoryScene);
    return;
  }

  els.createStatus.textContent = "ยังไม่พบตัวละคร กรุณาสร้างตัวละครก่อนเริ่มเดินทาง";
  runSceneTransition("กำลังเตรียมหน้าสร้างตัวละคร...", () => showScene("createCharacter"));
}

function hasExistingPlayer(userIdOrEmail) {
  return Boolean(playerStorage.get(getPlayerStorageKey(userIdOrEmail)));
}

function loginAsGuest() {
  state.currentUser = {
    userId: "guest",
    email: "guest@lingua.local",
    displayName: "Guest Player",
    isGuest: true
  };

  els.loginStatus.textContent = "กำลังโหลดข้อมูล Guest...";

  if (hasExistingPlayer("guest")) {
    loadPlayerProfile("guest");
    els.loginStatus.textContent = "พบข้อมูล Guest เดิม กำลังเข้าสู่โลก Lingua";
    runSceneTransition("พบข้อมูล Guest เดิม กำลังเข้าสู่โลก Lingua...", setupStoryScene);
    return;
  }

  els.createStatus.textContent = "ยังไม่พบตัวละคร Guest กรุณาสร้างตัวละครก่อนเริ่มเดินทาง";
  runSceneTransition("กำลังเตรียมหน้าสร้างตัวละคร Guest...", () => showScene("createCharacter"));
}

function loadPlayerData(userIdOrEmail) {
  const saved = playerStorage.get(getPlayerStorageKey(userIdOrEmail));
  return saved ? JSON.parse(saved) : null;
}

function loadPlayerProfile(userIdOrEmail) {
  playerData = loadPlayerData(userIdOrEmail);
  if (playerData) {
    state.currentUser = {
      userId: playerData.userId,
      email: playerData.email,
      displayName: playerData.displayName,
      isGuest: Boolean(playerData.isGuest)
    };
  }
  return playerData;
}

function savePlayerProfile() {
  return savePlayerData();
}

function createDefaultPlayerData(user) {
  const now = new Date().toISOString();
  return {
    userId: user.userId,
    email: user.email,
    displayName: user.displayName,
    isGuest: Boolean(user.isGuest),
    characterName: "",
    className: "",
    room: "",
    avatar: {
      gender: "other",
      bodyType: "normal",
      type: "wanderer",
      outfit: "default",
      color: "blue"
    },
    level: 1,
    grammaria: 0,
    coins: 0,
    hp: 100,
    maxHp: 100,
    stats: {
      atk: 1,
      def: 1,
      vit: 1,
      agi: 1,
      luk: 1,
      statusPoints: 0
    },
    progress: {
      currentAct: 1,
      currentChapter: 1,
      currentScene: "story",
      unlockedFragments: [],
      restoredCores: [],
      defeatedEnemies: []
    },
    inventory: {
      battleItems: [],
      equipment: [],
      keyItems: []
    },
    settings: {
      textSpeed: "normal",
      sound: true,
      language: "th"
    },
    createdAt: now,
    updatedAt: now
  };
}

function savePlayerData() {
  if (!playerData) {
    return false;
  }

  playerData.updatedAt = new Date().toISOString();
  playerStorage.set(getPlayerStorageKey(playerData.email), JSON.stringify(playerData));
  return true;
}

function mergeDeep(target, source) {
  Object.entries(source).forEach(([key, value]) => {
    if (value && typeof value === "object" && !Array.isArray(value)) {
      target[key] = target[key] || {};
      mergeDeep(target[key], value);
    } else {
      target[key] = value;
    }
  });
  return target;
}

function updatePlayerProgress(updateObject) {
  if (!playerData) {
    return;
  }

  mergeDeep(playerData, updateObject);
  savePlayerData();
}

function syncBattleStateToPlayerData() {
  if (!playerData) {
    return;
  }

  updatePlayerProgress({
    grammaria: state.grammaria,
    hp: state.playerHp
  });
}

function addUniqueProgressItem(listName, value) {
  if (!playerData) {
    return;
  }

  if (!playerData.progress[listName].includes(value)) {
    playerData.progress[listName].push(value);
  }
}

function createCharacterFromForm() {
  const user = getCurrentUser();
  if (!user) {
    els.createStatus.textContent = "กรุณาเข้าสู่ระบบก่อนสร้างตัวละคร";
    showScene("login");
    return;
  }

  const className = els.classNameSelect.value;
  const room = els.roomInput.value.trim();
  const avatarChoice = document.querySelector("input[name=\"avatarType\"]:checked");
  const genderChoice = document.querySelector("input[name=\"avatarGender\"]:checked");
  const bodyTypeChoice = document.querySelector("input[name=\"avatarBodyType\"]:checked");

  if (!room) {
    els.createStatus.textContent = "กรุณากรอกห้องเรียน";
    return;
  }

  playerData = createDefaultPlayerData(user);
  playerData.characterName = "";
  playerData.className = className;
  playerData.room = room;
  playerData.avatar = {
    gender: genderChoice ? genderChoice.value : "other",
    bodyType: bodyTypeChoice ? bodyTypeChoice.value : "normal",
    type: avatarChoice ? avatarChoice.value : "wanderer",
    outfit: "default",
    color: "blue"
  };

  savePlayerProfile();
  els.createStatus.textContent = "บันทึกข้อมูลแล้ว";
  runSceneTransition("บันทึกข้อมูลแล้ว กำลังเข้าสู่โลก Lingua...", setupStoryScene);
}

function getCheckedRadioValue(name, fallback) {
  const checked = document.querySelector(`input[name="${name}"]:checked`);
  return checked ? checked.value : fallback;
}

function updateAvatarPreview() {
  if (!els.avatarPreview || !els.avatarPreviewText) {
    return;
  }

  const gender = getCheckedRadioValue("avatarGender", "other");
  const bodyType = getCheckedRadioValue("avatarBodyType", "normal");
  const genderLabels = { male: "ชาย", female: "หญิง", other: "ไม่ระบุ" };
  const bodyLabels = { small: "ตัวเล็ก", normal: "ปกติ", tall: "สูง" };

  els.avatarPreview.className = `avatar-preview avatar-gender-${gender} avatar-body-${bodyType}`;
  els.avatarPreviewText.textContent = `ตัวอย่าง: ${genderLabels[gender] || genderLabels.other} / ${bodyLabels[bodyType] || bodyLabels.normal}`;
}

function bindAvatarPreviewInputs() {
  document.querySelectorAll("input[name=\"avatarGender\"], input[name=\"avatarBodyType\"]").forEach(input => {
    input.addEventListener("change", updateAvatarPreview);
  });
  updateAvatarPreview();
}

function getCharacterName() {
  return playerData && playerData.characterName ? playerData.characterName.trim() : "";
}

function createNameGreetingLine() {
  return {
    speaker: "มาสเตอร์เวรีออน",
    text: () => `"ยินดีที่ได้พบเจ้า, ${getCharacterName()} นับจากนี้ ชื่อนี้จะเป็นแสงแรกที่ผูกเจ้ากับโลก Lingua"`
  };
}

function buildStoryDialogue() {
  const lines = [...prologueDialogue];

  if (getCharacterName()) {
    lines.push(createNameGreetingLine());
  } else {
    lines.push(...namingDialogue);
  }

  return lines.concat(mainStoryDialogue);
}

function resolveDialogueText(line) {
  return typeof line.text === "function" ? line.text() : line.text;
}

function showNamePrompt() {
  state.awaitingName = true;
  els.storyNameForm.classList.remove("hidden");
  els.nextDialogueButton.classList.add("hidden");
  els.namePromptStatus.textContent = "";
  setDialogueButtonReady(false);
  setTimeout(() => els.storyNameInput.focus(), 80);
}

function hideNamePrompt() {
  state.awaitingName = false;
  els.storyNameForm.classList.add("hidden");
  els.nextDialogueButton.classList.remove("hidden");
}

function confirmStoryName() {
  const name = els.storyNameInput.value.trim();

  if (!name) {
    els.namePromptStatus.textContent = "กรุณากรอกชื่อก่อนเริ่มการเดินทาง";
    return;
  }

  if (!playerData) {
    const user = getCurrentUser() || {
      userId: "guest",
      email: "guest@lingua.local",
      displayName: "Guest Player",
      isGuest: true
    };
    playerData = createDefaultPlayerData(user);
  }

  playerData.characterName = name;
  playerData.displayName = name;
  savePlayerData();
  hideNamePrompt();
  state.activeDialogue.splice(state.dialogueIndex + 1, 0, createNameGreetingLine());
  advanceDialogue();
}

function updateDialogue() {
  const line = state.activeDialogue[state.dialogueIndex];
  els.speakerName.textContent = line.speaker;
  updateSpeakingCharacter(line.speaker);
  startTypewriter(resolveDialogueText(line));
}

function startTypewriter(text) {
  stopTypewriter();
  state.typewriterText = text;
  state.typewriterIndex = 0;
  state.isTypingDialogue = true;
  els.dialogueText.textContent = "";
  setDialogueButtonReady(false);
  typeNextCharacter();
}

function typeNextCharacter() {
  if (!state.isTypingDialogue) {
    return;
  }

  state.typewriterIndex += 1;
  els.dialogueText.textContent = state.typewriterText.slice(0, state.typewriterIndex);

  if (state.typewriterIndex >= state.typewriterText.length) {
    finishTypewriter();
    return;
  }

  state.typewriterTimer = setTimeout(typeNextCharacter, 44);
}

function finishTypewriter() {
  stopTypewriter();
  els.dialogueText.textContent = state.typewriterText;
  state.isTypingDialogue = false;
  setDialogueButtonReady(true);

  const line = state.activeDialogue[state.dialogueIndex];
  if (line && line.requiresName && !getCharacterName()) {
    showNamePrompt();
  }
}

function stopTypewriter() {
  if (state.typewriterTimer) {
    clearTimeout(state.typewriterTimer);
  }

  state.typewriterTimer = null;
}

function setDialogueButtonReady(isReady) {
  els.nextDialogueButton.disabled = !isReady;
  els.nextDialogueButton.setAttribute("aria-disabled", isReady ? "false" : "true");
  els.nextDialogueButton.classList.toggle("is-waiting", !isReady);
}

function updateSpeakingCharacter(speaker) {
  els.storyWanderer.classList.remove("is-speaking");
  els.storyVerion.classList.remove("is-speaking");

  if (speaker.includes("ผู้พเนจร")) {
    els.storyWanderer.classList.add("is-speaking");
  }

  if (speaker.includes("เวรีออน")) {
    els.storyVerion.classList.add("is-speaking");
  }
}

function clearSpeakingCharacters() {
  els.storyWanderer.classList.remove("is-speaking");
  els.storyVerion.classList.remove("is-speaking");
}

function triggerMotion(element, className) {
  element.classList.remove(className);
  void element.offsetWidth;
  element.classList.add(className);

  setTimeout(() => {
    element.classList.remove(className);
  }, 560);
}

function startStory() {
  if (state.isTransitioning) {
    return;
  }

  runSceneTransition("กำลังเข้าสู่หอคอยแห่ง Unity...", setupStoryScene);
}

function setupStoryScene() {
  stopTypewriter();
  state.dialogueIndex = 0;
  state.activeDialogue = buildStoryDialogue();
  state.awaitingName = false;
  hideNamePrompt();
  els.storyNameInput.value = "";
  els.dialoguePanel.classList.remove("hidden");
  els.dialogueActions.classList.remove("hidden");
  els.nounActivity.classList.add("hidden");
  els.nounActivityVisual.classList.add("hidden");
  showScene("story");
  updatePlayerProgress({ progress: { currentScene: "story" } });
  updateDialogue();
}

function advanceDialogue() {
  if (state.isTransitioning) {
    return;
  }

  if (state.isTypingDialogue) {
    return;
  }

  if (state.awaitingName) {
    return;
  }

  state.dialogueIndex += 1;

  if (state.dialogueIndex >= state.activeDialogue.length) {
    stopTypewriter();
    clearSpeakingCharacters();
    runSceneTransition("เสียงของถ้อยคำเริ่มกลับคืน...", () => {
      els.dialoguePanel.classList.add("hidden");
      els.dialogueActions.classList.add("hidden");
      startNounActivity();
    });
    return;
  }

  updateDialogue();
}

function startNounActivity() {
  state.selectedNouns.clear();
  els.wordGrid.innerHTML = "";
  els.activityFeedback.textContent = "หา 4 คำที่ใช้เรียกชื่อสิ่งต่าง ๆ";
  els.battleButton.classList.add("hidden");
  updatePlayerProgress({ progress: { currentScene: "nounActivity" } });

  nounWords.forEach(item => {
    const button = document.createElement("button");
    button.className = "word-card";
    button.textContent = item.word;
    button.addEventListener("click", () => selectWord(button, item));
    els.wordGrid.appendChild(button);
  });

  els.nounActivity.classList.remove("hidden");
  els.nounActivityVisual.classList.remove("hidden");
}

function selectWord(button, item) {
  if (item.noun) {
    state.selectedNouns.add(item.word);
    button.classList.add("correct");
    button.disabled = true;
    els.activityFeedback.textContent = `ถูกต้อง "${item.word}" เป็นคำที่ใช้เรียกชื่อสิ่งหนึ่ง`;
  } else {
    button.classList.remove("wrong");
    void button.offsetWidth;
    button.classList.add("wrong");
    els.activityFeedback.textContent = `"${item.word}" ยังไม่ใช่คำนามในบทเรียนนี้`;
  }

  if (state.selectedNouns.size === 4) {
    els.activityFeedback.textContent = "\"ดีมาก หอคอยจำชื่อของมันได้แล้ว แต่บางสิ่งกำลังขโมยมันไปอีกครั้ง\"";
    els.battleButton.classList.remove("hidden");
    updatePlayerProgress({ progress: { currentScene: "battleReady" } });
  }
}

function startBattleFromActivity() {
  runSceneTransition("วิสป์ไร้นามปรากฏตัว!", resetBattle);
}

function resetBattle() {
  clearEnemyTurnTimer();
  stopTimer("charge");
  stopParryCountdown();

  state.playerHp = 100;
  state.enemyHp = 80;
  state.grammaria = 0;
  state.sparkBonus = 0;
  state.currentQuestion = null;
  state.answerCorrect = false;
  state.selectedCharm = null;
  state.shield = 0;
  state.guardShield = 0;
  state.parryAttack = null;

  updateBattleStats();
  updatePlayerProgress({
    hp: state.playerHp,
    progress: { currentScene: "battle" }
  });
  setActionButtonsEnabled(true);
  els.battleMessage.textContent = "วิญญาณไร้นามลอยเข้ามาใกล้";
  showOnlyBattlePanel(els.actionMenu);
  showScene("battle");
}

function updateBattleStats() {
  const playerPercent = (state.playerHp / 100) * 100;
  const enemyPercent = (state.enemyHp / 80) * 100;

  els.playerHpFill.style.width = `${playerPercent}%`;
  els.enemyHpFill.style.width = `${enemyPercent}%`;
  els.playerHpText.textContent = `พลังชีวิต ${state.playerHp} / 100`;
  els.enemyHpText.textContent = `พลังชีวิต ${state.enemyHp} / 80`;
  els.grammariaText.textContent = state.grammaria;

  if (state.shield > 0) {
    els.shieldText.textContent = "สมาธิ";
  } else if (state.guardShield > 0) {
    els.shieldText.textContent = "พิทักษ์";
  } else {
    els.shieldText.textContent = "ไม่มี";
  }
}

function startAttack() {
  state.currentQuestion = sample(questions, 1)[0];
  state.answerCorrect = false;
  state.selectedCharm = null;

  els.questionText.textContent = state.currentQuestion.text;
  els.answerOptions.innerHTML = "";

  state.currentQuestion.options.forEach(option => {
    const button = document.createElement("button");
    button.className = "answer-button";
    button.textContent = option;
    button.addEventListener("click", () => chooseAnswer(option));
    els.answerOptions.appendChild(button);
  });

  els.battleMessage.textContent = "ระบุความหมายก่อนร่ายเวท";
  showOnlyBattlePanel(els.questionPanel);
}

function chooseAnswer(option) {
  state.answerCorrect = option === state.currentQuestion.correct;
  els.battleMessage.textContent = state.answerCorrect
    ? "คำนั้นเปล่งแสงแห่งความหมาย เลือกเครื่องรางหนึ่งชิ้น"
    : "ความหมายเริ่มสั่นไหว เครื่องรางอาจยังช่วยปกป้องเจ้าได้";
  showCharmChoices();
}

function showCharmChoices() {
  els.charmOptions.innerHTML = "";

  sample(charms, 3).forEach(charm => {
    const button = document.createElement("button");
    button.className = "charm-card";
    button.innerHTML = `<strong>${charm.name}</strong><span>${charm.effect}</span>`;
    button.addEventListener("click", () => chooseCharm(charm));
    els.charmOptions.appendChild(button);
  });

  showOnlyBattlePanel(els.charmPanel);
}

function chooseCharm(charm) {
  state.selectedCharm = charm;
  els.battleMessage.textContent = `เลือก ${charm.name} แล้ว หยุดชาร์จให้ถูกจังหวะ`;
  startCharge();
}

function startCharge() {
  const widerPerfect = state.selectedCharm && state.selectedCharm.id === "focusGlyph";
  const zoneWidth = widerPerfect ? 30 : 18;
  const zoneStart = (100 - zoneWidth) / 2;

  els.perfectZone.style.width = `${zoneWidth}%`;
  els.perfectZone.style.left = `${zoneStart}%`;
  showOnlyBattlePanel(els.chargePanel);
  state.charge = createTimer(els.chargeMarker, 1050);
}

function createTimer(marker, duration) {
  const timer = {
    marker,
    duration,
    direction: 1,
    progress: 0,
    lastTime: null,
    frame: null
  };

  const step = timestamp => {
    if (!timer.lastTime) {
      timer.lastTime = timestamp;
    }

    const elapsed = timestamp - timer.lastTime;
    timer.lastTime = timestamp;
    timer.progress += (elapsed / timer.duration) * 100 * timer.direction;

    if (timer.progress >= 100) {
      timer.progress = 100;
      timer.direction = -1;
    }

    if (timer.progress <= 0) {
      timer.progress = 0;
      timer.direction = 1;
    }

    marker.style.left = `calc(${timer.progress}% - 4px)`;
    timer.frame = requestAnimationFrame(step);
  };

  timer.frame = requestAnimationFrame(step);
  return timer;
}

function stopTimer(type) {
  const timer = state[type];
  if (timer && timer.frame) {
    cancelAnimationFrame(timer.frame);
  }
  state[type] = null;
}

function stopParryCountdown() {
  if (!state.parry) {
    return;
  }

  if (state.parry.tickTimeout) {
    clearTimeout(state.parry.tickTimeout);
  }

  if (state.parry.resolveTimeout) {
    clearTimeout(state.parry.resolveTimeout);
  }

  if (state.parry.gaugeFrame) {
    cancelAnimationFrame(state.parry.gaugeFrame);
  }

  state.parry = null;
  els.parryButton.disabled = false;
}

function timingResult(progress, perfectWidth) {
  const perfectStart = (100 - perfectWidth) / 2;
  const perfectEnd = perfectStart + perfectWidth;
  const greatStart = perfectStart - 12;
  const greatEnd = perfectEnd + 12;
  const goodStart = perfectStart - 24;
  const goodEnd = perfectEnd + 24;

  if (progress >= perfectStart && progress <= perfectEnd) {
    return "PERFECT";
  }

  if (progress >= greatStart && progress <= greatEnd) {
    return "GREAT";
  }

  if (progress >= goodStart && progress <= goodEnd) {
    return "GOOD";
  }

  return "MISS";
}

function thaiTimingName(result) {
  const names = {
    PERFECT: "สมบูรณ์แบบ",
    GREAT: "ยอดเยี่ยม",
    GOOD: "ดี",
    MISS: "พลาด"
  };

  return names[result] || result;
}

function stopCharge() {
  if (!state.charge) {
    return;
  }

  const progress = state.charge.progress;
  const perfectWidth = state.selectedCharm && state.selectedCharm.id === "focusGlyph" ? 30 : 18;
  const result = timingResult(progress, perfectWidth);
  stopTimer("charge");
  resolvePlayerAttack(result);
}

function resolvePlayerAttack(chargeResult) {
  const chargeModifiers = {
    PERFECT: 1.5,
    GREAT: 1.25,
    GOOD: 1,
    MISS: 0.75
  };

  let damage = 0;
  let message = "";

  if (state.answerCorrect) {
    triggerMotion(els.battlePlayer, "player-attack-motion");
    damage = 25;

    if (state.selectedCharm.id === "minorPower") {
      damage *= 1.1;
    }

    if (state.selectedCharm.id === "attackRune") {
      damage *= 1.25;
    }

    damage = Math.round(damage * chargeModifiers[chargeResult]);
    state.enemyHp = clamp(state.enemyHp - damage, 0, 80);
    state.grammaria += 20;

    if (state.selectedCharm.id === "tinyHeal") {
      state.playerHp = clamp(state.playerHp + 8, 0, 100);
    }

    if (state.selectedCharm.id === "grammariaSpark") {
      state.sparkBonus += 5;
    }

    message = `ผู้พเนจรร่ายแกรมมาเรีย! ชาร์จระดับ ${thaiTimingName(chargeResult)} สร้างดาเมจ ${damage}`;
  } else {
    if (state.selectedCharm.id === "guardWord") {
      state.guardShield = 0.3;
    }

    message = `แกรมมาเรียเลือนหาย ความหมายยังไม่ชัดเจน ชาร์จระดับ ${thaiTimingName(chargeResult)} จึงโจมตีไม่ได้`;
  }

  updateBattleStats();
  syncBattleStateToPlayerData();
  endPlayerTurn(message);
}

function useItem() {
  endPlayerTurn("เจ้ายังไม่มีไอเทมต่อสู้ จังหวะลังเลเปิดช่องให้ศัตรูโจมตี");
}

function endPlayerTurn(message) {
  clearEnemyTurnTimer();
  showOnlyBattlePanel(null);
  els.battleMessage.textContent = message;

  if (state.enemyHp <= 0) {
    setTimeout(showVictory, 900);
    return;
  }

  setActionButtonsEnabled(false);
  state.enemyTurnTimer = setTimeout(() => {
    state.enemyTurnTimer = null;
    startEnemyTurn();
  }, 900);
}

function focusTurn() {
  state.shield = 0.4;
  updateBattleStats();
  endPlayerTurn("ผู้พเนจรตั้งสมาธิและทำให้กระแสแกรมมาเรียนิ่งขึ้น");
}

function startEnemyTurn(pattern = enemyAttackPatterns.normal) {
  startEnemyAttack(pattern);
}

function startEnemyAttack(pattern) {
  clearEnemyTurnTimer();
  stopParryCountdown();
  setActionButtonsEnabled(false);
  triggerMotion(els.battleEnemy, "enemy-attack-motion");
  state.parryAttack = {
    pattern,
    hitIndex: 0,
    results: [],
    totalDamage: 0,
    totalCounterDamage: 0,
    perfectStreak: 0,
    maxPerfectStreak: 0,
    streakBonus: false,
    fullPerfectBonus: false
  };

  els.battleMessage.textContent = pattern.hits > 1
    ? `${pattern.announce}\nเตรียมปัดป้อง ${pattern.hits} hit ติดต่อกัน!`
    : pattern.announce;

  beginNextParryHit();
}

function beginNextParryHit() {
  const attack = state.parryAttack;
  if (!attack) {
    return;
  }

  if (attack.hitIndex >= attack.pattern.hits) {
    finishEnemyAttackSequence();
    return;
  }

  attack.hitIndex += 1;
  const hitNumber = attack.hitIndex;
  const pattern = attack.pattern;
  const startCount = sample(pattern.countdownOptions, 1)[0];
  const stepDuration = startCount === 3 ? pattern.shortStepDuration : pattern.longStepDuration;
  const targetDelayInsideOne = 420;
  const gaugeZoneWidth = Math.max(12, pattern.gaugeZoneWidth - ((hitNumber - 1) * pattern.gaugeZoneShrinkPerHit));
  const gaugeSpeed = Math.max(720, pattern.gaugeSpeed - ((hitNumber - 1) * pattern.gaugeSpeedUpPerHit));
  const now = performance.now();

  state.parry = {
    active: true,
    current: startCount,
    hitNumber,
    totalHits: pattern.hits,
    stepDuration,
    targetTime: now + ((startCount - 1) * stepDuration) + targetDelayInsideOne,
    tickTimeout: null,
    resolveTimeout: null,
    gaugeProgress: 0,
    gaugeDirection: 1,
    gaugeLastTime: null,
    gaugeFrame: null,
    gaugeSpeed,
    gaugeZoneWidth,
    gaugeZoneStart: (100 - gaugeZoneWidth) / 2
  };

  els.enemyAttackName.textContent = pattern.name;
  els.parryHitText.textContent = `Hit ${hitNumber} / ${pattern.hits}`;
  els.parryHitResult.textContent = attack.results.length
    ? `ผลล่าสุด: ${thaiParryName(attack.results[attack.results.length - 1].result)}`
    : "";
  els.parryGaugeZone.style.width = `${gaugeZoneWidth}%`;
  els.parryGaugeZone.style.left = `${state.parry.gaugeZoneStart}%`;
  els.parryButton.disabled = false;
  showOnlyBattlePanel(els.parryPanel);
  showParryCount(startCount);
  startParryGauge();
  scheduleParryCount(startCount);
}

function startParryGauge() {
  const step = timestamp => {
    if (!state.parry || !state.parry.active) {
      return;
    }

    if (!state.parry.gaugeLastTime) {
      state.parry.gaugeLastTime = timestamp;
    }

    const elapsed = timestamp - state.parry.gaugeLastTime;
    state.parry.gaugeLastTime = timestamp;
    state.parry.gaugeProgress += (elapsed / state.parry.gaugeSpeed) * 100 * state.parry.gaugeDirection;

    if (state.parry.gaugeProgress >= 100) {
      state.parry.gaugeProgress = 100;
      state.parry.gaugeDirection = -1;
    }

    if (state.parry.gaugeProgress <= 0) {
      state.parry.gaugeProgress = 0;
      state.parry.gaugeDirection = 1;
    }

    els.parryGaugeMarker.style.left = `calc(${state.parry.gaugeProgress}% - 5px)`;
    state.parry.gaugeFrame = requestAnimationFrame(step);
  };

  els.parryGaugeMarker.style.left = "0";
  state.parry.gaugeFrame = requestAnimationFrame(step);
}

function showParryCount(count) {
  els.parryCountdown.textContent = count;
  els.parryCountdown.classList.remove("pulse");
  void els.parryCountdown.offsetWidth;
  els.parryCountdown.classList.add("pulse");
}

function scheduleParryCount(count) {
  if (!state.parry || !state.parry.active) {
    return;
  }

  if (count > 1) {
    state.parry.tickTimeout = setTimeout(() => {
      showParryCount(count - 1);
      scheduleParryCount(count - 1);
    }, state.parry.stepDuration);
    return;
  }

  state.parry.resolveTimeout = setTimeout(() => {
    resolveCountdownParry("MISS");
  }, state.parry.stepDuration + 650);
}

function stopParry() {
  if (!state.parry || !state.parry.active) {
    return;
  }

  const result = countdownParryResult(performance.now());
  resolveCountdownParry(result);
}

function countdownParryResult(clickTime) {
  const diff = Math.abs(clickTime - state.parry.targetTime);
  const tooEarly = clickTime < state.parry.targetTime - 700;
  const tooLate = clickTime > state.parry.targetTime + 1050;
  const gaugeResult = parryGaugeResult(state.parry.gaugeProgress);

  if (tooEarly || tooLate) {
    return "MISS";
  }

  if (diff <= 250) {
    return gaugeResult === "PERFECT" || gaugeResult === "GREAT" ? "PERFECT" : "GREAT";
  }

  if (diff <= 550) {
    return gaugeResult === "MISS" ? "GOOD" : "GREAT";
  }

  return "GOOD";
}

function parryGaugeResult(progress) {
  const perfectStart = state.parry.gaugeZoneStart;
  const perfectEnd = perfectStart + state.parry.gaugeZoneWidth;
  const greatStart = perfectStart - 12;
  const greatEnd = perfectEnd + 12;
  const goodStart = perfectStart - 24;
  const goodEnd = perfectEnd + 24;

  if (progress >= perfectStart && progress <= perfectEnd) {
    return "PERFECT";
  }

  if (progress >= greatStart && progress <= greatEnd) {
    return "GREAT";
  }

  if (progress >= goodStart && progress <= goodEnd) {
    return "GOOD";
  }

  return "MISS";
}

function resolveCountdownParry(result) {
  if (!state.parry || !state.parry.active) {
    return;
  }

  const hitNumber = state.parry.hitNumber;
  state.parry.active = false;
  els.parryButton.disabled = true;
  stopParryCountdown();
  resolveEnemyHit(result, hitNumber);
}

function resolveEnemyHit(parryResult, hitNumber) {
  const attack = state.parryAttack;
  if (!attack) {
    return;
  }

  const hit = calculateParryHit(parryResult, attack.pattern.baseDamage);
  attack.results.push({ hit: hitNumber, result: parryResult, damage: hit.damage, counterDamage: hit.counterDamage });
  attack.totalDamage += hit.damage;
  attack.totalCounterDamage += hit.counterDamage;

  if (parryResult === "PERFECT") {
    attack.perfectStreak += 1;
    attack.maxPerfectStreak = Math.max(attack.maxPerfectStreak, attack.perfectStreak);
  } else {
    attack.perfectStreak = 0;
  }

  els.parryHitResult.textContent = `${thaiParryName(parryResult)} - ดาเมจที่รับ ${hit.damage}`;

  if (attack.hitIndex >= attack.pattern.hits) {
    setTimeout(finishEnemyAttackSequence, 700);
    return;
  }

  setTimeout(beginNextParryHit, 700);
}

function calculateParryHit(parryResult, baseDamage) {
  if (parryResult === "PERFECT") {
    return { damage: 0, counterDamage: 5 };
  }

  if (parryResult === "GREAT") {
    return { damage: Math.round(baseDamage * 0.3), counterDamage: 0 };
  }

  if (parryResult === "GOOD") {
    return { damage: Math.round(baseDamage * 0.6), counterDamage: 0 };
  }

  return { damage: baseDamage, counterDamage: 0 };
}

function finishEnemyAttackSequence() {
  const attack = state.parryAttack;
  if (!attack) {
    return;
  }

  let totalDamage = attack.totalDamage;
  let totalCounterDamage = attack.totalCounterDamage;
  const counts = countParryResults(attack.results);
  const summaryLines = [];

  if (attack.maxPerfectStreak >= 3) {
    attack.streakBonus = true;
    totalCounterDamage += 10;
    summaryLines.push("Perfect Streak! Grammaria Counter is charging!");
  }

  if (attack.pattern.hits > 1 && counts.PERFECT === attack.pattern.hits) {
    attack.fullPerfectBonus = true;
    totalCounterDamage += 20;
    summaryLines.push("GRAMMARIA COUNTER BURST!");
  }

  if (state.shield > 0) {
    totalDamage *= 1 - state.shield;
    state.shield = 0;
  }

  if (state.guardShield > 0) {
    totalDamage *= 1 - state.guardShield;
    state.guardShield = 0;
  }

  totalDamage = Math.round(totalDamage);
  state.playerHp = clamp(state.playerHp - totalDamage, 0, 100);
  state.enemyHp = clamp(state.enemyHp - totalCounterDamage, 0, 80);

  updateBattleStats();
  syncBattleStateToPlayerData();
  showOnlyBattlePanel(null);
  els.battleMessage.textContent = buildParrySummary(attack, counts, totalDamage, totalCounterDamage, summaryLines);
  state.parryAttack = null;

  if (state.enemyHp <= 0) {
    setTimeout(showVictory, 900);
    return;
  }

  if (state.playerHp <= 0) {
    state.playerHp = 35;
    updateBattleStats();
    els.battleMessage.textContent += "\nอาจารย์เวเรียนประคองบทเรียนไว้ ผู้พเนจรลุกขึ้นพร้อมพลังชีวิต 35";
  }

  els.continueBattleButton.textContent = "ตาผู้เล่น";
  els.continueBattleButton.onclick = () => {
    els.battleMessage.textContent = "เลือกการกระทำของเจ้า";
    setActionButtonsEnabled(true);
    showOnlyBattlePanel(els.actionMenu);
  };
  els.continueBattleButton.classList.remove("hidden");
}

function countParryResults(results) {
  return results.reduce((counts, item) => {
    counts[item.result] += 1;
    return counts;
  }, { PERFECT: 0, GREAT: 0, GOOD: 0, MISS: 0 });
}

function buildParrySummary(attack, counts, totalDamage, totalCounterDamage, bonusLines) {
  const title = attack.pattern.hits > 1 ? "สรุปผล Multi-Hit Parry" : thaiParryName(attack.results[0].result);
  const lines = [
    title,
    `ท่าโจมตี: ${attack.pattern.name}`,
    `Perfect: ${counts.PERFECT}`,
    `Great: ${counts.GREAT}`,
    `Good: ${counts.GOOD}`,
    `Miss: ${counts.MISS}`,
    `Total Damage Taken: ${totalDamage}`
  ];

  if (totalCounterDamage > 0) {
    lines.push(`Counter Damage: ${totalCounterDamage}`);
  }

  return lines.concat(bonusLines).join("\n");
}

function thaiParryName(result) {
  const names = {
    PERFECT: "ปัดป้องสมบูรณ์แบบ",
    GREAT: "ปัดป้องยอดเยี่ยม",
    GOOD: "ตั้งรับได้ดี",
    MISS: "พลาด"
  };

  return names[result] || result;
}

function showVictory() {
  runSceneTransition("เศษเสี้ยวแห่งชื่อกำลังฟื้นคืน...", completeVictoryScene);
}

function completeVictoryScene() {
  clearEnemyTurnTimer();
  stopTimer("charge");
  stopParryCountdown();
  els.victoryGrammaria.textContent = state.grammaria + state.sparkBonus;
  els.victoryExtra.textContent = state.sparkBonus;

  if (playerData) {
    playerData.grammaria = state.grammaria + state.sparkBonus;
    playerData.hp = state.playerHp;
    playerData.progress.currentScene = "victory";
    addUniqueProgressItem("unlockedFragments", "Name Fragment");
    addUniqueProgressItem("defeatedEnemies", "Nameless Wisp");
    savePlayerData();
  }

  showScene("victory");
}

els.googleMockButton.addEventListener("click", loginWithGoogleMock);
els.guestLoginButton.addEventListener("click", loginAsGuest);
els.enterLinguaButton.addEventListener("click", loginWithGoogleMock);
els.createCharacterButton.addEventListener("click", createCharacterFromForm);
els.confirmNameButton.addEventListener("click", confirmStoryName);
els.storyNameInput.addEventListener("keydown", event => {
  if (event.key === "Enter") {
    confirmStoryName();
  }
});
els.startButton.addEventListener("click", startStory);
els.nextDialogueButton.addEventListener("click", advanceDialogue);
els.battleButton.addEventListener("click", startBattleFromActivity);
els.attackButton.addEventListener("click", startAttack);
els.itemButton.addEventListener("click", useItem);
els.focusButton.addEventListener("click", focusTurn);
els.stopChargeButton.addEventListener("click", stopCharge);
els.parryButton.addEventListener("click", stopParry);
els.returnTitleButton.addEventListener("click", () => showScene("login"));
bindAvatarPreviewInputs();
