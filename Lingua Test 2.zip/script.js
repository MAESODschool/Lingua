// Lingua Prototype 1 uses small scene switches and one shared state object.
const scenes = {
  login: document.getElementById("loginScene"),
  createCharacter: document.getElementById("createCharacterScene"),
  title: document.getElementById("titleScene"),
  story: document.getElementById("storyScene"),
  battle: document.getElementById("battleScene"),
  victory: document.getElementById("victoryScene")
};

const mainStoryDialogue = [];
const DIALOGUE_SPEED = 52;
const TEACHER_DIALOGUE_SPEED = 62;
const DIALOGUE_PUNCTUATION_PAUSE = {
  ",": 150,
  "，": 150,
  ".": 280,
  "?": 320,
  "!": 320,
  "؟": 320,
  "…": 400,
  "。": 280,
  "؟": 320
};

const prologueDialogue = [
  {
    speaker: "ระบบบรรยาย",
    text: "\"นานมาแล้ว โลก Lingua เคยมีแกนกลางของภาษาเพียงหนึ่งเดียว Grammar Core คือพลังที่เชื่อมถ้อยคำ ความหมาย และเวลาเข้าด้วยกัน\""
  },
  {
    speaker: "ระบบบรรยาย",
    text: "\"แต่ในวันที่ถูกเรียกว่า The Great Error แกนกลางนั้นแตกออกเป็นเศษเสี้ยว ปัจจุบัน อดีต และอนาคตเริ่มแยกจากกัน\""
  },
  {
    speaker: "ระบบบรรยาย",
    text: "\"เมื่อชื่อของสิ่งต่าง ๆ เริ่มเลือนหาย โลกทั้งใบจึงค่อย ๆ สูญเสียความหมาย\""
  },
  {
    speaker: "ระบบบรรยาย",
    text: "\"ท่ามกลางแสงสุดท้ายของแกรมมาเรีย เด็กคนหนึ่งได้ลืมตาขึ้นในหอคอยแห่ง Unity\""
  }
];

const namingDialogue = [
  {
    speaker: "มาสเตอร์เวรีออน",
    text: "\"เจ้าตื่นขึ้นท่ามกลางเศษถ้อยคำที่แตกสลาย... แต่ก่อนที่เจ้าจะก้าวไปข้างหน้า เจ้าต้องมีชื่อเสียก่อน\""
  },
  {
    speaker: "มาสเตอร์เวรีออน",
    text: "\"บอกข้ามาเถิด ผู้พเนจร เจ้าจะให้โลก Lingua เรียกเจ้าว่าอะไร?\"",
    requiresName: true
  }
];

const interactiveStoryDialogue = [
  {
    speaker: "มาสเตอร์เวรีออน",
    text: "\"ลองดู 3 ประโยคนี้ ผู้พเนจร เธอคิดว่าประโยคใดพูดถึงอดีต?\"",
    choices: [
      {
        text: "ฉันกินข้าววันนี้",
        response: "\"ยังไม่ใช่ วันนี้คือปัจจุบัน ลองสังเกตคำบอกเวลาอีกครั้ง คำว่า 'เมื่อวาน' คือเวลาที่ผ่านไปแล้ว\""
      },
      {
        text: "ฉันกินข้าวเมื่อวาน",
        response: "\"ถูกต้อง คำว่า 'เมื่อวาน' บอกว่าเหตุการณ์นั้นเกิดขึ้นแล้ว นี่แหละคืออดีต\""
      },
      {
        text: "ฉันจะกินข้าวพรุ่งนี้",
        response: "\"ยังไม่ใช่ พรุ่งนี้คืออนาคต เพราะเป็นสิ่งที่ยังไม่เกิดขึ้น อดีตต้องเป็นเหตุการณ์ที่ผ่านไปแล้ว\""
      }
    ]
  },
  {
    speaker: "มาสเตอร์เวรีออน",
    text: "\"ภาษาไทยกับภาษาอังกฤษต่างกันอย่างไรเมื่อพูดถึงเวลา?\"",
    choices: [
      {
        text: "ภาษาไทยกริยาไม่ค่อยเปลี่ยน แต่ภาษาอังกฤษเปลี่ยนรูปกริยา",
        response: "\"ดีมาก ภาษาอังกฤษใช้รูปกริยาเพื่อบอกเวลา เราจึงต้องรู้จัก V2 เมื่อต้องเล่าเรื่องในอดีต\""
      },
      {
        text: "ภาษาอังกฤษไม่มีอดีต",
        response: "\"ยังไม่ถูก ภาษาอังกฤษมีอดีต และมักแสดงผ่านรูปกริยา เช่น go เปลี่ยนเป็น went\""
      },
      {
        text: "ภาษาไทยต้องเติม -ed เสมอ",
        response: "\"ยังไม่ใช่ -ed เป็นกฎของ Regular Verbs ในภาษาอังกฤษ ไม่ใช่กฎของภาษาไทย\""
      }
    ]
  }
];


const BOSS_ACTIONS = [
  { type: "normal", label: "โจมตีปกติ", damage: 12, warning: "บอสกำลังโจมตี!", zoneWidth: 34, minZoneWidth: 18, speed: 920, zoneSpeed: 2200, shrinkPerSecond: 4, parryDuration: 3800 },
  { type: "skill", label: "สกิลแรง", damage: 22, warning: "บอสกำลังใช้สกิลแรง!", zoneWidth: 28, minZoneWidth: 13, speed: 780, zoneSpeed: 1700, shrinkPerSecond: 5.5, parryDuration: 3400 },
  { type: "ultimate", label: "อัลติ", damage: 35, warning: "บอสกำลังใช้อัลติ! เตรียมปัดป้อง!", zoneWidth: 24, minZoneWidth: 8, speed: 650, zoneSpeed: 1250, shrinkPerSecond: 7, parryDuration: 3100 }
];

const bossQuestionBanks = {
  edForger: [
    { prompt: "study →", options: ["studied", "studyed", "studyied", "studed"], answer: "studied", explanation: "study ลงท้ายด้วยพยัญชนะ + y จึงเปลี่ยน y เป็น i แล้วเติม -ed" },
    { prompt: "love →", options: ["loved", "loveed", "lovied", "lovd"], answer: "loved", explanation: "love ลงท้ายด้วย e เติมแค่ -d" },
    { prompt: "stop →", options: ["stopped", "stoped", "stopied", "stopd"], answer: "stopped", explanation: "stop เป็นคำสั้นแบบ CVC จึงเพิ่ม p แล้วเติม -ed" },
    { prompt: "play →", options: ["played", "playied", "plaied", "playd"], answer: "played", explanation: "play มีสระ a หน้า y จึงเติม -ed ได้เลย" },
    { prompt: "prefer →", options: ["preferred", "prefered", "preferied", "preferrd"], answer: "preferred", explanation: "prefer ต้องเพิ่ม r ก่อนเติม -ed" },
    { prompt: "reply →", options: ["replied", "replyed", "replyied", "replid"], answer: "replied", explanation: "reply ลงท้ายด้วยพยัญชนะ + y จึงเปลี่ยน y เป็น i แล้วเติม -ed" }
  ],
  irregularWraith: [
    { prompt: "go →", options: ["went", "goed", "gone", "goes"], answer: "went", explanation: "go เป็น irregular verb รูป V2 คือ went" },
    { prompt: "eat →", options: ["ate", "eated", "eaten", "eats"], answer: "ate", explanation: "eat เป็น irregular verb รูป V2 คือ ate" },
    { prompt: "bring →", options: ["brought", "bringed", "brang", "brung"], answer: "brought", explanation: "bring เป็น irregular verb รูป V2 คือ brought" },
    { prompt: "teach →", options: ["taught", "teached", "teacht", "teaching"], answer: "taught", explanation: "teach เป็น irregular verb รูป V2 คือ taught" },
    { prompt: "write →", options: ["wrote", "writed", "written", "writing"], answer: "wrote", explanation: "write เป็น irregular verb รูป V2 คือ wrote" },
    { prompt: "find →", options: ["found", "finded", "founded", "finding"], answer: "found", explanation: "find เป็น irregular verb รูป V2 คือ found" }
  ],
  memoryBreaker: [
    { sentence: "Yesterday, I ____ to school.", options: ["went", "go", "goes", "going"], answer: "went", explanation: "Yesterday บอกอดีต จึงใช้ went" },
    { sentence: "She ____ English last night.", options: ["studied", "studyed", "studies", "studying"], answer: "studied", explanation: "study เปลี่ยน y เป็น i แล้วเติม -ed" },
    { sentence: "They ____ the window yesterday.", options: ["broke", "breaked", "broken", "break"], answer: "broke", explanation: "break เป็น irregular verb รูป V2 คือ broke" },
    { sentence: "My father ____ home late last night.", options: ["came", "comed", "come", "coming"], answer: "came", explanation: "come เป็น irregular verb รูป V2 คือ came" },
    { prompt: "เลือกประโยคที่ถูกต้อง", options: ["I studied English last night.", "I studyed English last night.", "I studying English last night.", "I studies English last night."], answer: "I studied English last night.", explanation: "ประโยคอดีตใช้ V2 และ study เป็น studied" },
    { prompt: "choose →", options: ["chose", "choosed", "chosen", "choosing"], answer: "chose", explanation: "choose เป็น irregular verb รูป V2 คือ chose" },
    { prompt: "drop →", options: ["dropped", "droped", "dropd", "dropied"], answer: "dropped", explanation: "drop ต้องเพิ่ม p ก่อนเติม -ed" },
    { sentence: "He ____ his homework this morning.", options: ["did", "do", "does", "doing"], answer: "did", explanation: "this morning ถ้าเหตุการณ์จบแล้วถือเป็นอดีต ใช้ did" }
  ]
};

const bossActionPatterns = {
  edForger: [["attack"], ["question"], ["question", "attack"], ["attack"]],
  irregularWraith: [["question"], ["attack"], ["question", "attack"], ["attack", "question"], ["question"]],
  memoryBreaker: [["question", "attack"], ["attack", "question"], ["question", "attack", "question"], ["question", "question", "attack"]]
};

const bossDifficultyWeights = {
  edForger: { medium: 60, hard: 30, boss: 10 },
  irregularWraith: { medium: 35, hard: 40, boss: 25 },
  memoryBreaker: { medium: 15, hard: 35, boss: 50 }
};

function bossQuestion(config) {
  return {
    id: config.id,
    boss: config.boss,
    difficulty: config.difficulty,
    type: config.type,
    baseVerb: config.baseVerb,
    prompt: config.prompt,
    sentence: config.sentence,
    options: config.options,
    answer: config.answer,
    explanation: config.explanation
  };
}

function buildEdForgerQuestions() {
  const items = [
    ["ed_001", "medium", "regular-ed", "walk", "walk ->", ["walked", "walkd", "walkked", "walkied"], "walked", "คำทั่วไปเติม -ed เป็น walked"],
    ["ed_002", "medium", "regular-ed", "clean", "clean ->", ["cleaned", "cleand", "cleanned", "cleanied"], "cleaned", "คำทั่วไปเติม -ed เป็น cleaned"],
    ["ed_003", "medium", "regular-ed", "help", "help ->", ["helped", "helpd", "helpped", "helpied"], "helped", "คำทั่วไปเติม -ed เป็น helped"],
    ["ed_004", "medium", "regular-ed", "watch", "watch ->", ["watched", "watchd", "watcheed", "watchied"], "watched", "คำทั่วไปเติม -ed เป็น watched"],
    ["ed_005", "medium", "ending-e", "love", "love ->", ["loved", "loveed", "lovied", "lovd"], "loved", "คำที่ลงท้ายด้วย e เติมแค่ -d"],
    ["ed_006", "medium", "ending-e", "like", "like ->", ["liked", "likeed", "likied", "likd"], "liked", "คำที่ลงท้ายด้วย e เติมแค่ -d"],
    ["ed_007", "medium", "ending-e", "move", "move ->", ["moved", "moveed", "movied", "movd"], "moved", "คำที่ลงท้ายด้วย e เติมแค่ -d"],
    ["ed_008", "medium", "ending-e", "dance", "dance ->", ["danced", "danceed", "dancied", "dancd"], "danced", "คำที่ลงท้ายด้วย e เติมแค่ -d"],
    ["ed_009", "medium", "vowel-y", "play", "play ->", ["played", "playied", "plaied", "playd"], "played", "หน้า y เป็นสระ จึงเติม -ed ได้เลย"],
    ["ed_010", "medium", "vowel-y", "enjoy", "enjoy ->", ["enjoyed", "enjoied", "enjoyd", "enjoyied"], "enjoyed", "หน้า y เป็นสระ จึงเติม -ed ได้เลย"],
    ["ed_011", "medium", "consonant-y", "study", "study ->", ["studied", "studyed", "studyied", "studed"], "studied", "พยัญชนะ + y เปลี่ยน y เป็น i แล้วเติม -ed"],
    ["ed_012", "medium", "consonant-y", "try", "try ->", ["tried", "tryed", "tryied", "trid"], "tried", "พยัญชนะ + y เปลี่ยน y เป็น i แล้วเติม -ed"],
    ["ed_013", "medium", "consonant-y", "reply", "reply ->", ["replied", "replyed", "replyied", "replid"], "replied", "พยัญชนะ + y เปลี่ยน y เป็น i แล้วเติม -ed"],
    ["ed_014", "medium", "regular-ed", "visit", "visit ->", ["visited", "visitted", "visitd", "visitied"], "visited", "visit ไม่เน้นเสียงท้ายแบบ CVC จึงเติม -ed ปกติ"],
    ["ed_015", "medium", "regular-ed", "open", "open ->", ["opened", "openned", "opend", "openied"], "opened", "open ไม่ต้องเพิ่ม n ก่อนเติม -ed"],
    ["ed_016", "medium", "regular-ed", "listen", "listen ->", ["listened", "listenned", "listend", "listenied"], "listened", "listen เติม -ed ปกติ"],
    ["ed_017", "hard", "cvc-double", "stop", "stop ->", ["stopped", "stoped", "stopied", "stopd"], "stopped", "คำสั้น CVC ต้องเพิ่มพยัญชนะท้ายก่อนเติม -ed"],
    ["ed_018", "hard", "cvc-double", "plan", "plan ->", ["planned", "planed", "planied", "pland"], "planned", "คำสั้น CVC ต้องเพิ่ม n ก่อนเติม -ed"],
    ["ed_019", "hard", "cvc-double", "drop", "drop ->", ["dropped", "droped", "dropd", "dropied"], "dropped", "คำสั้น CVC ต้องเพิ่ม p ก่อนเติม -ed"],
    ["ed_020", "hard", "cvc-double", "grab", "grab ->", ["grabbed", "grabed", "grabied", "grabd"], "grabbed", "คำสั้น CVC ต้องเพิ่ม b ก่อนเติม -ed"],
    ["ed_021", "hard", "cvc-double", "skip", "skip ->", ["skipped", "skiped", "skipd", "skipied"], "skipped", "คำสั้น CVC ต้องเพิ่ม p ก่อนเติม -ed"],
    ["ed_022", "hard", "final-stress", "prefer", "prefer ->", ["preferred", "prefered", "preferied", "preferrd"], "preferred", "prefer เน้นเสียงท้าย จึงเพิ่ม r ก่อนเติม -ed"],
    ["ed_023", "hard", "final-stress", "refer", "refer ->", ["referred", "refered", "referied", "referrd"], "referred", "refer เน้นเสียงท้าย จึงเพิ่ม r ก่อนเติม -ed"],
    ["ed_024", "hard", "final-stress", "occur", "occur ->", ["occurred", "occured", "occuried", "occurrd"], "occurred", "occur เน้นเสียงท้าย จึงเพิ่ม r ก่อนเติม -ed"],
    ["ed_025", "hard", "no-final-stress", "travel", "travel ->", ["traveled", "travelled", "traveld", "travelied"], "traveled", "ใช้รูป American English: traveled"],
    ["ed_026", "hard", "no-final-stress", "offer", "offer ->", ["offered", "offerred", "offerd", "offeried"], "offered", "offer ไม่เน้นเสียงท้าย จึงเติม -ed ปกติ"],
    ["ed_027", "hard", "ending-e", "decide", "decide ->", ["decided", "decideed", "decidied", "decidd"], "decided", "ลงท้าย e เติม -d เป็น decided"],
    ["ed_028", "hard", "ending-e", "practice", "practice ->", ["practiced", "practiceed", "practicied", "practicd"], "practiced", "ลงท้าย e เติม -d เป็น practiced"],
    ["ed_029", "boss", "mixed-rule", "study", "Which word changes y to i before -ed?", ["study", "play", "enjoy", "stay"], "study", "study ลงท้ายด้วยพยัญชนะ + y จึงเปลี่ยน y เป็น i"],
    ["ed_030", "boss", "mixed-rule", "stop", "Which word doubles the final consonant?", ["stop", "open", "visit", "clean"], "stop", "stop เป็นคำสั้น CVC จึงเพิ่ม p"],
    ["ed_031", "boss", "mixed-rule", "stop", "Which answer is correct?", ["I stopped at the tower.", "I stoped at the tower.", "I stopied at the tower.", "I stopd at the tower."], "I stopped at the tower.", "stop ต้องเป็น stopped"],
    ["ed_032", "boss", "mixed-rule", "study", "Which answer is correct?", ["She studied the rune.", "She studyed the rune.", "She studyied the rune.", "She studed the rune."], "She studied the rune.", "study ต้องเป็น studied"],
    ["ed_033", "boss", "mixed-rule", "open", "Which answer is correct?", ["They opened the gate.", "They openned the gate.", "They openied the gate.", "They opend the gate."], "They opened the gate.", "open เติม -ed ปกติ"],
    ["ed_034", "boss", "mixed-rule", "prefer", "Which answer is correct?", ["He preferred the blue crystal.", "He prefered the blue crystal.", "He preferrd the blue crystal.", "He preferied the blue crystal."], "He preferred the blue crystal.", "prefer ต้องเป็น preferred"],
    ["ed_035", "boss", "mixed-rule", "arrive ->", ["arrived", "arriveed", "arrivied", "arrivd"], "arrived", "arrive ลงท้าย e เติม -d"],
    ["ed_036", "boss", "mixed-rule", "carry ->", ["carried", "carryed", "carryied", "carryd"], "carried", "พยัญชนะ + y เปลี่ยน y เป็น i แล้วเติม -ed"]
  ];

  return items.map(item => bossQuestion({
    id: item[0],
    boss: "edForger",
    difficulty: item[1],
    type: item[2],
    baseVerb: item[3],
    prompt: item[4],
    options: item[5],
    answer: item[6],
    explanation: item[7]
  }));
}

function buildIrregularWraithQuestions() {
  const verbs = [
    ["ir_001", "medium", "go", "go ->", ["went", "goed", "gone", "goes"], "went"],
    ["ir_002", "medium", "eat", "eat ->", ["ate", "eated", "eaten", "eats"], "ate"],
    ["ir_003", "medium", "see", "see ->", ["saw", "seed", "seen", "sees"], "saw"],
    ["ir_004", "medium", "come", "come ->", ["came", "comed", "come", "coming"], "came"],
    ["ir_005", "medium", "buy", "buy ->", ["bought", "buyed", "brought", "buying"], "bought"],
    ["ir_006", "medium", "bring", "bring ->", ["brought", "bringed", "brang", "brung"], "brought"],
    ["ir_007", "medium", "teach", "teach ->", ["taught", "teached", "teacht", "teaching"], "taught"],
    ["ir_008", "medium", "think", "think ->", ["thought", "thinked", "thunk", "thinking"], "thought"],
    ["ir_009", "medium", "write", "write ->", ["wrote", "writed", "written", "writing"], "wrote"],
    ["ir_010", "medium", "find", "find ->", ["found", "finded", "founded", "finding"], "found"],
    ["ir_011", "medium", "make", "make ->", ["made", "maked", "makeed", "making"], "made"],
    ["ir_012", "medium", "take", "take ->", ["took", "taked", "taken", "taking"], "took"],
    ["ir_013", "medium", "give", "give ->", ["gave", "gived", "given", "giving"], "gave"],
    ["ir_014", "medium", "speak", "speak ->", ["spoke", "speaked", "spoken", "speaking"], "spoke"],
    ["ir_015", "hard", "break", "break ->", ["broke", "breaked", "broken", "break"], "broke"],
    ["ir_016", "hard", "choose", "choose ->", ["chose", "choosed", "chosen", "choosing"], "chose"],
    ["ir_017", "hard", "drive", "drive ->", ["drove", "drived", "driven", "driving"], "drove"],
    ["ir_018", "hard", "forget", "forget ->", ["forgot", "forgetted", "forgotten", "forget"], "forgot"],
    ["ir_019", "hard", "hide", "hide ->", ["hid", "hided", "hidden", "hiding"], "hid"],
    ["ir_020", "hard", "keep", "keep ->", ["kept", "keeped", "keeping", "keept"], "kept"],
    ["ir_021", "hard", "leave", "leave ->", ["left", "leaved", "leaving", "leaves"], "left"],
    ["ir_022", "hard", "lose", "lose ->", ["lost", "losed", "losing", "loosed"], "lost"],
    ["ir_023", "hard", "meet", "meet ->", ["met", "meeted", "meeting", "meat"], "met"],
    ["ir_024", "hard", "pay", "pay ->", ["paid", "payed", "payd", "paying"], "paid"],
    ["ir_025", "hard", "read", "read ->", ["read", "readed", "rode", "reading"], "read"],
    ["ir_026", "hard", "ride", "ride ->", ["rode", "rided", "ridden", "riding"], "rode"],
    ["ir_027", "hard", "rise", "rise ->", ["rose", "rised", "risen", "rising"], "rose"],
    ["ir_028", "hard", "sell", "sell ->", ["sold", "selled", "selling", "salled"], "sold"],
    ["ir_029", "hard", "send", "send ->", ["sent", "sended", "sending", "send"], "sent"],
    ["ir_030", "hard", "shake", "shake ->", ["shook", "shaked", "shaken", "shaking"], "shook"],
    ["ir_031", "boss", "steal", "steal ->", ["stole", "stealed", "stolen", "stealing"], "stole"],
    ["ir_032", "boss", "swim", "swim ->", ["swam", "swimmed", "swum", "swimming"], "swam"],
    ["ir_033", "boss", "throw", "throw ->", ["threw", "throwed", "thrown", "throwing"], "threw"],
    ["ir_034", "boss", "wear", "wear ->", ["wore", "weared", "worn", "wearing"], "wore"],
    ["ir_035", "boss", "win", "win ->", ["won", "winned", "winning", "wan"], "won"],
    ["ir_036", "boss", "begin", "begin ->", ["began", "beginned", "begun", "beginning"], "began"],
    ["ir_037", "boss", "fall", "fall ->", ["fell", "falled", "fallen", "falling"], "fell"],
    ["ir_038", "boss", "fly", "fly ->", ["flew", "flyed", "flown", "flying"], "flew"],
    ["ir_039", "boss", "grow", "grow ->", ["grew", "growed", "grown", "growing"], "grew"],
    ["ir_040", "boss", "hold", "hold ->", ["held", "holded", "holding", "hald"], "held"]
  ];

  return verbs.map(item => bossQuestion({
    id: item[0],
    boss: "irregularWraith",
    difficulty: item[1],
    type: "irregular-v2",
    baseVerb: item[2],
    prompt: item[3],
    options: item[4],
    answer: item[5],
    explanation: `${item[2]} เป็น Irregular Verb รูป V2 คือ ${item[5]}`
  }));
}

function buildMemoryBreakerQuestions() {
  const items = [
    ["mb_001", "medium", "sentence", "go", "Yesterday, I ____ to school.", ["went", "go", "goes", "going"], "went", "Yesterday บอกอดีต จึงใช้ went"],
    ["mb_002", "medium", "sentence", "study", "She ____ English last night.", ["studied", "studyed", "studies", "studying"], "studied", "last night บอกอดีต และ study เป็น studied"],
    ["mb_003", "medium", "sentence", "play", "They ____ football yesterday.", ["played", "play", "plays", "playing"], "played", "yesterday บอกอดีต จึงใช้ played"],
    ["mb_004", "medium", "sentence", "come", "My father ____ home late last night.", ["came", "comed", "come", "coming"], "came", "come เป็น Irregular Verb รูป V2 คือ came"],
    ["mb_005", "medium", "choose-correct", "study", "Choose the correct sentence.", ["I studied English last night.", "I studyed English last night.", "I studying English last night.", "I studies English last night."], "I studied English last night.", "ประโยคอดีตใช้ V2 และ study เป็น studied"],
    ["mb_006", "medium", "irregular-v2", "choose", "choose ->", ["chose", "choosed", "chosen", "choosing"], "chose", "choose เป็น Irregular Verb รูป V2 คือ chose"],
    ["mb_007", "medium", "regular-ed", "drop", "drop ->", ["dropped", "droped", "dropd", "dropied"], "dropped", "drop เป็น CVC จึงเพิ่ม p แล้วเติม -ed"],
    ["mb_008", "medium", "sentence", "do", "He ____ his homework this morning.", ["did", "do", "does", "doing"], "did", "this morning เมื่อเหตุการณ์จบแล้ว ใช้ did"],
    ["mb_009", "hard", "sentence", "break", "They ____ the window yesterday.", ["broke", "breaked", "broken", "break"], "broke", "break เป็น Irregular Verb รูป V2 คือ broke"],
    ["mb_010", "hard", "sentence", "prefer", "The scholar ____ the blue crystal.", ["preferred", "prefered", "preferied", "preferrd"], "preferred", "prefer เน้นเสียงท้าย จึงเพิ่ม r ก่อนเติม -ed"],
    ["mb_011", "hard", "sentence", "visit", "We ____ the Unity Tower last week.", ["visited", "visitted", "visit", "visitied"], "visited", "visit เติม -ed ปกติ"],
    ["mb_012", "hard", "sentence", "write", "The Wanderer ____ a note yesterday.", ["wrote", "writed", "written", "writing"], "wrote", "write เป็น Irregular Verb รูป V2 คือ wrote"],
    ["mb_013", "hard", "did-base", "go", "Did she ____ to the library yesterday?", ["go", "went", "goes", "going"], "go", "หลัง did ต้องใช้กริยาช่อง 1"],
    ["mb_014", "hard", "did-base", "eat", "Did they ____ breakfast this morning?", ["eat", "ate", "eated", "eaten"], "eat", "หลัง did ต้องใช้กริยาช่อง 1"],
    ["mb_015", "hard", "negative", "see", "I did not ____ the Memory Shade.", ["see", "saw", "seen", "seeing"], "see", "หลัง did not ต้องใช้กริยาช่อง 1"],
    ["mb_016", "hard", "negative", "make", "She did not ____ a mistake.", ["make", "made", "maked", "making"], "make", "หลัง did not ต้องใช้กริยาช่อง 1"],
    ["mb_017", "hard", "choose-correct", "go", "Choose the correct sentence.", ["Did you go yesterday?", "Did you went yesterday?", "Did you goes yesterday?", "Did you going yesterday?"], "Did you go yesterday?", "คำถามที่ใช้ did ต้องตามด้วยกริยาช่อง 1"],
    ["mb_018", "hard", "choose-correct", "see", "Choose the correct sentence.", ["I saw the tower yesterday.", "I seed the tower yesterday.", "I seen the tower yesterday.", "I seeing the tower yesterday."], "I saw the tower yesterday.", "see รูป V2 คือ saw"],
    ["mb_019", "hard", "mixed-rule", "study", "Which one is Past Simple?", ["studied", "studies", "studying", "study"], "studied", "studied เป็นรูปอดีตของ study"],
    ["mb_020", "hard", "mixed-rule", "take", "Which one is V2?", ["took", "taken", "take", "taking"], "took", "take รูป V2 คือ took"],
    ["mb_021", "hard", "sentence", "stop", "The clock ____ suddenly.", ["stopped", "stoped", "stop", "stopping"], "stopped", "stop เป็น CVC จึงเพิ่ม p แล้วเติม -ed"],
    ["mb_022", "hard", "sentence", "arrive", "Master Verion ____ before sunset.", ["arrived", "arriveed", "arrivied", "arrivd"], "arrived", "arrive ลงท้าย e เติม -d"],
    ["mb_023", "hard", "sentence", "bring", "The student ____ a book yesterday.", ["brought", "bringed", "brang", "bringing"], "brought", "bring รูป V2 คือ brought"],
    ["mb_024", "hard", "sentence", "teach", "Master Verion ____ the past tense.", ["taught", "teached", "teacht", "teaching"], "taught", "teach รูป V2 คือ taught"],
    ["mb_025", "boss", "sentence", "forget", "The shade ____ its name long ago.", ["forgot", "forgetted", "forgotten", "forget"], "forgot", "forget รูป V2 คือ forgot"],
    ["mb_026", "boss", "sentence", "hide", "The fragment ____ inside the tower.", ["hid", "hided", "hidden", "hiding"], "hid", "hide รูป V2 คือ hid"],
    ["mb_027", "boss", "sentence", "rise", "A purple light ____ from the floor.", ["rose", "rised", "risen", "rising"], "rose", "rise รูป V2 คือ rose"],
    ["mb_028", "boss", "sentence", "throw", "The wraith ____ a broken rune.", ["threw", "throwed", "thrown", "throwing"], "threw", "throw รูป V2 คือ threw"],
    ["mb_029", "boss", "sentence", "open", "The gate ____ after the spell.", ["opened", "openned", "open", "openied"], "opened", "open เติม -ed ปกติ"],
    ["mb_030", "boss", "sentence", "refer", "The book ____ to an ancient error.", ["referred", "refered", "referied", "referrd"], "referred", "refer เน้นเสียงท้าย จึงเพิ่ม r"],
    ["mb_031", "boss", "did-base", "write", "Did the Wanderer ____ the answer?", ["write", "wrote", "written", "writing"], "write", "หลัง did ต้องใช้กริยาช่อง 1"],
    ["mb_032", "boss", "did-base", "choose", "Did you ____ the correct charm?", ["choose", "chose", "chosen", "choosing"], "choose", "หลัง did ต้องใช้กริยาช่อง 1"],
    ["mb_033", "boss", "negative", "bring", "They did not ____ the old map.", ["bring", "brought", "bringed", "bringing"], "bring", "หลัง did not ต้องใช้กริยาช่อง 1"],
    ["mb_034", "boss", "negative", "take", "He did not ____ the crystal.", ["take", "took", "taken", "taking"], "take", "หลัง did not ต้องใช้กริยาช่อง 1"],
    ["mb_035", "boss", "choose-correct", "break", "Choose the correct sentence.", ["The crystal broke yesterday.", "The crystal breaked yesterday.", "The crystal broken yesterday.", "The crystal breaking yesterday."], "The crystal broke yesterday.", "break รูป V2 คือ broke"],
    ["mb_036", "boss", "choose-correct", "prefer", "Choose the correct sentence.", ["She preferred the blue rune.", "She prefered the blue rune.", "She preferied the blue rune.", "She preferrd the blue rune."], "She preferred the blue rune.", "prefer ต้องเป็น preferred"],
    ["mb_037", "boss", "choose-correct", "did-base", "Choose the correct sentence.", ["Did he make a shield?", "Did he made a shield?", "Did he makes a shield?", "Did he making a shield?"], "Did he make a shield?", "หลัง did ต้องใช้กริยาช่อง 1"],
    ["mb_038", "boss", "mixed-rule", "sell", "Which one is V2?", ["sold", "selled", "selling", "sell"], "sold", "sell รูป V2 คือ sold"],
    ["mb_039", "boss", "mixed-rule", "travel", "Which spelling is correct?", ["traveled", "travelled", "traveld", "travelied"], "traveled", "ใช้รูป American English: traveled"],
    ["mb_040", "boss", "mixed-rule", "carry", "carry ->", ["carried", "carryed", "carryied", "carryd"], "carried", "พยัญชนะ + y เปลี่ยน y เป็น i แล้วเติม -ed"],
    ["mb_041", "boss", "sentence", "swim", "The boy ____ across the river.", ["swam", "swimmed", "swum", "swimming"], "swam", "swim รูป V2 คือ swam"],
    ["mb_042", "boss", "sentence", "fly", "The letters ____ above the tower.", ["flew", "flyed", "flown", "flying"], "flew", "fly รูป V2 คือ flew"],
    ["mb_043", "boss", "sentence", "win", "The team ____ the match last week.", ["won", "winned", "winning", "win"], "won", "win รูป V2 คือ won"],
    ["mb_044", "boss", "sentence", "pay", "She ____ for the book yesterday.", ["paid", "payed", "payd", "paying"], "paid", "pay รูป V2 คือ paid"],
    ["mb_045", "boss", "sentence", "shake", "The tower ____ during the error.", ["shook", "shaked", "shaken", "shaking"], "shook", "shake รูป V2 คือ shook"],
    ["mb_046", "boss", "sentence", "leave", "They ____ before the bell.", ["left", "leaved", "leaving", "leaves"], "left", "leave รูป V2 คือ left"],
    ["mb_047", "boss", "sentence", "read", "I ____ the old scroll yesterday.", ["read", "readed", "rode", "reading"], "read", "read รูป V2 เขียนเหมือนเดิม แต่ออกเสียงต่างกัน"],
    ["mb_048", "boss", "sentence", "begin", "The battle ____ at dawn.", ["began", "beginned", "begun", "beginning"], "began", "begin รูป V2 คือ began"]
  ];

  return items.map(item => bossQuestion({
    id: item[0],
    boss: "memoryBreaker",
    difficulty: item[1],
    type: item[2],
    baseVerb: item[3],
    prompt: item[4].includes("____") ? undefined : item[4],
    sentence: item[4].includes("____") ? item[4] : undefined,
    options: item[5],
    answer: item[6],
    explanation: item[7]
  }));
}

bossQuestionBanks.edForger = buildEdForgerQuestions();
bossQuestionBanks.irregularWraith = buildIrregularWraithQuestions();
bossQuestionBanks.memoryBreaker = buildMemoryBreakerQuestions();

const TENSE_LABELS = {
  present: "Present (ปัจจุบัน)",
  past: "Past (อดีต)",
  future: "Future (อนาคต)"
};

const regularVerbBanks = {
  addEd: [
    ["walk", "walked", ["walkd", "walkked", "walkied"]],
    ["jump", "jumped", ["jumpd", "jumpped", "jumpied"]],
    ["help", "helped", ["helpd", "helpped", "helpied"]],
    ["watch", "watched", ["watchd", "watcheed", "watchied"]],
    ["open", "opened", ["opend", "openned", "openied"]],
    ["clean", "cleaned", ["cleand", "cleanned", "cleanied"]],
    ["finish", "finished", ["finishd", "finisheed", "finishied"]],
    ["answer", "answered", ["answerd", "answereed", "answeried"]],
    ["listen", "listened", ["listend", "listenned", "listenied"]],
    ["visit", "visited", ["visitd", "visitted", "visitied"]],
    ["collect", "collected", ["collectd", "collectted", "collectied"]],
    ["explain", "explained", ["explaind", "explainned", "explainied"]],
    ["return", "returned", ["returnd", "returnned", "returnied"]],
    ["repair", "repaired", ["repaird", "repairred", "repairied"]],
    ["remember", "remembered", ["rememberd", "rememberred", "rememberied"]]
  ],
  endingE: [
    ["like", "liked", ["likeed", "likied", "likd"]],
    ["love", "loved", ["loveed", "lovied", "lovd"]],
    ["live", "lived", ["liveed", "livied", "livd"]],
    ["dance", "danced", ["danceed", "dancied", "dancd"]],
    ["close", "closed", ["closeed", "closied", "closd"]],
    ["move", "moved", ["moveed", "movied", "movd"]],
    ["decide", "decided", ["decideed", "decidied", "decidd"]],
    ["arrive", "arrived", ["arriveed", "arrivied", "arrivd"]],
    ["create", "created", ["createed", "creatied", "creatd"]],
    ["practice", "practiced", ["practiceed", "practicied", "practicd"]],
    ["receive", "received", ["receiveed", "receivied", "receivd"]],
    ["hope", "hoped", ["hopeed", "hopied", "hopd"]]
  ],
  endingY: [
    ["play", "played", ["playied", "plaied", "playd"], "หน้า y เป็นสระ จึงเติม -ed ได้เลย"],
    ["enjoy", "enjoyed", ["enjoied", "enjoyd", "enjoyied"], "หน้า y เป็นสระ จึงเติม -ed ได้เลย"],
    ["stay", "stayed", ["staied", "stayd", "stayied"], "หน้า y เป็นสระ จึงเติม -ed ได้เลย"],
    ["obey", "obeyed", ["obeied", "obeyd", "obeyied"], "หน้า y เป็นสระ จึงเติม -ed ได้เลย"],
    ["delay", "delayed", ["delaied", "delayd", "delayied"], "หน้า y เป็นสระ จึงเติม -ed ได้เลย"],
    ["study", "studied", ["studyed", "studyied", "studed"], "หน้า y เป็นพยัญชนะ จึงเปลี่ยน y เป็น i แล้วเติม -ed"],
    ["cry", "cried", ["cryed", "cryied", "cryd"], "หน้า y เป็นพยัญชนะ จึงเปลี่ยน y เป็น i แล้วเติม -ed"],
    ["try", "tried", ["tryed", "tryied", "tryd"], "หน้า y เป็นพยัญชนะ จึงเปลี่ยน y เป็น i แล้วเติม -ed"],
    ["carry", "carried", ["carryed", "carryied", "carred"], "หน้า y เป็นพยัญชนะ จึงเปลี่ยน y เป็น i แล้วเติม -ed"],
    ["copy", "copied", ["copyed", "copyied", "copd"], "หน้า y เป็นพยัญชนะ จึงเปลี่ยน y เป็น i แล้วเติม -ed"],
    ["hurry", "hurried", ["hurryed", "hurryied", "hurred"], "หน้า y เป็นพยัญชนะ จึงเปลี่ยน y เป็น i แล้วเติม -ed"],
    ["worry", "worried", ["worryed", "worryied", "worred"], "หน้า y เป็นพยัญชนะ จึงเปลี่ยน y เป็น i แล้วเติม -ed"],
    ["reply", "replied", ["replyed", "replyied", "repled"], "หน้า y เป็นพยัญชนะ จึงเปลี่ยน y เป็น i แล้วเติม -ed"],
    ["apply", "applied", ["applyed", "applyied", "appled"], "หน้า y เป็นพยัญชนะ จึงเปลี่ยน y เป็น i แล้วเติม -ed"]
  ],
  doubleCvc: [
    ["stop", "stopped", ["stoped", "stopied", "stopd"]],
    ["plan", "planned", ["planed", "planied", "pland"]],
    ["drop", "dropped", ["droped", "dropd", "dropied"]],
    ["clap", "clapped", ["claped", "clapd", "clapied"]],
    ["grab", "grabbed", ["grabed", "grabd", "grabied"]],
    ["hug", "hugged", ["huged", "hugd", "hugied"]],
    ["travel", "traveled", ["traveleded", "travelled", "travelied"]],
    ["prefer", "preferred", ["prefered", "preferd", "preferied"]],
    ["admit", "admitted", ["admited", "admitd", "admitied"]],
    ["occur", "occurred", ["occured", "occurd", "occuried"]]
  ]
};

function makeRegularQuestion([verb, answer, distractors, note], ruleText) {
  return {
    prompt: `${verb} ->`,
    options: [answer, ...distractors],
    answer,
    explanation: `${verb} ในรูปอดีตที่ถูกต้องคือ ${answer}${note ? ` เพราะ${note}` : ` เพราะ${ruleText}`}`
  };
}

const regularRuleOneQuestions = regularVerbBanks.addEd
  .slice(0, 8)
  .map(item => makeRegularQuestion(item, "คำกริยาทั่วไปเติม -ed"));

const regularRuleTwoQuestions = regularVerbBanks.endingE
  .slice(0, 8)
  .map(item => makeRegularQuestion(item, "คำลงท้ายด้วย e เติมแค่ -d"));

const regularRuleThreeQuestions = regularVerbBanks.endingY
  .slice(0, 10)
  .map(item => makeRegularQuestion(item, "ต้องดูตัวอักษรก่อน y"));

const regularRuleFourQuestions = regularVerbBanks.doubleCvc
  .slice(0, 8)
  .map(item => makeRegularQuestion(item, "คำสั้นบางคำเพิ่มพยัญชนะท้ายก่อนเติม -ed"));

const edForgerQuestions = [
  ...regularVerbBanks.addEd.slice(0, 6),
  ...regularVerbBanks.endingE.slice(0, 5),
  ...regularVerbBanks.endingY.slice(0, 7),
  ...regularVerbBanks.doubleCvc.slice(0, 7)
].map(item => makeRegularQuestion(item, "เลือกการสะกดรูปอดีตที่ถูกต้อง"));

const irregularVerbBank = [
  ["go", "went", ["goed", "goes", "gone"]],
  ["eat", "ate", ["eated", "eats", "eaten"]],
  ["see", "saw", ["seed", "seen", "seeed"]],
  ["buy", "bought", ["buyed", "buys", "buyt"]],
  ["take", "took", ["taked", "taken", "takeded"]],
  ["come", "came", ["comed", "comes", "comeed"]],
  ["have", "had", ["haved", "has", "hadded"]],
  ["do", "did", ["doed", "does", "doeded"]],
  ["make", "made", ["maked", "makes", "makeed"]],
  ["write", "wrote", ["writed", "written", "writeed"]],
  ["meet", "met", ["meeted", "meets", "meted"]],
  ["choose", "chose", ["choosed", "chosen", "chooseed"]],
  ["read", "read", ["readed", "reads", "readinged"]],
  ["give", "gave", ["gived", "given", "giveed"]],
  ["get", "got", ["getted", "gets", "geted"]],
  ["speak", "spoke", ["speaked", "spoken", "speeked"]],
  ["break", "broke", ["breaked", "broken", "breakked"]],
  ["bring", "brought", ["bringed", "brang", "bringted"]],
  ["think", "thought", ["thinked", "thunk", "thinkted"]],
  ["teach", "taught", ["teached", "teacht", "teachted"]],
  ["catch", "caught", ["catched", "catcht", "catchted"]],
  ["find", "found", ["finded", "founded", "findted"]],
  ["leave", "left", ["leaved", "leaveded", "leavet"]],
  ["feel", "felt", ["feeled", "feelt", "feeld"]],
  ["keep", "kept", ["keeped", "keept", "keepied"]],
  ["hear", "heard", ["heared", "heart", "hearded"]],
  ["lose", "lost", ["losed", "loosed", "loset"]],
  ["send", "sent", ["sended", "sendted", "sendeded"]],
  ["spend", "spent", ["spended", "spendted", "spendeded"]],
  ["build", "built", ["builded", "buildted", "buildied"]]
];

function makeIrregularQuestion([verb, answer, distractors]) {
  return {
    prompt: `${verb} ->`,
    options: [answer, ...distractors],
    answer,
    explanation: `${verb} เป็น Irregular Verb รูป V2 คือ ${answer}`
  };
}

const irregularPracticeQuestions = [
  ...irregularVerbBank.slice(0, 8).map(makeIrregularQuestion),
  { sentence: "Yesterday, I ____ to school.", options: ["went", "goed", "goes", "going"], answer: "went", explanation: "Yesterday บอกอดีต จึงใช้ went" }
];

const irregularWraithQuestions = irregularVerbBank
  .slice(0, 20)
  .map(makeIrregularQuestion);

const finalBossQuestions = [
  makeRegularQuestion(regularVerbBanks.addEd[8], "คำกริยาทั่วไปเติม -ed"),
  makeRegularQuestion(regularVerbBanks.endingE[7], "คำลงท้ายด้วย e เติมแค่ -d"),
  makeRegularQuestion(regularVerbBanks.endingY[9], "หน้า y เป็นพยัญชนะ เปลี่ยน y เป็น i แล้วเติม -ed"),
  makeRegularQuestion(regularVerbBanks.doubleCvc[7], "เพิ่มพยัญชนะท้ายก่อนเติม -ed"),
  makeIrregularQuestion(irregularVerbBank[8]),
  makeIrregularQuestion(irregularVerbBank[9]),
  makeIrregularQuestion(irregularVerbBank[11]),
  makeIrregularQuestion(irregularVerbBank[16]),
  { type: "sentence-fill", sentence: "Yesterday, I ____ to school.", options: ["went", "go", "goes", "going"], answer: "went", explanation: "Yesterday บอกอดีต จึงต้องใช้ V2 คือ went" },
  { type: "sentence-fill", sentence: "Last night, she ____ a movie.", options: ["watched", "watch", "watches", "watching"], answer: "watched", explanation: "Last night บอกอดีต และ watch เป็น Regular Verb เติม -ed เป็น watched" },
  { type: "sentence-fill", sentence: "Two days ago, we ____ dinner together.", options: ["ate", "eat", "eats", "eating"], answer: "ate", explanation: "eat เป็น Irregular Verb รูป V2 คือ ate" },
  { type: "sentence-fill", sentence: "Last week, he ____ a new book.", options: ["bought", "buy", "buys", "buying"], answer: "bought", explanation: "buy เป็น Irregular Verb รูป V2 คือ bought" },
  { type: "sentence-fill", sentence: "My mother ____ breakfast this morning.", options: ["cooked", "cook", "cooks", "cooking"], answer: "cooked", explanation: "ถ้าเหตุการณ์เมื่อเช้าจบแล้ว ถือเป็นอดีต จึงใช้ cooked" },
  { type: "sentence-fill", sentence: "He ____ his homework last night.", options: ["did", "do", "does", "doing"], answer: "did", explanation: "do เป็น Irregular Verb รูป V2 คือ did" },
  { type: "sentence-fill", sentence: "They ____ English yesterday.", options: ["studied", "studyed", "study", "studying"], answer: "studied", explanation: "study เปลี่ยน y เป็น i แล้วเติม -ed เป็น studied" },
  { type: "correct-sentence", prompt: "เลือกประโยคที่ถูกต้อง", options: ["Yesterday, I went to school.", "Yesterday, I go to school.", "Yesterday, I goes to school.", "Yesterday, I going to school."], answer: "Yesterday, I went to school.", explanation: "Yesterday บอกอดีต จึงต้องใช้ went" },
  { type: "correct-sentence", prompt: "เลือกประโยคที่ถูกต้อง", options: ["Last night, she saw a bird.", "Last night, she see a bird.", "Last night, she sees a bird.", "Last night, she seeing a bird."], answer: "Last night, she saw a bird.", explanation: "see ในรูป V2 คือ saw" },
  { type: "correct-sentence", prompt: "เลือกประโยคที่ถูกต้อง", options: ["We watched TV yesterday.", "We watch TV yesterday.", "We watches TV yesterday.", "We watching TV yesterday."], answer: "We watched TV yesterday.", explanation: "watch ใช้ในอดีตเป็น watched" },
  { type: "correct-sentence", prompt: "เลือกประโยคที่ถูกต้อง", options: ["I studied English last night.", "I studyed English last night.", "I studying English last night.", "I studies English last night."], answer: "I studied English last night.", explanation: "study ต้องเปลี่ยน y เป็น i แล้วเติม -ed เป็น studied" },
  { type: "sentence-fill", sentence: "She ____ her old friend yesterday.", options: ["met", "meet", "meets", "meeting"], answer: "met", explanation: "meet เป็น Irregular Verb รูป V2 คือ met" }
];

const PAST_FRAGMENT_ACT = {
  id: "past-fragment",
  title: "ACT: The Past Fragment",
  subtitle: "ภารกิจฟื้นคืนอดีตด้วยคำกริยาช่องที่ 2",
  reward: "Past Fragment",
  badge: "ผู้ฟื้นคืนอดีต",
  objectives: [
    "เข้าใจอดีต ปัจจุบัน และอนาคตจากตัวอย่างภาษาไทย",
    "เข้าใจแนวคิด tense ว่าภาษาอังกฤษเปลี่ยนรูปกริยาเพื่อบอกเวลา",
    "ใช้ V2 เพื่อเล่าเหตุการณ์ที่เกิดขึ้นแล้ว",
    "เติม -ed / -d ให้ Regular Verbs ได้ถูกต้อง",
    "จำและใช้ Irregular Verbs พื้นฐานได้",
    "เลือก V2 ในประโยค Past Simple ได้"
  ],
  stages: [
    {
      id: "prologue",
      type: "story",
      title: "เงาแห่งอดีตที่แตกสลาย",
      dialogues: [
        { speaker: "ระบบบรรยาย", text: "\"ประตูแห่งอดีตเปิดออกพร้อมหมอกสีม่วง เศษประโยคผิดรูปลอยอยู่รอบหอคอยแห่ง Unity\"" },
        { speaker: "ระบบบรรยาย", text: "\"Yesterday, I go to school. Last night, she eat dinner. Two days ago, they play football. ประโยคเหล่านั้นแตกร้าวราวกับความทรงจำที่ถูกเล่าผิด\"" },
        { speaker: "ผู้พเนจร", text: "\"ทำไมประโยคพวกนี้ถึงแตกออกครับ?\"" },
        { speaker: "มาสเตอร์เวรีออน", text: "\"เพราะมันกำลังเล่าเรื่องในอดีต แต่หัวใจของประโยคยังติดอยู่ในปัจจุบัน ก่อนจะใช้ V2 ได้ เจ้าต้องเข้าใจก่อนว่าอดีตคืออะไร\"" }
      ]
    },
    {
      id: "what-is-past",
      type: "lesson-quiz",
      title: "What is the Past?",
      thaiTitle: "อดีตคืออะไร",
      enemy: "Time Dust",
      thaiEnemy: "ฝุ่นเวลา",
      completionKey: "introCompleted",
      reward: { grammaria: 30, fragment: "Time Spark" },
      lesson: [
        "มาสเตอร์เวรีออน: ผู้พเนจรเอ๋ย ก่อนที่เราจะใช้พลังของอดีต เจ้าต้องเข้าใจก่อนว่า 'อดีต' ไม่ได้หมายถึงเมื่อวานเท่านั้น",
        "สิ่งใดก็ตามที่เกิดขึ้นแล้ว และจบลงแล้ว สิ่งนั้นคืออดีต",
        "หนึ่งวินาทีก่อนหน้านี้ ก็เป็นอดีต สิบนาทีก่อน ก็เป็นอดีต เมื่อเช้าที่ผ่านมา ก็เป็นอดีต หากเหตุการณ์นั้นจบลงแล้ว",
        "เมื่อวาน เดือนที่แล้ว หรือปีที่แล้ว ก็ล้วนเป็นอดีตเช่นกัน",
        "อดีตคือร่องรอยของสิ่งที่เคยเกิดขึ้น และภาษาคือพลังที่ช่วยให้เราบอกเล่าร่องรอยนั้นได้ถูกต้อง",
        "ลองดู 3 ประโยคนี้ก่อน ผู้พเนจร ทั้งสามประโยคพูดถึงเวลาไม่เหมือนกัน",
        "ภาษาไทย: ฉันกินข้าววันนี้",
        "ภาษาไทย: ฉันกินข้าวเมื่อวาน",
        "ภาษาไทย: ฉันจะกินข้าวพรุ่งนี้",
        "วันนี้ = ปัจจุบัน",
        "เมื่อวาน = อดีต",
        "พรุ่งนี้ = อนาคต",
        "ภาษาไทยไม่ว่าจะเป็นวันนี้ เมื่อวาน หรือพรุ่งนี้ คำกริยา 'กิน' ไม่ได้เปลี่ยนรูปมากนัก เราใช้คำบอกเวลาเป็นตัวช่วยให้รู้ว่าเหตุการณ์เกิดขึ้นตอนไหน"
      ],
      questions: [
        { prompt: "ประโยคใดเป็นเหตุการณ์ในอดีต", options: ["ฉันกินข้าววันนี้", "ฉันกินข้าวเมื่อวาน", "ฉันจะกินข้าวพรุ่งนี้"], answer: "ฉันกินข้าวเมื่อวาน", explanation: "คำว่า เมื่อวาน บอกว่าเหตุการณ์เกิดขึ้นแล้ว จึงเป็นอดีต" },
        { prompt: "เหตุการณ์ใดนับเป็นอดีตได้", options: ["สิ่งที่เกิดขึ้นแล้วและจบลงแล้ว", "สิ่งที่กำลังจะเกิดพรุ่งนี้", "สิ่งที่ยังไม่เริ่ม"], answer: "สิ่งที่เกิดขึ้นแล้วและจบลงแล้ว", explanation: "อดีตคือสิ่งที่เกิดขึ้นแล้วและจบลงแล้ว แม้จะเพิ่งเกิดเมื่อ 1 วินาทีก่อนก็นับเป็นอดีตได้" },
        { prompt: "คำว่า 'พรุ่งนี้' บอกเวลาใด", options: ["อดีต", "ปัจจุบัน", "อนาคต"], answer: "อนาคต", explanation: "พรุ่งนี้คือเวลาที่ยังมาไม่ถึง จึงเป็นอนาคต" },
        { prompt: "คำว่า 'วันนี้' มักใช้พูดถึงเวลาใด", options: ["อดีต", "ปัจจุบัน", "อนาคต"], answer: "ปัจจุบัน", explanation: "วันนี้คือเวลาที่กำลังเกิดขึ้นหรือเกี่ยวข้องกับปัจจุบัน" },
        { prompt: "คำว่า 'เมื่อวาน' บอกว่าเหตุการณ์เป็นอย่างไร", options: ["เกิดขึ้นแล้ว", "กำลังเกิดขึ้น", "ยังไม่เกิดขึ้น"], answer: "เกิดขึ้นแล้ว", explanation: "เมื่อวานคือเวลาที่ผ่านไปแล้ว" },
        { prompt: "ประโยค 'ฉันจะกินข้าวพรุ่งนี้' เป็นเวลาใด", options: ["อดีต", "ปัจจุบัน", "อนาคต"], answer: "อนาคต", explanation: "คำว่า จะ และ พรุ่งนี้ บอกว่าเหตุการณ์ยังไม่เกิดขึ้น" }
      ]
    },
    {
      id: "what-is-tense",
      type: "lesson-quiz",
      title: "What is Tense?",
      thaiTitle: "Tense คืออะไร",
      enemy: "Echo Tick",
      thaiEnemy: "ติ๊กสะท้อนอดีต",
      completionKey: "tenseLessonCompleted",
      reward: { grammaria: 30, fragment: "Tense Spark" },
      lesson: [
        "มาสเตอร์เวรีออน: ตอนนี้เราจะดูพลังที่ภาษาอังกฤษใช้บอกเวลา พลังนั้นเรียกว่า tense",
        "ภาษาไทย: ฉันกินข้าววันนี้ / ฉันกินข้าวเมื่อวาน / ฉันจะกินข้าวพรุ่งนี้",
        "มาสเตอร์เวรีออน: ในภาษาไทย คำกริยามักไม่เปลี่ยนรูปมากนัก แต่ภาษาอังกฤษใช้รูปของกริยาเพื่อบอกเวลา",
        "ตัวอย่างภาษาอังกฤษ: I go. / I went. / I will go.",
        `I go. = ${TENSE_LABELS.present}`,
        `I went. = ${TENSE_LABELS.past}`,
        `I will go. = ${TENSE_LABELS.future}`,
        "วันนี้เราจะเน้นพลังของอดีต นั่นคือการใช้กริยาช่องที่ 2 หรือ V2"
      ],
      questions: [
        { prompt: "I go. เป็นเวลาใด", options: [TENSE_LABELS.present, TENSE_LABELS.past, TENSE_LABELS.future], answer: TENSE_LABELS.present, explanation: "go เป็นรูปปัจจุบัน" },
        { prompt: "I went. เป็นเวลาใด", options: [TENSE_LABELS.present, TENSE_LABELS.past, TENSE_LABELS.future], answer: TENSE_LABELS.past, explanation: "went เป็น V2 ใช้พูดถึงอดีต" },
        { prompt: "I will go. เป็นเวลาใด", options: [TENSE_LABELS.present, TENSE_LABELS.past, TENSE_LABELS.future], answer: TENSE_LABELS.future, explanation: "will + V1 ใช้พูดถึงอนาคต" },
        { prompt: "ถ้าจะเล่าเรื่องที่เกิดขึ้นเมื่อวาน ภาษาอังกฤษมักต้องใช้กริยารูปใด", options: ["V1", "V2", "will + V1"], answer: "V2", explanation: "เหตุการณ์ที่เกิดขึ้นแล้วใช้ V2" }
      ]
    },
    {
      id: "regular-intro",
      type: "lesson-only",
      title: "Regular Verbs and -ed Workshop",
      thaiTitle: "โรงหลอม -ed แห่งอดีต",
      completionKey: "regularRulesCompleted",
      reward: { grammaria: 10, fragment: "Regular Gate Opened" },
      lesson: [
        "มาสเตอร์เวรีออน: ประตูแห่งอดีตมีสองเส้นทางใหญ่ ผู้พเนจร",
        "เส้นทางแรกคือ Regular Verbs กริยาที่เดินตามกฎของโรงหลอม -ed",
        "เส้นทางที่สองคือ Irregular Verbs กริยาที่ไม่ยอมเดินตามกฎ ต้องจำรูปอดีตของมันทีละคำ",
        "เราจะเริ่มจาก Regular Verbs ก่อน เพราะมันเป็นประตูแรกของการเล่าอดีตให้ถูกต้อง"
      ],
      questions: []
    },
    {
      id: "regular-rule-1",
      type: "lesson-quiz",
      title: "Regular Rule 1",
      thaiTitle: "คำกริยาทั่วไปเติม -ed",
      enemy: "Time Dust",
      thaiEnemy: "ฝุ่นเวลา",
      reward: { grammaria: 20, fragment: "Rule 1 Spark" },
      lesson: [
        "มาสเตอร์เวรีออน: กฎแรกของ Regular Verbs ง่ายที่สุด คำกริยาทั่วไปเติม -ed ได้เลย",
        "ให้มองคำเดิมเหมือนแกนคริสตัล แล้วเติมตราประทับ -ed เพื่อบอกว่าเหตุการณ์จบลงแล้ว",
        "Examples: walk -> walked, jump -> jumped, help -> helped, watch -> watched, open -> opened, clean -> cleaned, finish -> finished, answer -> answered"
      ],
      questions: regularRuleOneQuestions
    },
    {
      id: "regular-rule-2",
      type: "lesson-quiz",
      title: "Regular Rule 2",
      thaiTitle: "คำลงท้ายด้วย e เติม -d",
      enemy: "Echo Tick",
      thaiEnemy: "ติ๊กสะท้อนอดีต",
      reward: { grammaria: 20, fragment: "Rule 2 Spark" },
      lesson: [
        "มาสเตอร์เวรีออน: กฎที่สอง ระวังคำที่ลงท้ายด้วย e",
        "ถ้าคำกริยามี e อยู่ท้ายคำแล้ว อย่าเติม e ซ้ำ ให้เติมแค่ -d",
        "Examples: like -> liked, love -> loved, live -> lived, dance -> danced, close -> closed, move -> moved, decide -> decided, arrive -> arrived"
      ],
      questions: regularRuleTwoQuestions
    },
    {
      id: "regular-rule-3",
      type: "lesson-quiz",
      title: "Regular Rule 3",
      thaiTitle: "คำลงท้ายด้วย y",
      enemy: "Yesterday Sprite",
      thaiEnemy: "ภูตเมื่อวาน",
      reward: { grammaria: 25, fragment: "Rule 3 Spark" },
      lesson: [
        "มาสเตอร์เวรีออน: กฎที่สามคือประตูตัวอักษร y เจ้าต้องมองตัวอักษรก่อนหน้า y ให้ดี",
        "ถ้าหน้า y เป็นสระ ให้เติม -ed ได้เลย เช่น play -> played, enjoy -> enjoyed, stay -> stayed, obey -> obeyed",
        "ถ้าหน้า y เป็นพยัญชนะ ให้เปลี่ยน y เป็น i แล้วเติม -ed เช่น study -> studied, cry -> cried, try -> tried, carry -> carried, reply -> replied"
      ],
      questions: regularRuleThreeQuestions
    },
    {
      id: "regular-rule-4",
      type: "lesson-quiz",
      title: "Regular Rule 4",
      thaiTitle: "คำสั้นเพิ่มพยัญชนะท้าย",
      enemy: "Rewind Slime",
      thaiEnemy: "สไลม์ย้อนเวลา",
      reward: { grammaria: 25, fragment: "Rule 4 Spark" },
      lesson: [
        "มาสเตอร์เวรีออน: กฎที่สี่คือจังหวะสั้นของคำ CVC",
        "คำกริยาสั้นบางคำที่มีรูปแบบ พยัญชนะ + สระ + พยัญชนะ ต้องเพิ่มพยัญชนะท้ายอีกหนึ่งตัวก่อนเติม -ed",
        "Examples: stop -> stopped, plan -> planned, drop -> dropped, clap -> clapped, grab -> grabbed, hug -> hugged, prefer -> preferred, admit -> admitted"
      ],
      questions: regularRuleFourQuestions
    },
    {
      id: "ed-mini-boss",
      type: "mini-boss",
      title: "Mini Boss 1: The -ed Forger",
      thaiTitle: "ช่างหลอม -ed ที่ผิดเพี้ยน",
      enemy: "The -ed Forger",
      completionKey: "edMiniBossDefeated",
      reward: { grammaria: 80, fragment: "Ed Fragment" },
      lesson: [
        "The -ed Forger ปรากฏตัว มันคือช่างตีเวลาเสื่อมสลายที่หลอมคำกริยาอดีตผิดรูป",
        "คำผิดที่มันสร้างไว้: studyed, stoped, loveed, playied, danceed, droped",
        "ใช้กฎ -ed ทั้ง 4 ข้อเพื่อทำลายการหลอมผิดรูป"
      ],
      questions: edForgerQuestions
    },
    {
      id: "irregular-lesson",
      type: "lesson-quiz",
      title: "Irregular Verbs",
      thaiTitle: "ถ้ำกริยาที่ไม่เชื่อฟังกฎ",
      enemy: "Memory Bat",
      thaiEnemy: "ค้างคาวความทรงจำ",
      completionKey: "irregularLessonCompleted",
      reward: { grammaria: 35, fragment: "Irregular Memory Spark" },
      lesson: [
        "มาสเตอร์เวรีออน: ต่อไปคือถ้ำของ Irregular Verbs กริยาที่ไม่ยอมรับตรา -ed",
        "Regular Verbs เดินตามกฎ เช่น walk -> walked, play -> played, study -> studied",
        "Irregular Verbs เปลี่ยนรูปในแบบของตนเอง เช่น go -> went, eat -> ate, see -> saw, buy -> bought",
        "เจ้าต้องจำพวกมันทีละคำ เพราะถ้าเติม -ed แบบมั่ว ๆ ความทรงจำจะบิดเบี้ยวทันที",
        "go -> went, eat -> ate, see -> saw, buy -> bought, take -> took, come -> came, have -> had, do -> did, make -> made, write -> wrote, meet -> met, choose -> chose, read -> read, give -> gave, get -> got, speak -> spoke, break -> broke, bring -> brought, think -> thought"
      ],
      questions: irregularPracticeQuestions
    },
    {
      id: "irregular-mini-boss",
      type: "mini-boss",
      title: "Mini Boss 2: The Irregular Wraith",
      thaiTitle: "วิญญาณกริยาไร้กฎ",
      enemy: "The Irregular Wraith",
      completionKey: "irregularMiniBossDefeated",
      reward: { grammaria: 90, fragment: "Irregular Fragment" },
      lesson: [
        "The Irregular Wraith ซ่อนรูป V2 ไว้ในถ้ำความทรงจำ",
        "กริยากลุ่มนี้ไม่เติม -ed ต้องเลือก V2 ที่ถูกต้องจากความจำ",
        "ตอบให้ถูกและเตรียมปัดป้องการโจมตีของวิญญาณไร้กฎ"
      ],
      questions: irregularWraithQuestions
    },
    {
      id: "merge-twist",
      type: "story-stage",
      title: "Story Twist",
      thaiTitle: "บอสทั้งสองยังไม่ตาย และหลอมรวมกัน",
      completionKey: "twistSeen",
      reward: { grammaria: 20, fragment: "Merged Memory Warning" },
      lesson: [
        "ผู้พเนจรคิดว่าบอสทั้งสองถูกกำจัดแล้ว แต่เศษของ The -ed Forger และ The Irregular Wraith ยังไม่หายไป",
        "Boss dialogue: อดีตไม่ได้แตกเพราะกฎข้อเดียว...แต่มันแตกเพราะทุกคนเล่ามันผิดซ้ำแล้วซ้ำเล่า",
        "เศษตัวอักษรของ Regular และ Irregular ลอยขึ้นสู่ฟ้า ก่อนหลอมรวมเป็น The Memory Breaker",
        "มาสเตอร์เวรีออน: พลังของ Regular และ Irregular กำลังหลอมรวมกัน ระวังให้ดี ผู้พเนจร นี่คืออดีตที่ถูกเล่าผิดทั้งหมดรวมเป็นหนึ่งเดียว"
      ],
      questions: []
    },
    {
      id: "final-boss",
      type: "final-boss",
      title: "Final Boss: The Memory Breaker",
      thaiTitle: "ผู้ทำลายความทรงจำ",
      enemy: "The Memory Breaker",
      completionKey: "finalBossDefeated",
      bossDialogueLines: [
        "อดีตคือรากของทุกสิ่ง หากอดีตผิดพลาด ปัจจุบันก็ไร้ความหมาย",
        "ข้าไม่ยอมหลอมรวมกับปัจจุบันและอนาคต เพราะพวกมันพยายามลืมข้า",
        "เจ้าคิดว่าอนาคตสำคัญกว่าอดีตอย่างนั้นหรือ",
        "ถ้าไม่มีอดีต เจ้าจะรู้ได้อย่างไรว่าเคยล้ม เคยเรียนรู้ และเคยเติบโต",
        "จงปล่อยให้อดีตแยกออกไป ข้าจะปกป้องมันจากการถูกลืม",
        "ความทรงจำที่ถูกเล่าผิด คือบาดแผลของ Lingua"
      ],
      reward: { grammaria: 150, fragment: "Past Fragment", badge: "ผู้ฟื้นคืนอดีต" },
      lesson: [
        "The -ed Forger และ The Irregular Wraith หลอมรวมกันเป็น The Memory Breaker",
        "Final Boss จะทดสอบทุกอย่าง: Regular Verbs, Irregular Verbs, sentence completion และ correct sentences",
        "เมื่อ HP ต่ำ บอสจะใช้อัลติ เตรียมปัดป้องให้ดี"
      ],
      questions: finalBossQuestions
    },
    {
      id: "ending",
      type: "ending",
      title: "Ending",
      thaiTitle: "ได้รับ Past Fragment",
      lesson: [
        "The Memory Breaker: ข้าไม่ได้เกลียดปัจจุบันหรืออนาคต...ข้าเพียงกลัวว่าอดีตจะถูกลืม",
        "มาสเตอร์เวรีออน: อดีตไม่ควรถูกขังไว้ และไม่ควรถูกลืม อดีตมีหน้าที่บอกเราว่าเคยเกิดอะไรขึ้น เพื่อให้ปัจจุบันเข้าใจตนเอง และให้อนาคตเดินต่อไปได้อย่างถูกทาง",
        "ได้รับ Past Fragment",
        "ได้รับ Badge: ผู้ฟื้นคืนอดีต",
        "ดินแดนแห่งอดีตฟื้นคืนแล้ว"
      ]
    }
  ],
  endingLines: [
    "The Memory Breaker collapses, but before disappearing it speaks: ข้าไม่ได้เกลียดปัจจุบันหรืออนาคต...ข้าเพียงกลัวว่าอดีตจะถูกลืม",
    "มาสเตอร์เวรีออน: อดีตไม่ควรถูกขังไว้ และไม่ควรถูกลืม อดีตมีหน้าที่บอกเราว่าเคยเกิดอะไรขึ้น เพื่อให้ปัจจุบันเข้าใจตนเอง และให้อนาคตเดินต่อไปได้อย่างถูกทาง",
    "ระบบ: ได้รับ Past Fragment ได้รับ Badge: ผู้ฟื้นคืนอดีต ดินแดนแห่งอดีตฟื้นคืนแล้ว"
  ],
  summary: [
    "อดีตคือเหตุการณ์ที่เกิดขึ้นแล้วและจบลงแล้ว แม้จะเป็น 1 วินาทีก่อนหรือ 10 นาทีก่อนก็เป็นอดีตได้",
    "ภาษาไทยมักใช้คำบอกเวลา เช่น เมื่อวาน วันนี้ พรุ่งนี้ เพื่อบอกช่วงเวลา",
    "ภาษาอังกฤษใช้รูปของกริยาเพื่อบอกเวลา นี่คือแนวคิดของ tense",
    `I go. = ${TENSE_LABELS.present}, I went. = ${TENSE_LABELS.past}, I will go. = ${TENSE_LABELS.future}`,
    "เมื่อต้องการเล่าเหตุการณ์ในอดีต เราใช้กริยาช่องที่ 2 หรือ V2",
    "V2 แบ่งได้เป็น 2 กลุ่มใหญ่ คือ Regular Verbs และ Irregular Verbs",
    "Regular Verbs มักเติม -ed หรือ -d ตามกฎ",
    "คำลงท้ายด้วย e เติมแค่ -d",
    "คำลงท้ายด้วยพยัญชนะ + y เปลี่ยน y เป็น i แล้วเติม -ed",
    "คำสั้นบางคำต้องเพิ่มพยัญชนะท้ายก่อนเติม -ed",
    "Irregular Verbs ไม่เติม -ed แต่เปลี่ยนรูป เช่น go -> went, eat -> ate, see -> saw",
    "คำบอกเวลา เช่น yesterday, last night, last week, ago มักเป็นสัญญาณของ Past Simple",
    "ถ้าใช้ V2 ถูกต้อง เราจะเล่าอดีตได้ชัดเจนและถูกต้อง"
  ]
};

const nounWords = [];

const questions = PAST_FRAGMENT_ACT.stages
  .filter(stage => stage.questions)
  .flatMap(stage => stage.questions)
  .map(question => ({
    text: question.sentence || question.prompt,
    options: question.options,
    correct: question.answer
  }));

const charms = [
  {
    id: "minorPower",
    name: "เครื่องรางพลังน้อย",
    effect: "ถ้าตอบถูก ดาเมจ +10%"
  },
  {
    id: "attackRune",
    name: "เครื่องรางรูนโจมตี",
    effect: "ถ้าตอบถูก ดาเมจ +25%"
  },
  {
    id: "tinyHeal",
    name: "เครื่องรางฟื้นฟูเล็ก",
    effect: "ถ้าตอบถูก ฟื้นฟูพลังชีวิต 8"
  },
  {
    id: "guardWord",
    name: "เครื่องรางคำพิทักษ์",
    effect: "ถ้าตอบผิด ลดดาเมจศัตรูครั้งถัดไป 30%"
  },
  {
    id: "focusGlyph",
    name: "เครื่องรางสัญลักษณ์สมาธิ",
    effect: "ทำให้ช่องสมบูรณ์แบบกว้างขึ้น"
  },
  {
    id: "grammariaSpark",
    name: "เครื่องรางประกายแกรมมาเรีย",
    effect: "ถ้าตอบถูก ได้แกรมมาเรียพิเศษ +5 หลังต่อสู้"
  }
];

const CHARM_RANK_DROP_RATES = { C: 42, B: 30, A: 18, S: 8, SS: 2 };
const LOW_HP_CHARM_RANK_DROP_RATES = { C: 45, B: 35, A: 14, S: 5, SS: 1 };
const BASE_CRITICAL_CHANCE = 0.05;
const CRITICAL_DAMAGE_MULTIPLIER = 1.75;

const charmRankMeta = {
  C: { icon: "◇", label: "Common" },
  B: { icon: "◆", label: "Uncommon" },
  A: { icon: "✦", label: "Rare" },
  S: { icon: "✧", label: "Epic" },
  SS: { icon: "✺", label: "Legendary" }
};

function makeCharm(id, name, rank, type, effectType, value, description, extra = {}) {
  return {
    id,
    name,
    rank,
    type,
    effectType,
    value,
    description,
    effect: description,
    icon: extra.icon || charmRankMeta[rank].icon,
    ...extra
  };
}

const actAttackCharms = [
  makeCharm("c_minor_power", "รูนพลังน้อย", "C", "attack", "damageMultiplier", 1.10, "เพิ่มดาเมจ 10% ในการโจมตีครั้งนี้"),
  makeCharm("c_grammaria_spark", "ประกายแกรมมาเรีย", "C", "reward", "bonusGrammaria", 5, "ได้ Grammaria เพิ่ม +5 หลังจบเทิร์น"),
  makeCharm("c_small_heal", "แสงเยียวยาเล็ก", "C", "heal", "healFlat", 8, "ฟื้น HP 8"),
  makeCharm("c_short_focus", "สมาธิสั้น", "C", "parry", "parrySlow", 0.90, "ทำให้ Parry bar ช้าลงเล็กน้อย 1 ครั้ง", { duration: 1 }),
  makeCharm("c_vocab_armor", "เกราะคำศัพท์", "C", "defense", "nextDamageReduction", 0.15, "ลดดาเมจบอสครั้งถัดไป 15%", { duration: 1 }),
  makeCharm("c_past_compass", "เข็มทิศอดีต", "C", "attack", "pastDamageBonus", 1.10, "ถ้าคำถามเป็น Past Simple หรือ V2 เพิ่มดาเมจ 10%"),
  makeCharm("c_memory_shard", "เศษผลึกความจำ", "C", "charge", "memoryCharge", 1, "สะสม Memory Charge 1 หน่วย"),
  makeCharm("c_confidence", "แต้มแห่งความมั่นใจ", "C", "reward", "nextCorrectBonusGrammaria", 3, "ตอบถูกครั้งถัดไป ได้ Grammaria เพิ่ม +3", { duration: 1 }),
  makeCharm("c_light_echo", "แรงสะท้อนเบา", "C", "attack", "echoDamage", 0.10, "หลังโจมตีหลัก ทำดาเมจซ้ำอีก 10%"),
  makeCharm("c_wanderer_breath", "ลมหายใจผู้พเนจร", "C", "heal", "conditionalHeal", 5, "ถ้า HP ต่ำกว่า 50% ฟื้นเพิ่ม 5", { condition: "hpBelow50" }),

  makeCharm("b_attack_rune", "รูนโจมตี", "B", "attack", "damageMultiplier", 1.25, "เพิ่มดาเมจ 25%"),
  makeCharm("b_guard_word", "โล่คำพิทักษ์", "B", "defense", "nextDamageReduction", 0.30, "ลดดาเมจบอสครั้งถัดไป 30%", { duration: 1 }),
  makeCharm("b_wide_parry", "เขตปัดป้องกว้างขึ้น", "B", "parry", "parryZoneBonus", 8, "ขยายช่อง Parry ทุกสีเล็กน้อย 1 ครั้ง", { duration: 1 }),
  makeCharm("b_teacher_hint", "คำใบ้จากอาจารย์", "B", "support", "removeWrongChoice", 1, "คำถามถัดไปตัดตัวเลือกผิดออก 1 ตัว", { duration: 1 }),
  makeCharm("b_second_chance", "โอกาสครั้งที่สอง", "B", "parry", "secondChanceParry", 1, "ถ้า Parry พลาด อัปเกรดเป็น Weak Parry 1 ครั้ง", { duration: 1 }),
  makeCharm("b_past_flame", "เปลวไฟแห่งอดีต", "B", "attack", "pastDamageBonus", 1.25, "ถ้าคำถามเกี่ยวกับ V2 หรือ Past Simple เพิ่มดาเมจ 25%"),
  makeCharm("b_critical_charm", "เครื่องรางคริติคอล", "B", "critical", "criticalChanceBonus", 0.15, "เพิ่มโอกาส Critical +15% ในการโจมตีครั้งนี้", { duration: 1 }),
  makeCharm("b_stun_hammer", "ค้อนสะกดจังหวะ", "B", "stun", "stunChance", 0.25, "โจมตีครั้งนี้มีโอกาส 25% ทำให้บอสติด Stun 1 เทิร์น", { duration: 1 }),
  makeCharm("b_heal_on_correct", "ฟื้นพลังจากคำตอบ", "B", "heal", "healOnCorrect", 12, "ถ้าตอบถูก ฟื้น HP 12", { duration: 1 }),
  makeCharm("b_mark", "รอยประทับ Mark", "B", "status", "applyMark", 0.15, "ติด Mark ให้บอส บอสโดนดาเมจเพิ่ม 15% 1 เทิร์น", { duration: 1 }),
  makeCharm("b_counter_power", "พลังตอบโต้", "B", "counter", "counterOnGoodParry", 0.15, "ถ้า Good หรือ Perfect Parry สำเร็จ โจมตีสวน 15%", { duration: 1 }),
  makeCharm("b_opening_rune", "รูนเริ่มศึก", "B", "attack", "firstTurnDamageBonus", 1.35, "ถ้าเป็นเทิร์นแรกของการต่อสู้ ดาเมจเพิ่ม 35%"),

  makeCharm("a_echo_strike", "ประกายโจมตีสะท้อน", "A", "attack", "echoDamage", 0.25, "หลังโจมตีหลัก ทำดาเมจซ้ำอีก 25%"),
  makeCharm("a_memory_pierce", "แทงทะลุความทรงจำ", "A", "attack", "memoryEnemyBonus", 1.40, "เพิ่มดาเมจ 40% ใส่ศัตรูสายความทรงจำหรือกาลเวลา"),
  makeCharm("a_time_slow", "หน่วงเวลา", "A", "parry", "parrySlow", 0.75, "ทำให้ Parry bar ช้าลงชัดเจน 1 ครั้ง", { duration: 1 }),
  makeCharm("a_retry", "พลังแห่งการทบทวน", "A", "support", "retryNextWrong", 1, "ถ้าตอบผิดครั้งถัดไป ให้ลองใหม่ 1 ครั้ง โดยบอสยังไม่สวน", { duration: 1 }),
  makeCharm("a_crit_rune", "รูนคริติคอลขั้นสูง", "A", "critical", "criticalChanceBonus", 0.25, "เพิ่มโอกาส Critical +25%", { duration: 1 }),
  makeCharm("a_shock_hammer", "ค้อนช็อกแกรมมาเรีย", "A", "stun", "stunChance", 0.50, "โจมตีครั้งนี้มีโอกาส 50% ทำให้บอสติด Stun 1 เทิร์น", { duration: 1 }),
  makeCharm("a_critical_stun", "Critical Stun", "A", "critical-stun", "stunOnCritical", 0.50, "ถ้าโจมตีติด Critical มีโอกาส 50% ทำให้บอสติด Stun 1 เทิร์น", { duration: 1 }),
  makeCharm("a_shield_pierce", "พลังทำลายเกราะ", "A", "break", "shieldPierceDamage", 1.20, "ถ้าบอสมี Shield หรือ Guard ให้ทะลุและทำดาเมจเพิ่ม 20%"),
  makeCharm("a_lifesteal", "เวทดูดพลัง", "A", "heal", "lifesteal", 0.15, "เมื่อโจมตีโดน ฟื้น HP 15% ของดาเมจที่ทำได้"),
  makeCharm("a_weak_curse", "คำสาปผิดรูป", "A", "debuff", "applyWeak", 0.30, "บอสติด Weak ทำดาเมจลดลง 30% 1 เทิร์น", { duration: 1 }),
  makeCharm("a_parry_power", "เร่งพลังหลัง Parry", "A", "parry", "perfectParryNextDamage", 1.35, "ถ้า Perfect Parry สำเร็จ โจมตีครั้งถัดไปแรงขึ้น 35%", { duration: 1 }),
  makeCharm("a_stack_circle", "วงเวทสะสมพลัง", "A", "stack", "stackingCorrectDamage", 0.05, "ทุกครั้งที่ตอบถูก ดาเมจเพิ่ม 5% ซ้อนสูงสุด 5 ครั้ง", { maxStacks: 5 }),
  makeCharm("a_combo_echo", "Echo Strike", "A", "attack", "comboCorrectEcho", 0.30, "ถ้าตอบถูกติดกัน 2 ครั้ง โจมตีซ้ำอีก 30%", { condition: "twoCorrectInRow" }),
  makeCharm("a_grammar_break", "Grammar Break", "A", "break", "bossQuestionBreak", 1, "ถ้าตอบคำถามบอสถูก ทำลาย Guard บอสและเพิ่มดาเมจครั้งถัดไป"),

  makeCharm("s_crystal_charge", "ชาร์จผลึก", "S", "charge", "crystalCharge", 1, "สะสม 1 ชาร์จ ครบ 3 ครั้ง ดาเมจถัดไป x2", { threshold: 3 }),
  makeCharm("s_time_echo", "เวทสะท้อนเวลา", "S", "attack", "delayedEchoDamage", 0.30, "ดาเมจที่ทำในเทิร์นนี้ 30% จะย้อนกลับไปโดนบอสอีกครั้งในเทิร์นถัดไป"),
  makeCharm("s_grammaria_shield", "โล่แกรมมาเรีย", "S", "defense", "blockIfGoodParry", 1, "ป้องกันดาเมจบอส 1 ครั้ง ถ้า Parry ได้อย่างน้อย Good", { duration: 1 }),
  makeCharm("s_verion_eye", "ดวงตาแห่งเวรีออน", "S", "support", "showHintBeforeQuestion", 1, "คำถามถัดไปแสดงคำใบ้ก่อนตอบ", { duration: 1 }),
  makeCharm("s_last_memory_crit", "Last Memory Critical", "S", "critical", "lowHpCriticalBonus", 0.50, "ถ้า HP ต่ำกว่า 30% เพิ่มโอกาส Critical +50%", { condition: "hpBelow30" }),
  makeCharm("s_stun_breaker", "Stun Breaker", "S", "stun", "damageOnStunned", 1.50, "ถ้าบอสติด Stun ดาเมจเพิ่ม 50%"),
  makeCharm("s_perfect_scholar", "Perfect Scholar", "S", "stack", "correctStreakDamage", 1.75, "ถ้าตอบถูก 3 ครั้งติดกัน ดาเมจครั้งถัดไป x1.75", { condition: "threeCorrectInRow" }),
  makeCharm("s_time_skip", "Time Skip", "S", "turn", "extraTurnChance", 0.35, "หลังโจมตี มีโอกาส 35% ได้เล่นต่อทันที 1 เทิร์น"),
  makeCharm("s_grammar_roulette", "Grammar Roulette", "S", "gamble", "rouletteDamage", null, "ดาเมจสุ่ม 70% หรือ 180% ของดาเมจปกติ", { values: [0.70, 1.80] }),
  makeCharm("s_absolute_parry", "Absolute Parry", "S", "parry", "upgradeNextParry", 1, "Parry ครั้งถัดไป ถ้าโดนช่องสีใดก็ตาม จะอัปเกรดผลขึ้น 1 ระดับ", { duration: 1 }),

  makeCharm("ss_past_fragment", "เศษเสี้ยว Past Fragment", "SS", "attack", "damageAndReward", null, "ดาเมจ x2 และได้ Grammaria เพิ่ม +15", { damageMultiplier: 2.00, bonusGrammaria: 15 }),
  makeCharm("ss_v2_judgement", "ประกาศิตแห่ง V2", "SS", "attack-debuff", "v2Judgement", null, "ถ้าตอบถูก ดาเมจหนักมาก และบอสติด Weak 1 เทิร์น", { damageMultiplier: 1.85, applyWeak: 0.30, duration: 1 }),
  makeCharm("ss_reverse_curse", "คำสาปย้อนกลับ", "SS", "counter", "reflectNextBossAttack", 0.50, "ถ้าบอสโจมตีในเทิร์นถัดไป บอสโดนดาเมจสะท้อน 50%", { duration: 1 }),
  makeCharm("ss_full_memory", "ความทรงจำสมบูรณ์", "SS", "heal-attack-parry", "fullMemoryBurst", null, "ฟื้น HP 25 เพิ่มดาเมจ 50% และขยาย Parry 1 ครั้ง", { healFlat: 25, damageMultiplier: 1.50, parryZoneBonus: 10, duration: 1 }),
  makeCharm("ss_verion_seal", "เวรีออนเปิดผนึก", "SS", "support-critical", "verionSeal", null, "ตัดตัวเลือกผิด 2 ตัว และโจมตีครั้งถัดไป Critical แน่นอน", { removeWrongChoice: 2, forceCriticalNextAttack: true, duration: 1 }),
  makeCharm("ss_perfect_timeline", "Perfect Timeline", "SS", "parry-stun-counter", "perfectTimeline", null, "Perfect Parry ครั้งถัดไปทำให้บอสติด Stun และสวนกลับแรง x2", { stunOnPerfectParry: true, counterMultiplier: 2.00, duration: 1 }),
  makeCharm("ss_great_recall", "The Great Recall", "SS", "revive", "surviveFatalOnce", 0.40, "ถ้า HP เหลือ 0 ครั้งแรก จะรอดที่ 1 HP แล้วฟื้น 40%", { healPercent: 0.40, oncePerBattle: true })
];

const enemyAttackPatterns = {
  normal: {
    id: "normal",
    name: "ดูดกลืนชื่อ",
    announce: "Memory Shade กำลังโจมตี!",
    hits: 1,
    baseDamage: 18,
    countdownOptions: [3, 5],
    shortStepDuration: 850,
    longStepDuration: 950,
    gaugeSpeed: 1150,
    gaugeZoneWidth: 22,
    gaugeZoneShrinkPerHit: 0,
    gaugeSpeedUpPerHit: 0
  },
  silentBarrage: {
    id: "silentBarrage",
    name: "Silent Barrage",
    announce: "Null Core uses Silent Barrage!",
    hits: 5,
    baseDamage: 8,
    countdownOptions: [3, 5],
    shortStepDuration: 820,
    longStepDuration: 920,
    gaugeSpeed: 1120,
    gaugeZoneWidth: 26,
    gaugeZoneShrinkPerHit: 3,
    gaugeSpeedUpPerHit: 80
  }
};

const enemySpriteMap = {
  "Memory Shade": "assets/memory-shade.png",
  "Time Dust": "assets/enemies/time-dust.png",
  "Echo Tick": "assets/enemies/echo-tick.png",
  "Rewind Slime": "assets/enemies/rewind-slime.png",
  "Yesterday Sprite": "assets/memory-shade.png",
  "Memory Bat": "assets/memory-shade.png",
  "The -ed Forger": "assets/enemies/ed-forger.png",
  "ช่างหลอม -ed": "assets/enemies/ed-forger.png",
  "The Irregular Wraith": "assets/enemies/irregular-wraith.png",
  "ภูต Irregular": "assets/enemies/irregular-wraith.png",
  "The Memory Breaker": "assets/enemies/memory-breaker.png",
  "ผู้ทำลายความทรงจำ": "assets/enemies/memory-breaker.png"
};

const enemyDescriptions = {
  "Time Dust": "ฝุ่นแห่งกาลเวลาที่ลอยวนอยู่รอบเศษความทรงจำ",
  "Echo Tick": "สิ่งมีชีวิตกลไกเวลาที่ทำให้ช่วงเวลาซ้ำไปซ้ำมา",
  "Rewind Slime": "สไลม์แห่งการย้อนกลับที่กลืนเศษเวลาไว้ในตัว",
  "Memory Shade": "เงาความทรงจำที่บิดเบือนคำกริยาในอดีต",
  "The -ed Forger": "ช่างหลอมคำกริยาอดีตที่สร้างรูป -ed ผิดเพี้ยน",
  "The Irregular Wraith": "วิญญาณกริยาไร้กฎที่ซ่อนรูป V2 ไว้ในความทรงจำ",
  "The Memory Breaker": "เศษความทรงจำ Regular และ Irregular ที่หลอมรวมจนบิดเบี้ยว"
};

const HIT_TOLERANCE = 6;

const skipBattleEnemies = [
  {
    id: "time-dust",
    stageId: "what-is-past",
    name: "Time Dust",
    thaiName: "ไทม์ดัสต์",
    description: "ฝุ่นแห่งกาลเวลาที่ลอยวนอยู่รอบเศษความทรงจำ",
    lesson: "อดีตคืออะไร"
  },
  {
    id: "echo-tick",
    stageId: "regular-rule-2",
    name: "Echo Tick",
    thaiName: "เอคโคทิก",
    description: "สิ่งมีชีวิตกลไกเวลาที่ทำให้ช่วงเวลาซ้ำไปซ้ำมา",
    lesson: "กฎการเติม -d"
  },
  {
    id: "rewind-slime",
    stageId: "regular-rule-4",
    name: "Rewind Slime",
    thaiName: "รีไวน์สไลม์",
    description: "สไลม์แห่งการย้อนกลับที่กลืนเศษเวลาไว้ในตัว",
    lesson: "กฎ y เป็น ied"
  },
  {
    id: "ed-forger",
    stageId: "ed-mini-boss",
    name: "The -ed Forger",
    thaiName: "ช่างหลอม -ed",
    description: "มินิบอสที่หลอมรูปอดีตของคำกริยาปกติให้ผิดเพี้ยน",
    lesson: "Regular Verb Mini Boss"
  },
  {
    id: "irregular-wraith",
    stageId: "irregular-mini-boss",
    name: "The Irregular Wraith",
    thaiName: "ภูต Irregular",
    description: "วิญญาณกริยาไร้กฎที่ซ่อนรูป V2 ไว้ในความทรงจำ",
    lesson: "Irregular Verb Mini Boss"
  },
  {
    id: "memory-breaker",
    stageId: "final-boss",
    name: "The Memory Breaker",
    thaiName: "ผู้ทำลายความทรงจำ",
    description: "บอสใหญ่ที่ผสม Regular และ Irregular จนเวลาแตกกระจาย",
    lesson: "Past Fragment Final Boss"
  }
];

let playerData = null;

const playerStorage = {
  get(key) {
    return localStorage.getItem(key);
  },
  set(key, value) {
    localStorage.setItem(key, value);
  }
};

const state = {
  currentUser: null,
  dialogueIndex: 0,
  typewriterTimer: null,
  typewriterText: "",
  typewriterIndex: 0,
  isTypingDialogue: false,
  activeDialogue: [],
  awaitingName: false,
  awaitingDialogueChoice: false,
  isTransitioning: false,
  enemyTurnTimer: null,
  selectedNouns: new Set(),
  playerHp: 100,
  enemyHp: 80,
  grammaria: 0,
  sparkBonus: 0,
  currentQuestion: null,
  answerCorrect: false,
  selectedCharm: null,
  shield: 0,
  guardShield: 0,
  charge: null,
  parry: null,
  parryAttack: null,
  enemyMaxHp: 80,
  actStageIndex: 0,
  actBattle: null,
  lastStageResult: null,
  lessonSteps: [],
  lessonStepIndex: 0,
  currentLessonStage: null,
  lessonStoryMode: false,
  lessonStorySteps: [],
  lessonStoryStepIndex: 0,
  lastCharmSet: [],
  battleActiveEffects: {},
  isLessonSummaryOpen: false
};

const els = {
  googleMockButton: document.getElementById("googleMockButton"),
  guestLoginButton: document.getElementById("guestLoginButton"),
  loginDisplayName: document.getElementById("loginDisplayName"),
  loginEmail: document.getElementById("loginEmail"),
  enterLinguaButton: document.getElementById("enterLinguaButton"),
  loginStatus: document.getElementById("loginStatus"),
  classNameSelect: document.getElementById("classNameSelect"),
  roomInput: document.getElementById("roomInput"),
  avatarPreview: document.getElementById("avatarPreview"),
  avatarPreviewText: document.getElementById("avatarPreviewText"),
  createCharacterButton: document.getElementById("createCharacterButton"),
  createStatus: document.getElementById("createStatus"),
  storyNameForm: document.getElementById("storyNameForm"),
  storyNameInput: document.getElementById("storyNameInput"),
  confirmNameButton: document.getElementById("confirmNameButton"),
  namePromptStatus: document.getElementById("namePromptStatus"),
  startButton: document.getElementById("startButton"),
  speakerName: document.getElementById("speakerName"),
  dialogueText: document.getElementById("dialogueText"),
  dialogueChoices: document.getElementById("dialogueChoices"),
  nextDialogueButton: document.getElementById("nextDialogueButton"),
  dialoguePanel: document.getElementById("dialoguePanel"),
  dialogueActions: document.getElementById("dialogueActions"),
  lessonStoryVisual: document.getElementById("lessonStoryVisual"),
  nounActivity: document.getElementById("nounActivity"),
  nounActivityVisual: document.getElementById("nounActivityVisual"),
  explanationCloseButton: document.getElementById("explanationCloseButton"),
  wordGrid: document.getElementById("wordGrid"),
  activityFeedback: document.getElementById("activityFeedback"),
  battleButton: document.getElementById("battleButton"),
  playerHpFill: document.getElementById("playerHpFill"),
  enemyHpFill: document.getElementById("enemyHpFill"),
  playerHpText: document.getElementById("playerHpText"),
  enemyHpText: document.getElementById("enemyHpText"),
  grammariaText: document.getElementById("grammariaText"),
  shieldText: document.getElementById("shieldText"),
  battleTitle: document.getElementById("battleTitle"),
  battleExitButton: document.getElementById("battleExitButton"),
  battleEnemySprite: document.getElementById("battleEnemySprite"),
  battleEnemyName: document.getElementById("battleEnemyName"),
  battleEnemyDescription: document.getElementById("battleEnemyDescription"),
  battleMessage: document.getElementById("battleMessage"),
  actionMenu: document.getElementById("actionMenu"),
  attackButton: document.getElementById("attackButton"),
  itemButton: document.getElementById("itemButton"),
  focusButton: document.getElementById("focusButton"),
  questionPanel: document.getElementById("questionPanel"),
  questionText: document.getElementById("questionText"),
  answerOptions: document.getElementById("answerOptions"),
  charmPanel: document.getElementById("charmPanel"),
  charmOptions: document.getElementById("charmOptions"),
  chargePanel: document.getElementById("chargePanel"),
  chargeBar: document.getElementById("chargeBar"),
  perfectZone: document.getElementById("perfectZone"),
  chargeMarker: document.getElementById("chargeMarker"),
  stopChargeButton: document.getElementById("stopChargeButton"),
  parryPanel: document.getElementById("parryPanel"),
  enemyAttackName: document.getElementById("enemyAttackName"),
  parryHitText: document.getElementById("parryHitText"),
  parryCountdown: document.getElementById("parryCountdown"),
  parryGaugeZone: document.getElementById("parryGaugeZone"),
  parryGaugeMarker: document.getElementById("parryGaugeMarker"),
  parryHitResult: document.getElementById("parryHitResult"),
  parryButton: document.getElementById("parryButton"),
  continueBattleButton: document.getElementById("continueBattleButton"),
  victoryTitle: document.getElementById("victoryTitle"),
  victoryEnemy: document.getElementById("victoryEnemy"),
  victoryStory: document.getElementById("victoryStory"),
  victoryGrammaria: document.getElementById("victoryGrammaria"),
  victoryExtra: document.getElementById("victoryExtra"),
  victoryBadge: document.getElementById("victoryBadge"),
  victoryFragmentText: document.getElementById("victoryFragmentText"),
  returnTitleButton: document.getElementById("returnTitleButton"),
  sceneTransition: document.getElementById("sceneTransition"),
  transitionText: document.getElementById("transitionText"),
  storyWanderer: document.getElementById("storyWanderer"),
  storyVerion: document.getElementById("storyVerion"),
  lessonBackButton: document.getElementById("lessonBackButton"),
  lessonDictionaryButton: document.getElementById("lessonDictionaryButton"),
  lessonExplainButton: document.getElementById("lessonExplainButton"),
  lessonReviewButton: document.getElementById("lessonReviewButton"),
  skipBattleButton: document.getElementById("skipBattleButton"),
  lessonActLabel: document.getElementById("lessonActLabel"),
  lessonLocationLabel: document.getElementById("lessonLocationLabel"),
  lessonProgressText: document.getElementById("lessonProgressText"),
  battlePlayer: document.getElementById("battlePlayer"),
  battleEnemy: document.getElementById("battleEnemy"),
  gameModal: document.getElementById("gameModal"),
  gameModalClose: document.getElementById("gameModalClose"),
  gameModalTitle: document.getElementById("gameModalTitle"),
  gameModalBody: document.getElementById("gameModalBody"),
  gameModalContent: document.getElementById("gameModalContent"),
  gameModalActions: document.getElementById("gameModalActions")
};

function showScene(name) {
  Object.values(scenes).forEach(scene => scene.classList.remove("active"));
  scenes[name].classList.add("active");
}

function runSceneTransition(message, onCovered) {
  if (state.isTransitioning) {
    return;
  }

  state.isTransitioning = true;
  els.transitionText.textContent = message;
  els.sceneTransition.classList.remove("hidden");

  requestAnimationFrame(() => {
    els.sceneTransition.classList.add("visible");
  });

  setTimeout(() => {
    onCovered();

    setTimeout(() => {
      els.sceneTransition.classList.remove("visible");

      setTimeout(() => {
        els.sceneTransition.classList.add("hidden");
        state.isTransitioning = false;
      }, 380);
    }, 260);
  }, 420);
}

function closeGameModal() {
  if (!els.gameModal) {
    return;
  }

  els.gameModal.classList.add("hidden");
  els.gameModalTitle.textContent = "";
  els.gameModalBody.textContent = "";
  els.gameModalContent.innerHTML = "";
  els.gameModalActions.innerHTML = "";
}

function isGameModalOpen() {
  return els.gameModal && !els.gameModal.classList.contains("hidden");
}

function openGameModal({ title, body = "", content = "", actions = [] }) {
  if (!els.gameModal) {
    return;
  }

  els.gameModalTitle.textContent = title;
  els.gameModalBody.textContent = body;
  els.gameModalContent.innerHTML = "";
  els.gameModalActions.innerHTML = "";

  if (typeof content === "string") {
    els.gameModalContent.innerHTML = content;
  } else if (content) {
    els.gameModalContent.appendChild(content);
  }

  actions.forEach(action => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = action.primary ? "primary-button" : "secondary-button";
    button.textContent = action.label;
    button.addEventListener("click", action.onClick);
    els.gameModalActions.appendChild(button);
  });

  els.gameModal.classList.remove("hidden");
}

function showOnlyBattlePanel(panelToShow) {
  [els.actionMenu, els.questionPanel, els.charmPanel, els.chargePanel, els.parryPanel, els.continueBattleButton]
    .forEach(panel => panel.classList.add("hidden"));

  if (panelToShow) {
    panelToShow.classList.remove("hidden");
  }
}

function setBattleTurnOwner(owner) {
  els.battlePlayer.classList.toggle("is-active-turn", owner === "player");
  els.battleEnemy.classList.toggle("is-active-turn", owner === "enemy");
}

function setActionButtonsEnabled(isEnabled) {
  [els.attackButton, els.itemButton, els.focusButton].forEach(button => {
    button.disabled = !isEnabled;
  });
}

function clearEnemyTurnTimer() {
  if (state.enemyTurnTimer) {
    clearTimeout(state.enemyTurnTimer);
    state.enemyTurnTimer = null;
  }
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function sample(array, count) {
  const copy = [...array];
  const result = [];

  while (copy.length && result.length < count) {
    const index = Math.floor(Math.random() * copy.length);
    result.push(copy.splice(index, 1)[0]);
  }

  return result;
}

function weightedPickFromTable(table) {
  const entries = Object.entries(table);
  const total = entries.reduce((sum, [, weight]) => sum + weight, 0);
  let roll = Math.random() * total;

  for (const [key, weight] of entries) {
    roll -= weight;
    if (roll <= 0) {
      return key;
    }
  }

  return entries[entries.length - 1][0];
}

function getPlayerHpPercent() {
  return clamp((state.playerHp || 0) / 100, 0, 1);
}

function shouldUseLowHpCharmBias() {
  return getPlayerHpPercent() <= 0.35;
}

function getCharmPoolByRules(rank, excludedIds, allowHighRank = true) {
  let pool = actAttackCharms.filter(charm => charm.rank === rank && !excludedIds.has(charm.id));

  if (!allowHighRank) {
    pool = pool.filter(charm => charm.rank !== "S" && charm.rank !== "SS");
  }

  if (!pool.length) {
    pool = actAttackCharms.filter(charm => charm.rank === rank);
  }

  return pool;
}

function selectRandomActCharms() {
  const battle = state.actBattle;
  const rates = shouldUseLowHpCharmBias() ? LOW_HP_CHARM_RANK_DROP_RATES : CHARM_RANK_DROP_RATES;
  const recentIds = new Set([...(battle?.recentCharmIds || []), ...(state.lastCharmSet || [])]);
  const selected = [];
  const selectedIds = new Set();
  let highRankCount = 0;
  let attempts = 0;

  while (selected.length < 3 && attempts < 80) {
    attempts += 1;
    const rank = weightedPickFromTable(rates);
    const allowHighRank = highRankCount < 1;
    const excluded = new Set([...recentIds, ...selectedIds]);
    const pool = getCharmPoolByRules(rank, excluded, allowHighRank);
    const charm = sample(pool, 1)[0];

    if (!charm || selectedIds.has(charm.id)) {
      continue;
    }

    if ((charm.rank === "S" || charm.rank === "SS") && highRankCount >= 1) {
      continue;
    }

    selected.push(charm);
    selectedIds.add(charm.id);
    if (charm.rank === "S" || charm.rank === "SS") {
      highRankCount += 1;
    }
  }

  if (selected.length < 3) {
    const fallback = actAttackCharms.filter(charm => !selectedIds.has(charm.id));
    selected.push(...sample(fallback, 3 - selected.length));
  }

  const ranks = selected.map(charm => charm.rank);
  const allSameRank = ranks.length === 3 && ranks.every(rank => rank === ranks[0]);
  if (allSameRank) {
    const replacement = sample(actAttackCharms.filter(charm => charm.rank !== ranks[0] && !selectedIds.has(charm.id)), 1)[0];
    if (replacement) {
      selected[2] = replacement;
    }
  }

  if (shouldUseLowHpCharmBias() && !selected.some(charm => charm.type === "heal" || charm.type === "defense")) {
    const rescuePool = actAttackCharms.filter(charm =>
      (charm.type === "heal" || charm.type === "defense") &&
      (charm.rank === "C" || charm.rank === "B") &&
      !selectedIds.has(charm.id)
    );
    const rescueCharm = sample(rescuePool, 1)[0];
    if (rescueCharm) {
      const replaceIndex = selected.findIndex(charm => charm.rank === "S" || charm.rank === "SS");
      selected[replaceIndex >= 0 ? replaceIndex : 2] = rescueCharm;
    }
  }

  const choices = selected.slice(0, 3);
  state.lastCharmSet = choices.map(charm => charm.id);

  if (battle) {
    battle.recentCharmIds = [...(battle.recentCharmIds || []), ...state.lastCharmSet].slice(-6);
  }

  return choices;
}

function resetBattleActiveEffects() {
  state.battleActiveEffects = {
    parrySlow: 0,
    parrySlowMultiplier: 1,
    parryWide: 0,
    parryWideBonus: 0,
    secondChance: 0,
    hint: 0,
    retry: 0,
    echoDamageNextTurn: 0,
    criticalChanceBonus: 0,
    forceCriticalNextAttack: 0,
    stunChance: 0,
    stunOnCriticalChance: 0,
    counterOnGoodParry: 0,
    blockIfGoodParry: 0,
    reflectNextBossAttack: 0,
    upgradeNextParry: 0,
    stunOnPerfectParry: 0,
    perfectTimelineCounterMultiplier: 1,
    bossWeak: 0,
    bossWeakTurns: 0,
    markDamageBonus: 0,
    lifestealRatio: 0,
    nextCorrectBonusGrammaria: 0,
    crystalCharge: 0,
    memoryCharge: 0,
    stackingDamageBonus: 0,
    surviveFatalOnce: false
  };
}

function useBattleEffect(effectId) {
  const effects = state.battleActiveEffects || {};
  if (!effects[effectId]) {
    return false;
  }

  effects[effectId] -= 1;
  return true;
}

function consumeBattleEffectValue(effectId, fallback = 0) {
  const effects = state.battleActiveEffects || {};
  const value = effects[effectId] || fallback;
  effects[effectId] = 0;
  return value;
}

function addBattleMessageLine(lines, text) {
  if (text) {
    lines.push(text);
  }
}

function normalizeEmail(email) {
  return email.trim().toLowerCase();
}

function getPlayerStorageKey(userIdOrEmail) {
  const normalized = normalizeEmail(userIdOrEmail);
  if (normalized === "guest" || normalized === "guest@lingua.local") {
    return "lingua_player_guest";
  }
  return `lingua_player_${normalized}`;
}

function getCurrentUser() {
  return state.currentUser;
}

function loginWithGoogleMock() {
  const displayName = els.loginDisplayName.value.trim();
  const email = normalizeEmail(els.loginEmail.value);

  if (!displayName || !email) {
    els.loginStatus.textContent = "กรุณากรอกชื่อผู้เล่นและอีเมล Gmail";
    return;
  }

  if (!email.endsWith("@gmail.com")) {
    els.loginStatus.textContent = "กรุณาใช้อีเมล Gmail สำหรับ mock login";
    return;
  }

  state.currentUser = {
    userId: email,
    email,
    displayName,
    isGuest: false
  };

  els.loginStatus.textContent = "กำลังโหลดข้อมูลผู้เล่น...";

  if (hasExistingPlayer(email)) {
    loadPlayerProfile(email);
    els.loginStatus.textContent = "พบข้อมูลเดิม กำลังเข้าสู่โลก Lingua";
    runSceneTransition("พบข้อมูลเดิม กำลังเข้าสู่โลก Lingua...", setupStoryScene);
    return;
  }

  els.createStatus.textContent = "ยังไม่พบตัวละคร กรุณาสร้างตัวละครก่อนเริ่มเดินทาง";
  runSceneTransition("กำลังเตรียมหน้าสร้างตัวละคร...", () => showScene("createCharacter"));
}

function hasExistingPlayer(userIdOrEmail) {
  return Boolean(playerStorage.get(getPlayerStorageKey(userIdOrEmail)));
}

function loginAsGuest() {
  state.currentUser = {
    userId: "guest",
    email: "guest@lingua.local",
    displayName: "Guest Player",
    isGuest: true
  };

  els.loginStatus.textContent = "กำลังโหลดข้อมูล Guest...";

  if (hasExistingPlayer("guest")) {
    loadPlayerProfile("guest");
    els.loginStatus.textContent = "พบข้อมูล Guest เดิม กำลังเข้าสู่โลก Lingua";
    runSceneTransition("พบข้อมูล Guest เดิม กำลังเข้าสู่โลก Lingua...", setupStoryScene);
    return;
  }

  els.createStatus.textContent = "ยังไม่พบตัวละคร Guest กรุณาสร้างตัวละครก่อนเริ่มเดินทาง";
  runSceneTransition("กำลังเตรียมหน้าสร้างตัวละคร Guest...", () => showScene("createCharacter"));
}

function loadPlayerData(userIdOrEmail) {
  const saved = playerStorage.get(getPlayerStorageKey(userIdOrEmail));
  return saved ? JSON.parse(saved) : null;
}

function loadPlayerProfile(userIdOrEmail) {
  playerData = loadPlayerData(userIdOrEmail);
  if (playerData) {
    state.currentUser = {
      userId: playerData.userId,
      email: playerData.email,
      displayName: playerData.displayName,
      isGuest: Boolean(playerData.isGuest)
    };
  }
  return playerData;
}

function savePlayerProfile() {
  return savePlayerData();
}

function createDefaultPlayerData(user) {
  const now = new Date().toISOString();
  return {
    userId: user.userId,
    email: user.email,
    displayName: user.displayName,
    isGuest: Boolean(user.isGuest),
    characterName: "",
    className: "",
    room: "",
    avatar: {
      gender: "other",
      bodyType: "normal",
      type: "wanderer",
      outfit: "default",
      color: "blue"
    },
    level: 1,
    grammaria: 0,
    coins: 0,
    hp: 100,
    maxHp: 100,
    stats: {
      atk: 1,
      def: 1,
      vit: 1,
      agi: 1,
      luk: 1,
      statusPoints: 0
    },
    progress: {
      currentAct: 1,
      currentChapter: 1,
      currentScene: "story",
      unlockedFragments: [],
      restoredCores: [],
      defeatedEnemies: [],
      pastFragmentAct: {
        introCompleted: false,
        tenseLessonCompleted: false,
        regularRulesCompleted: false,
        edMiniBossDefeated: false,
        irregularLessonCompleted: false,
        irregularMiniBossDefeated: false,
        twistSeen: false,
        finalBossDefeated: false,
        rewards: [],
        completedStages: [],
        fragments: [],
        grammariaEarned: 0,
        badge: ""
      }
    },
    inventory: {
      battleItems: [],
      equipment: [],
      keyItems: []
    },
    settings: {
      textSpeed: "normal",
      sound: true,
      language: "th"
    },
    createdAt: now,
    updatedAt: now
  };
}

function savePlayerData() {
  if (!playerData) {
    return false;
  }

  playerData.updatedAt = new Date().toISOString();
  playerStorage.set(getPlayerStorageKey(playerData.email), JSON.stringify(playerData));
  return true;
}

function mergeDeep(target, source) {
  Object.entries(source).forEach(([key, value]) => {
    if (value && typeof value === "object" && !Array.isArray(value)) {
      target[key] = target[key] || {};
      mergeDeep(target[key], value);
    } else {
      target[key] = value;
    }
  });
  return target;
}

function updatePlayerProgress(updateObject) {
  if (!playerData) {
    return;
  }

  mergeDeep(playerData, updateObject);
  savePlayerData();
}

function syncBattleStateToPlayerData() {
  if (!playerData) {
    return;
  }

  updatePlayerProgress({
    grammaria: state.grammaria,
    hp: state.playerHp
  });
}

function addUniqueProgressItem(listName, value) {
  if (!playerData) {
    return;
  }

  if (!playerData.progress[listName].includes(value)) {
    playerData.progress[listName].push(value);
  }
}

function createCharacterFromForm() {
  const user = getCurrentUser();
  if (!user) {
    els.createStatus.textContent = "กรุณาเข้าสู่ระบบก่อนสร้างตัวละคร";
    showScene("login");
    return;
  }

  const className = els.classNameSelect.value;
  const room = els.roomInput.value.trim();
  const avatarChoice = document.querySelector("input[name=\"avatarType\"]:checked");
  const genderChoice = document.querySelector("input[name=\"avatarGender\"]:checked");
  const bodyTypeChoice = document.querySelector("input[name=\"avatarBodyType\"]:checked");

  if (!room) {
    els.createStatus.textContent = "กรุณากรอกห้องเรียน";
    return;
  }

  playerData = createDefaultPlayerData(user);
  playerData.characterName = "";
  playerData.className = className;
  playerData.room = room;
  playerData.avatar = {
    gender: genderChoice ? genderChoice.value : "other",
    bodyType: bodyTypeChoice ? bodyTypeChoice.value : "normal",
    type: avatarChoice ? avatarChoice.value : "wanderer",
    outfit: "default",
    color: "blue"
  };

  savePlayerProfile();
  els.createStatus.textContent = "บันทึกข้อมูลแล้ว";
  runSceneTransition("บันทึกข้อมูลแล้ว กำลังเข้าสู่โลก Lingua...", setupStoryScene);
}

function getCheckedRadioValue(name, fallback) {
  const checked = document.querySelector(`input[name="${name}"]:checked`);
  return checked ? checked.value : fallback;
}

function updateAvatarPreview() {
  if (!els.avatarPreview || !els.avatarPreviewText) {
    return;
  }

  const gender = getCheckedRadioValue("avatarGender", "other");
  const bodyType = getCheckedRadioValue("avatarBodyType", "normal");
  const genderLabels = { male: "ชาย", female: "หญิง", other: "ไม่ระบุ" };
  const bodyLabels = { small: "ตัวเล็ก", normal: "ปกติ", tall: "สูง" };

  els.avatarPreview.className = `avatar-preview avatar-gender-${gender} avatar-body-${bodyType}`;
  els.avatarPreviewText.textContent = `ตัวอย่าง: ${genderLabels[gender] || genderLabels.other} / ${bodyLabels[bodyType] || bodyLabels.normal}`;
}

function bindAvatarPreviewInputs() {
  document.querySelectorAll("input[name=\"avatarGender\"], input[name=\"avatarBodyType\"]").forEach(input => {
    input.addEventListener("change", updateAvatarPreview);
  });
  updateAvatarPreview();
}

function getCharacterName() {
  return playerData && playerData.characterName ? playerData.characterName.trim() : "";
}

function createNameGreetingLine() {
  return {
    speaker: "มาสเตอร์เวรีออน",
    text: () => `"ยินดีที่ได้พบเจ้า, ${getCharacterName()} นับจากนี้ ชื่อนี้จะเป็นแสงแรกที่ผูกเจ้ากับโลก Lingua"`
  };
}

function buildStoryDialogue() {
  const actPrologue = PAST_FRAGMENT_ACT.stages.find(stage => stage.id === "prologue");
  const lines = [
    ...actPrologue.dialogues,
    ...interactiveStoryDialogue
  ];

  if (getCharacterName()) {
    lines.push(createNameGreetingLine());
  } else {
    lines.push(...namingDialogue);
  }

  lines.push({
    speaker: "ระบบ",
    text: `"${PAST_FRAGMENT_ACT.title}: ${PAST_FRAGMENT_ACT.subtitle}"`
  });
  return lines;
}

function resolveDialogueText(line) {
  return typeof line.text === "function" ? line.text() : line.text;
}

function showNamePrompt() {
  state.awaitingName = true;
  els.storyNameForm.classList.remove("hidden");
  els.nextDialogueButton.classList.add("hidden");
  els.namePromptStatus.textContent = "";
  setDialogueButtonReady(false);
  setTimeout(() => els.storyNameInput.focus(), 80);
}

function hideNamePrompt() {
  state.awaitingName = false;
  els.storyNameForm.classList.add("hidden");
  els.nextDialogueButton.classList.remove("hidden");
}

function confirmStoryName() {
  const name = els.storyNameInput.value.trim();

  if (!name) {
    els.namePromptStatus.textContent = "กรุณากรอกชื่อก่อนเริ่มการเดินทาง";
    return;
  }

  if (!playerData) {
    const user = getCurrentUser() || {
      userId: "guest",
      email: "guest@lingua.local",
      displayName: "Guest Player",
      isGuest: true
    };
    playerData = createDefaultPlayerData(user);
  }

  playerData.characterName = name;
  playerData.displayName = name;
  savePlayerData();
  hideNamePrompt();
  state.activeDialogue.splice(state.dialogueIndex + 1, 0, createNameGreetingLine());
  advanceDialogue();
}

function updateDialogue() {
  const line = state.activeDialogue[state.dialogueIndex];
  els.speakerName.textContent = line.speaker;
  updateSpeakingCharacter(line.speaker);
  updateDialogueSpeakerTone(line.speaker);
  hideDialogueChoices();
  startTypewriter(resolveDialogueText(line));
}

function updateDialogueSpeakerTone(speaker = "") {
  els.dialoguePanel.classList.remove("speaker-player", "speaker-verion", "speaker-system");
  els.dialoguePanel.classList.add(getSpeakerToneClass(speaker));
}

function startTypewriter(text) {
  stopTypewriter();
  state.typewriterText = text;
  state.typewriterIndex = 0;
  state.isTypingDialogue = true;
  els.dialogueText.textContent = "";
  setDialogueButtonReady(false);
  typeNextCharacter();
}

function typeNextCharacter() {
  if (!state.isTypingDialogue) {
    return;
  }

  state.typewriterIndex += 1;
  els.dialogueText.textContent = state.typewriterText.slice(0, state.typewriterIndex);

  if (state.typewriterIndex >= state.typewriterText.length) {
    finishTypewriter();
    return;
  }

  state.typewriterTimer = setTimeout(typeNextCharacter, getTypewriterDelay());
}

function getTypewriterDelay() {
  const currentCharacter = state.typewriterText[state.typewriterIndex - 1] || "";
  const line = state.activeDialogue[state.dialogueIndex] || {};
  const baseSpeed = line.speaker && line.speaker.includes("เวรีออน")
    ? TEACHER_DIALOGUE_SPEED
    : DIALOGUE_SPEED;

  return baseSpeed + (DIALOGUE_PUNCTUATION_PAUSE[currentCharacter] || 0);
}

function finishTypewriter() {
  stopTypewriter();
  els.dialogueText.textContent = state.typewriterText;
  state.isTypingDialogue = false;

  const line = state.activeDialogue[state.dialogueIndex];
  if (line && line.lessonChoices) {
    showLessonStoryChoices(line.lessonChoices);
    setDialogueButtonReady(false);
    return;
  }

  if (line && line.choices) {
    showDialogueChoices(line.choices);
    setDialogueButtonReady(false);
    return;
  }

  setDialogueButtonReady(true);
  if (line && line.requiresName && !getCharacterName()) {
    showNamePrompt();
  }
}

function showDialogueChoices(choices) {
  state.awaitingDialogueChoice = true;
  els.dialogueChoices.innerHTML = "";
  choices.forEach(choice => {
    const button = document.createElement("button");
    button.className = "dialogue-choice-btn";
    button.textContent = choice.text;
    button.addEventListener("click", () => chooseDialogueResponse(choice));
    els.dialogueChoices.appendChild(button);
  });
  els.dialogueChoices.classList.remove("hidden");
}

function hideDialogueChoices() {
  state.awaitingDialogueChoice = false;
  els.dialogueChoices.innerHTML = "";
  els.dialogueChoices.classList.add("hidden");
}

function chooseDialogueResponse(choice) {
  hideDialogueChoices();
  state.activeDialogue.splice(state.dialogueIndex + 1, 0, {
    speaker: "มาสเตอร์เวรีออน",
    text: choice.response
  });
  advanceDialogue();
}

function stopTypewriter() {
  if (state.typewriterTimer) {
    clearTimeout(state.typewriterTimer);
  }

  state.typewriterTimer = null;
}

function setDialogueButtonReady(isReady) {
  els.nextDialogueButton.disabled = !isReady;
  els.nextDialogueButton.setAttribute("aria-disabled", isReady ? "false" : "true");
  els.nextDialogueButton.classList.toggle("is-waiting", !isReady);
}

function updateSpeakingCharacter(speaker) {
  els.storyWanderer.classList.remove("is-speaking");
  els.storyVerion.classList.remove("is-speaking");

  if (speaker.includes("ผู้พเนจร")) {
    els.storyWanderer.classList.add("is-speaking");
  }

  if (speaker.includes("เวรีออน")) {
    els.storyVerion.classList.add("is-speaking");
  }
}

function clearSpeakingCharacters() {
  els.storyWanderer.classList.remove("is-speaking");
  els.storyVerion.classList.remove("is-speaking");
}

function triggerMotion(element, className) {
  element.classList.remove(className);
  void element.offsetWidth;
  element.classList.add(className);

  setTimeout(() => {
    element.classList.remove(className);
  }, 560);
}

function startStory() {
  if (state.isTransitioning) {
    return;
  }

  runSceneTransition("กำลังเข้าสู่หอคอยแห่ง Unity...", setupStoryScene);
}

function setupStoryScene() {
  stopTypewriter();
  state.dialogueIndex = 0;
  state.activeDialogue = buildStoryDialogue();
  state.awaitingName = false;
  state.awaitingDialogueChoice = false;
  hideDialogueChoices();
  hideNamePrompt();
  els.storyNameInput.value = "";
  els.dialoguePanel.classList.remove("hidden");
  els.dialogueActions.classList.remove("hidden");
  els.nounActivity.classList.add("hidden");
  els.nounActivityVisual.classList.add("hidden");
  updateLessonChrome(null, 0, "story");
  showScene("story");
  updatePlayerProgress({ progress: { currentScene: "story" } });
  updateDialogue();
}

function advanceDialogue() {
  if (state.isTransitioning) {
    return;
  }

  if (state.isTypingDialogue) {
    return;
  }

  if (state.awaitingName) {
    return;
  }

  if (state.awaitingDialogueChoice) {
    return;
  }

  if (state.lessonStoryMode) {
    advanceLessonStoryStep();
    return;
  }

  state.dialogueIndex += 1;

  if (state.dialogueIndex >= state.activeDialogue.length) {
    stopTypewriter();
    clearSpeakingCharacters();
    runSceneTransition("เสียงของถ้อยคำเริ่มกลับคืน...", () => {
      els.dialoguePanel.classList.add("hidden");
      els.dialogueActions.classList.add("hidden");
      startNounActivity();
    });
    return;
  }

  updateDialogue();
}

function startNounActivity() {
  showActInfoScreen();
}

function getPlayableStages() {
  return PAST_FRAGMENT_ACT.stages.filter(stage => !["story", "ending"].includes(stage.type));
}

function ensureActProgress() {
  if (!playerData) {
    return null;
  }

  const defaults = {
    introCompleted: false,
    tenseLessonCompleted: false,
    regularRulesCompleted: false,
    edMiniBossDefeated: false,
    irregularLessonCompleted: false,
    irregularMiniBossDefeated: false,
    twistSeen: false,
    finalBossDefeated: false,
    rewards: [],
    completedStages: [],
    fragments: [],
    grammariaEarned: 0,
    badge: ""
  };
  playerData.progress.pastFragmentAct = {
    ...defaults,
    ...(playerData.progress.pastFragmentAct || {})
  };
  return playerData.progress.pastFragmentAct;
}

function renderActionCards(items, className = "lesson-card") {
  els.wordGrid.innerHTML = "";
  items.forEach(item => {
    const card = document.createElement("div");
    card.className = `${className} ${getSpeakerToneClass(item)} ${getLessonCardRole(item)}`;
    card.textContent = item;
    els.wordGrid.appendChild(card);
  });
}

function showLessonSummaryModal(stage) {
  if (!stage) {
    return;
  }

  state.isLessonSummaryOpen = true;
  els.nounActivityVisual.querySelector("h3").textContent = stage.thaiTitle || stage.title;
  els.activityFeedback.textContent = "สรุปแนวคิดสำคัญ";
  renderActionCards(buildLessonDisplayItems(stage), "lesson-card");
  els.nounActivityVisual.classList.remove("hidden");
}

function getLessonCardRole(text = "") {
  if (text.includes("->") || text.includes("→") || text.includes("=")) {
    return "lesson-example";
  }

  if (text.startsWith("คำถาม:") || text.startsWith("ตรวจความเข้าใจ")) {
    return "lesson-question";
  }

  if (text.startsWith("ตัวเลือก:")) {
    return "lesson-choice";
  }

  return "";
}

function buildLessonDisplayItems(stage) {
  const items = (stage.lesson || []).flatMap(splitLessonItem);
  const firstQuestion = stage.questions && stage.questions[0];

  if (firstQuestion) {
    items.push("ตรวจความเข้าใจ");
    items.push(`คำถาม: ${firstQuestion.prompt || firstQuestion.sentence}`);
    firstQuestion.options.forEach(option => {
      items.push(`ตัวเลือก: ${option}`);
    });
  }

  return items;
}

function splitLessonItem(item) {
  if (!item || item.length < 92) {
    return [item];
  }

  return item
    .split(/(?<=[.!?])\s+|(?<=ครับ)\s+|(?<=ค่ะ)\s+|(?<=ก่อน)\s+/)
    .map(part => part.trim())
    .filter(Boolean);
}

function getSpeakerToneClass(text = "") {
  if (text.includes("ผู้พเนจร")) {
    return "speaker-player";
  }

  if (text.includes("มาสเตอร์เวรีออน") || text.includes("เวรีออน")) {
    return "speaker-verion";
  }

  return "speaker-system";
}

function updateLessonChrome(stage = null, stageIndex = 0, mode = "lesson") {
  const playableStages = getPlayableStages();
  const total = Math.max(playableStages.length, 1);
  const current = Math.min(stageIndex + 1, total);
  const location = stage
    ? (stage.thaiTitle || stage.title || "หอคอยแห่ง Unity")
    : "หอคอยแห่ง Unity";

  els.lessonActLabel.textContent = PAST_FRAGMENT_ACT.title;
  els.lessonLocationLabel.textContent = mode === "story" ? "หอคอยแห่ง Unity" : location;
  els.lessonProgressText.textContent = `${current} / ${total}`;
}

function closeExplanationPanel() {
  state.isLessonSummaryOpen = false;
  els.nounActivityVisual.classList.add("hidden");
}

function buildPastTeachingSteps() {
  return [
    {
      speaker: "มาสเตอร์เวรีออน",
      text: "ผู้พเนจรเอ๋ย ก่อนที่เราจะก้าวเข้าสู่ดินแดนแห่งอดีต เจ้าต้องเข้าใจก่อนว่า 'อดีต' คืออะไร"
    },
    {
      speaker: "มาสเตอร์เวรีออน",
      text: "หลายคนคิดว่าอดีตต้องเป็นเรื่องไกลตัว เช่น เมื่อวาน เดือนที่แล้ว หรือปีที่แล้ว แต่ความจริงแล้ว อดีตอาจอยู่ใกล้กว่านั้นมาก"
    },
    {
      speaker: "มาสเตอร์เวรีออน",
      text: "สิ่งใดก็ตามที่เกิดขึ้นแล้ว และจบลงแล้ว สิ่งนั้นคืออดีต"
    },
    {
      speaker: "มาสเตอร์เวรีออน",
      text: "หนึ่งวินาทีก่อนหน้านี้ ก็เป็นอดีต สิบนาทีก่อน ก็เป็นอดีต เมื่อเช้าที่ผ่านมา ก็เป็นอดีตเช่นกัน",
      visual: {
        title: "ตัวอย่างของอดีต",
        cards: ["1 วินาทีที่แล้ว", "10 นาทีที่แล้ว", "เมื่อเช้าที่ผ่านมา", "เมื่อวาน", "ปีที่แล้ว"]
      }
    },
    {
      speaker: "มาสเตอร์เวรีออน",
      text: "อดีตคือร่องรอยของสิ่งที่เคยเกิดขึ้น และภาษาคือเวทมนตร์ที่ช่วยให้เราบอกเล่าร่องรอยนั้นได้ถูกต้อง"
    },
    {
      speaker: "มาสเตอร์เวรีออน",
      text: "ถ้าอย่างนั้น เจ้าคิดว่าข้อใดเป็นอดีต?",
      lessonChoices: [
        {
          text: "สิ่งที่กำลังเกิดขึ้นตอนนี้",
          correct: false,
          response: "ยังไม่ใช่ ลองจำไว้ว่า อดีตต้องเป็นสิ่งที่เกิดขึ้นแล้ว และจบลงแล้ว"
        },
        {
          text: "สิ่งที่เกิดขึ้นแล้วและจบลงแล้ว",
          correct: true,
          response: "ถูกต้อง อดีตคือร่องรอยของสิ่งที่เกิดขึ้นแล้ว และจบลงแล้ว"
        },
        {
          text: "สิ่งที่ยังไม่เกิดขึ้น",
          correct: false,
          response: "ยังไม่ใช่ ลองจำไว้ว่า อดีตต้องเป็นสิ่งที่เกิดขึ้นแล้ว และจบลงแล้ว"
        }
      ]
    },
    {
      speaker: "มาสเตอร์เวรีออน",
      text: "คราวนี้ลองมองประโยคภาษาไทยสามประโยคนี้ เจ้าจะเห็นว่าเวลาในประโยคต่างกัน แม้คำกริยาจะยังดูคล้ายเดิม",
      visual: {
        title: "ตัวอย่างภาษาไทย",
        cards: ["ฉันกินข้าววันนี้", "ฉันกินข้าวเมื่อวาน", "ฉันจะกินข้าวพรุ่งนี้"]
      }
    },
    {
      speaker: "มาสเตอร์เวรีออน",
      text: "คำว่า วันนี้ บอกปัจจุบัน คำว่า เมื่อวาน บอกอดีต และคำว่า พรุ่งนี้ บอกอนาคต ภาษาไทยมักใช้คำบอกเวลาเหล่านี้ช่วยบอกว่าเหตุการณ์เกิดขึ้นตอนไหน",
      visual: {
        title: "คำบอกเวลา",
        cards: ["วันนี้ = ปัจจุบัน", "เมื่อวาน = อดีต", "พรุ่งนี้ = อนาคต"]
      }
    },
    {
      speaker: "มาสเตอร์เวรีออน",
      text: "แต่ภาษาอังกฤษต่างออกไปเล็กน้อย ภาษาอังกฤษไม่ได้ดูแค่คำบอกเวลาเท่านั้น แต่ยังดูรูปของคำกริยาด้วย",
      visual: {
        title: "English Tense",
        cards: [`I go. = ${TENSE_LABELS.present}`, `I went. = ${TENSE_LABELS.past}`, `I will go. = ${TENSE_LABELS.future}`],
        emphasize: true
      }
    },
    {
      speaker: "มาสเตอร์เวรีออน",
      text: "เมื่อเข้าใจอดีตแล้ว จงตอบคำถามเพื่อฟื้นคืน Time Spark แห่งดินแดนอดีต"
    }
  ];
}

function startPastDialogueLesson(stage) {
  state.lessonStoryMode = true;
  state.lessonStorySteps = buildPastTeachingSteps();
  state.lessonStoryStepIndex = 0;
  state.activeDialogue = [];
  state.dialogueIndex = 0;
  state.awaitingDialogueChoice = false;
  updateLessonChrome(stage, state.actStageIndex, "lesson");
  els.nounActivityVisual.classList.add("hidden");
  els.nounActivity.classList.add("hidden");
  els.dialoguePanel.classList.remove("hidden");
  els.dialogueActions.classList.remove("hidden");
  els.nextDialogueButton.classList.remove("hidden");
  els.storyNameForm.classList.add("hidden");
  els.nextDialogueButton.textContent = "ถัดไป";
  showScene("story");
  renderLessonStoryStep();
}

function renderLessonStoryStep() {
  const step = state.lessonStorySteps[state.lessonStoryStepIndex];
  if (!step) {
    finishPastDialogueLesson();
    return;
  }

  renderLessonStoryVisual(step.visual);
  hideDialogueChoices();
  state.activeDialogue = [step];
  state.dialogueIndex = 0;
  els.speakerName.textContent = step.speaker;
  updateSpeakingCharacter(step.speaker);
  updateDialogueSpeakerTone(step.speaker);
  els.nextDialogueButton.textContent = state.lessonStoryStepIndex >= state.lessonStorySteps.length - 1 ? "ตอบคำถาม" : "ถัดไป";
  startTypewriter(step.text);
}

function renderLessonStoryVisual(visual) {
  if (!visual) {
    els.lessonStoryVisual.classList.add("hidden");
    els.lessonStoryVisual.innerHTML = "";
    return;
  }

  const cards = visual.cards
    .map(card => `<div class="lesson-visual-card ${visual.emphasize ? "is-emphasis" : ""}">${card}</div>`)
    .join("");
  els.lessonStoryVisual.innerHTML = `<h3>${visual.title}</h3><div class="lesson-visual-grid">${cards}</div>`;
  els.lessonStoryVisual.classList.remove("hidden");
}

function showLessonStoryChoices(choices) {
  state.awaitingDialogueChoice = true;
  els.dialogueChoices.innerHTML = "";
  choices.forEach(choice => {
    const button = document.createElement("button");
    button.className = "dialogue-choice-btn";
    button.textContent = choice.text;
    button.addEventListener("click", () => chooseLessonStoryChoice(choice));
    els.dialogueChoices.appendChild(button);
  });
  els.dialogueChoices.classList.remove("hidden");
}

function chooseLessonStoryChoice(choice) {
  hideDialogueChoices();
  state.lessonStorySteps.splice(state.lessonStoryStepIndex + 1, 0, {
    speaker: "มาสเตอร์เวรีออน",
    text: choice.response
  });
  state.lessonStoryStepIndex += 1;
  renderLessonStoryStep();
}

function advanceLessonStoryStep() {
  state.lessonStoryStepIndex += 1;
  if (state.lessonStoryStepIndex >= state.lessonStorySteps.length) {
    finishPastDialogueLesson();
    return;
  }
  renderLessonStoryStep();
}

function finishPastDialogueLesson() {
  state.lessonStoryMode = false;
  state.lessonStorySteps = [];
  state.lessonStoryStepIndex = 0;
  els.lessonStoryVisual.classList.add("hidden");
  els.lessonStoryVisual.innerHTML = "";
  clearSpeakingCharacters();
  els.dialoguePanel.classList.add("hidden");
  els.dialogueActions.classList.add("hidden");
  startBattleFromActivity();
}

function buildGuidedLessonSteps(stage) {
  const steps = [];
  const lessonLines = (stage.lesson || []).flatMap(splitLessonItem);
  const firstQuestion = stage.questions && stage.questions[0];

  steps.push({
    type: "dialogue",
    speaker: "มาสเตอร์เวรีออน",
    text: stage.type === "final-boss"
      ? `${stage.enemy} กำลังทดสอบทุกความทรงจำของอดีต เตรียมทบทวนให้ชัดก่อนต่อสู้`
      : `วันนี้เราจะเรียนเรื่อง ${stage.thaiTitle || stage.title} ทีละขั้น`
  });

  lessonLines.forEach((line, index) => {
    if (line.includes("->") || line.includes("→") || line.includes("=")) {
      steps.push({
        type: "examples",
        title: "ตัวอย่างสำคัญ",
        cards: splitExampleCards(line)
      });
      return;
    }

    if (line.startsWith("มาสเตอร์เวรีออน:")) {
      steps.push({
        type: "dialogue",
        speaker: "มาสเตอร์เวรีออน",
        text: line.replace("มาสเตอร์เวรีออน:", "").trim()
      });
      return;
    }

    steps.push({
      type: index % 2 === 0 ? "dialogue" : "thought",
      speaker: index % 2 === 0 ? "มาสเตอร์เวรีออน" : "บทเรียน",
      text: line
    });
  });

  if (firstQuestion) {
    steps.push({
      type: "choice",
      speaker: "มาสเตอร์เวรีออน",
      text: firstQuestion.prompt || firstQuestion.sentence,
      choices: firstQuestion.options.map(option => ({
        text: option,
        correct: option === firstQuestion.answer,
        response: option === firstQuestion.answer
          ? `ถูกต้อง ${firstQuestion.explanation}`
          : `ยังไม่ใช่ คำตอบที่ถูกคือ ${firstQuestion.answer} ${firstQuestion.explanation}`
      }))
    });
  }

  steps.push({
    type: stage.questions && stage.questions.length ? "drill-intro" : "dialogue",
    speaker: "มาสเตอร์เวรีออน",
    text: stage.questions && stage.questions.length
      ? "เจ้าพร้อมแล้ว ต่อไปเป็นแบบฝึกสั้น ๆ ก่อนเผชิญพลังของอดีต"
      : "บทเรียนส่วนนี้เสร็จแล้ว เราจะไปยังขั้นต่อไป"
  });

  if (stage.questions && stage.questions.length) {
    steps.push({
      type: "battle-intro",
      speaker: "ระบบ",
      text: stage.type === "final-boss"
        ? `${stage.enemy} ปรากฏตัวแล้ว ใช้สิ่งที่เรียนทั้งหมดเพื่อฟื้นคืน Past Fragment`
        : `${stage.enemy || stage.thaiEnemy || "เงาความทรงจำ"} กำลังรออยู่ เริ่มฝึกเมื่อพร้อม`
    });
  }

  return steps;
}

function splitExampleCards(text) {
  return text
    .replace(/^Examples?:\s*/i, "")
    .split(/,\s*| \/ /)
    .map(item => item.trim())
    .filter(Boolean)
    .slice(0, 4);
}

function renderLessonStep() {
  const stage = state.currentLessonStage;
  const step = state.lessonSteps[state.lessonStepIndex];
  if (!stage || !step) {
    return;
  }

  state.isLessonSummaryOpen = false;
  els.nounActivityVisual.querySelector("h3").textContent = stage.thaiTitle || stage.title;
  els.activityFeedback.textContent = getLessonStepFeedback(step);
  els.wordGrid.innerHTML = "";
  els.nounActivityVisual.classList.remove("hidden");
  els.nounActivity.classList.remove("hidden");
  els.battleButton.classList.remove("hidden");

  if (step.type === "choice") {
    renderLessonChoiceStep(step);
    els.battleButton.classList.add("hidden");
    return;
  }

  if (step.type === "examples") {
    renderExampleCards(step);
  } else {
    renderLessonTextStep(step);
  }

  els.battleButton.textContent = getLessonStepButtonText(step);
  els.battleButton.onclick = advanceLessonStep;
}

function getLessonStepFeedback(step) {
  const labels = {
    dialogue: "มาสเตอร์เวรีออนกำลังอธิบาย",
    thought: "สรุปแนวคิดสำคัญ",
    examples: "ดูตัวอย่างทีละชุด",
    choice: "เลือกคำตอบของเจ้า",
    "drill-intro": "เตรียมเริ่มฝึก",
    "battle-intro": "พร้อมเข้าสู่การต่อสู้"
  };
  return labels[step.type] || "บทเรียน";
}

function getLessonStepButtonText(step) {
  if (step.type === "drill-intro") {
    return "เริ่มฝึก";
  }
  if (step.type === "battle-intro") {
    return "เริ่มต่อสู้";
  }
  return "ถัดไป";
}

function renderLessonTextStep(step) {
  const card = document.createElement("div");
  card.className = `lesson-step-card ${step.type === "thought" ? "lesson-thought-bubble" : "speaker-verion"}`;
  card.innerHTML = `<strong>${step.speaker || "บทเรียน"}</strong><span>${step.text}</span>`;
  els.wordGrid.appendChild(card);
}

function renderExampleCards(step) {
  const title = document.createElement("div");
  title.className = "lesson-step-card lesson-question";
  title.textContent = step.title || "ตัวอย่าง";
  els.wordGrid.appendChild(title);

  step.cards.forEach(example => {
    const card = document.createElement("div");
    card.className = "lesson-step-card lesson-example";
    card.textContent = example;
    els.wordGrid.appendChild(card);
  });
}

function renderLessonChoiceStep(step) {
  renderLessonTextStep(step);
  step.choices.forEach(choice => {
    const button = document.createElement("button");
    button.className = "lesson-choice-btn";
    button.textContent = choice.text;
    button.addEventListener("click", () => chooseLessonStepAnswer(choice));
    els.wordGrid.appendChild(button);
  });
}

function chooseLessonStepAnswer(choice) {
  els.wordGrid.innerHTML = "";
  const feedback = document.createElement("div");
  feedback.className = `lesson-step-card ${choice.correct ? "lesson-feedback-correct" : "lesson-feedback-wrong"}`;
  feedback.innerHTML = `<strong>${choice.correct ? "ถูกต้อง" : "ลองใหม่ในใจอีกครั้ง"}</strong><span>${choice.response}</span>`;
  els.wordGrid.appendChild(feedback);
  els.battleButton.textContent = "ถัดไป";
  els.battleButton.onclick = advanceLessonStep;
  els.battleButton.classList.remove("hidden");
}

function advanceLessonStep() {
  const step = state.lessonSteps[state.lessonStepIndex];
  if (step && step.type === "battle-intro") {
    startBattleFromActivity();
    return;
  }

  state.lessonStepIndex += 1;
  if (state.lessonStepIndex >= state.lessonSteps.length) {
    completeNonBattleStage(state.currentLessonStage);
    return;
  }
  renderLessonStep();
}

function showActInfoScreen() {
  state.actStageIndex = 0;
  state.isLessonSummaryOpen = false;
  updateLessonChrome(null, 0, "lesson");
  els.activityFeedback.textContent = "เมื่อจบ ACT นี้ ผู้เรียนสามารถใช้ V2 เพื่อเล่าเหตุการณ์ในอดีตได้";
  els.nounActivityVisual.querySelector("h3").textContent = PAST_FRAGMENT_ACT.title;
  renderActionCards([
    "Stage Progression",
    ...PAST_FRAGMENT_ACT.stages.map(stage => `${stage.title}${stage.thaiTitle ? ` / ${stage.thaiTitle}` : ""}`),
    "Learning Objectives",
    ...PAST_FRAGMENT_ACT.objectives
  ], "lesson-card");
  els.battleButton.textContent = "เริ่มภารกิจ";
  els.battleButton.classList.remove("hidden");
  els.battleButton.onclick = () => showStageLesson(0);

  els.nounActivity.classList.remove("hidden");
  els.nounActivityVisual.classList.remove("hidden");
  updatePlayerProgress({ progress: { currentScene: "pastFragmentActInfo" } });
}

function showStageLesson(stageIndex) {
  const stage = getPlayableStages()[stageIndex];
  if (!stage) {
    showActEnding();
    return;
  }

  state.actStageIndex = stageIndex;
  state.currentLessonStage = stage;
  state.lessonStepIndex = 0;
  state.lessonSteps = buildGuidedLessonSteps(stage);
  updateLessonChrome(stage, stageIndex, "lesson");
  if (stage.id === "what-is-past") {
    startPastDialogueLesson(stage);
    updatePlayerProgress({ progress: { currentScene: stage.id } });
    return;
  }

  state.lessonStoryMode = false;
  els.lessonStoryVisual.classList.add("hidden");
  els.lessonStoryVisual.innerHTML = "";
  renderLessonStep();
  updatePlayerProgress({ progress: { currentScene: stage.id } });
}

function completeNonBattleStage(stage) {
  state.lastStageResult = {
    correctAnswers: 0,
    totalQuestions: 0
  };
  grantActReward(stage);
  showStageReward(stage);
}

function startBattleFromActivity() {
  const stage = getPlayableStages()[state.actStageIndex] || getPlayableStages()[0];
  runSceneTransition(`${stage.enemy} ปรากฏตัว!`, () => startActBattle(state.actStageIndex));
}

function getQuestionText(question) {
  const phase = question.phase ? `[${question.phase}] ` : "";
  return phase + (question.sentence || question.prompt);
}

function startActBattle(stageIndex) {
  const stage = getPlayableStages()[stageIndex];
  const questionCount = stage.questions.length;
  const enemyMaxHp = stage.type === "final-boss" ? 140 : 100;
  state.actStageIndex = stageIndex;
  state.actBattle = {
    stage,
    questionIndex: 0,
    correctAnswers: 0,
    damagePerCorrect: Math.ceil(enemyMaxHp / questionCount),
    turnNumber: 1,
    awaitingParry: false,
    awaitingPrepare: false,
    pendingBossAction: null,
    pendingBossTurn: null,
    bossQuestionIndex: 0,
    pendingPlayerAttack: null,
    recentCharmIds: [],
    usedBossQuestionIds: new Set(),
    lastBossQuestionBaseVerb: "",
    simpleIrregularStreak: 0,
    bossStunned: false,
    bossWasStunnedLastTurn: false,
    correctStreak: 0
  };
  state.playerHp = 100;
  state.enemyMaxHp = enemyMaxHp;
  state.enemyHp = state.enemyMaxHp;
  state.grammaria = playerData ? playerData.grammaria || 0 : state.grammaria;
  state.sparkBonus = 0;
  resetBattleActiveEffects();
  els.battleTitle.textContent = stage.type === "final-boss" ? "Final Boss: The Memory Breaker" : stage.title;
  updateBattleEnemyVisual(stage);
  updateBattleStats();
  setActionButtonsEnabled(false);
  showScene("battle");
  showActBattleQuestion();
}

function showActBattleQuestion() {
  const battle = state.actBattle;
  const question = battle.stage.questions[battle.questionIndex];
  battle.pendingPlayerAttack = null;
  setBattleTurnOwner("player");
  els.continueBattleButton.classList.add("hidden");
  els.battleMessage.textContent = `${battle.stage.title} - คำถาม ${battle.questionIndex + 1} / ${battle.stage.questions.length}`;
  els.questionText.textContent = getQuestionText(question);
  els.answerOptions.innerHTML = "";

  let visibleOptions = [...question.options];
  const hintCount = Math.min(state.battleActiveEffects?.hint || 0, 2);
  if (hintCount > 0) {
    state.battleActiveEffects.hint = Math.max((state.battleActiveEffects.hint || 0) - hintCount, 0);
    const wrongOptions = visibleOptions.filter(option => option !== question.answer);
    const removedWrong = sample(wrongOptions, hintCount);
    visibleOptions = visibleOptions.filter(option => !removedWrong.includes(option));
    els.battleMessage.textContent += " | แสงชี้คำตอบลบตัวเลือกผิดออก 1 ข้อ";
  }

  if (state.battleActiveEffects.echoDamageNextTurn) {
    const echoDamage = state.battleActiveEffects.echoDamageNextTurn;
    state.battleActiveEffects.echoDamageNextTurn = 0;
    state.enemyHp = clamp(state.enemyHp - echoDamage, 0, state.enemyMaxHp);
    triggerEnemyHitFeedback(echoDamage);
    updateBattleStats();
    els.battleMessage.textContent += ` | เสียงสะท้อนสร้างดาเมจ ${echoDamage}`;
    if (state.enemyHp <= 0) {
      completeActStage();
      return;
    }
  }

  visibleOptions.forEach(option => {
    const button = document.createElement("button");
    button.className = "answer-button";
    button.textContent = option;
    button.addEventListener("click", () => chooseActAnswer(option));
    els.answerOptions.appendChild(button);
  });

  showOnlyBattlePanel(els.questionPanel);
}

function chooseActAnswer(option) {
  const battle = state.actBattle;
  const question = battle.stage.questions[battle.questionIndex];
  const isCorrect = option === question.answer;
  const feedback = document.createElement("div");
  feedback.className = "answer-feedback";

  els.answerOptions.querySelectorAll("button").forEach(button => {
    button.disabled = true;
    if (button.textContent === question.answer) {
      button.classList.add("correct");
    }
    if (button.textContent === option && !isCorrect) {
      button.classList.add("wrong");
    }
  });

  if (isCorrect) {
    setBattleTurnOwner("player");
    battle.correctAnswers += 1;
    battle.correctStreak = (battle.correctStreak || 0) + 1;
    const bonusGrammaria = consumeBattleEffectValue("nextCorrectBonusGrammaria", 0);
    battle.pendingPlayerAttack = {
      baseDamage: battle.damagePerCorrect,
      grammariaGain: 10 + bonusGrammaria
    };
    feedback.innerHTML = `<strong>คำตอบถูกต้อง!</strong><br>${question.explanation}`;
  } else {
    battle.correctStreak = 0;
    if (useBattleEffect("retry")) {
      els.answerOptions.querySelectorAll("button").forEach(button => {
        button.disabled = button.textContent === option;
        button.classList.remove("correct");
      });
      feedback.innerHTML = `<strong>ย้อนคิดทำงาน!</strong><br>คำตอบนี้ยังไม่ถูก แต่เจ้ามีโอกาสลองอีกครั้ง`;
      els.answerOptions.appendChild(feedback);
      els.battleMessage.textContent = "เครื่องรางย้อนคิดช่วยให้ลองตอบใหม่ในคำถามเดิม";
      return;
    }

    setBattleTurnOwner("enemy");
    state.playerHp = clamp(state.playerHp - 12, 0, 100);
    triggerMotion(els.battleEnemy, "enemy-attack-motion");
    feedback.innerHTML = `<strong>ยังไม่ถูกต้อง</strong><br>คำตอบที่ถูกคือ <strong>${question.answer}</strong><br>${question.explanation}`;
  }

  els.answerOptions.appendChild(feedback);
  updateBattleStats();
  syncBattleStateToPlayerData();
  battle.pendingBossAction = chooseActBossAction(battle);

  if (isCorrect) {
    els.battleMessage.textContent = "คำตอบถูกต้อง! เลือกเครื่องรางเพื่อเสริมพลังโจมตี";
    els.continueBattleButton.classList.add("hidden");
    setTimeout(showActCharmChoices, 650);
    return;
  }

  els.continueBattleButton.classList.add("hidden");
  setTimeout(startActBossWarning, 1100);
}

function showActCharmChoices() {
  const battle = state.actBattle;
  if (!battle || !battle.pendingPlayerAttack) {
    return;
  }

  els.charmOptions.innerHTML = "";
  selectRandomActCharms().forEach(charm => {
    const button = document.createElement("button");
    button.className = `charm-card rank-${charm.rank.toLowerCase()}`;
    const rankLabel = charmRankMeta[charm.rank] || charmRankMeta.C;
    button.innerHTML = `
      <span class="charm-topline">
        <span class="charm-icon" aria-hidden="true">${charm.icon || "✦"}</span>
        <span class="charm-rank">${rankLabel.label}</span>
      </span>
      <strong>${charm.name}</strong>
      <span class="charm-description">${charm.description || charm.effect}</span>
    `;
    button.addEventListener("click", () => chooseActCharmV2(charm));
    els.charmOptions.appendChild(button);
  });

  showOnlyBattlePanel(els.charmPanel);
}

function getBossKey(stage) {
  if (!stage) {
    return null;
  }
  if (stage.id === "ed-mini-boss" || stage.enemy === "The -ed Forger") {
    return "edForger";
  }
  if (stage.id === "irregular-mini-boss" || stage.enemy === "The Irregular Wraith") {
    return "irregularWraith";
  }
  if (stage.id === "final-boss" || stage.enemy === "The Memory Breaker") {
    return "memoryBreaker";
  }
  return null;
}

function getBossQuestion(stage) {
  const key = getBossKey(stage);
  const bank = key ? bossQuestionBanks[key] : null;
  if (!bank || !bank.length) {
    return null;
  }

  const battle = state.actBattle;
  if (!battle) {
    return sample(bank, 1)[0];
  }

  if (!battle.usedBossQuestionIds || battle.usedBossQuestionIds.size > Math.floor(bank.length * 0.8)) {
    battle.usedBossQuestionIds = new Set();
  }

  const weights = bossDifficultyWeights[key] || { medium: 50, hard: 35, boss: 15 };
  let preferredDifficulty = weightedPickFromTable(weights);
  let pool = bank.filter(question =>
    question.difficulty === preferredDifficulty &&
    !battle.usedBossQuestionIds.has(question.id) &&
    question.baseVerb !== battle.lastBossQuestionBaseVerb
  );

  if (key === "memoryBreaker" && battle.simpleIrregularStreak >= 2) {
    pool = pool.filter(question => !["irregular-v2", "mixed-rule"].includes(question.type));
  }

  if (!pool.length) {
    pool = bank.filter(question =>
      !battle.usedBossQuestionIds.has(question.id) &&
      question.baseVerb !== battle.lastBossQuestionBaseVerb
    );
  }

  if (!pool.length) {
    pool = bank.filter(question => !battle.usedBossQuestionIds.has(question.id));
  }

  if (!pool.length) {
    battle.usedBossQuestionIds.clear();
    pool = [...bank];
  }

  const question = sample(pool, 1)[0];
  battle.usedBossQuestionIds.add(question.id);
  battle.lastBossQuestionBaseVerb = question.baseVerb || "";
  battle.bossQuestionIndex += 1;

  if (key === "memoryBreaker" && question.type === "irregular-v2") {
    battle.simpleIrregularStreak = (battle.simpleIrregularStreak || 0) + 1;
  } else if (key === "memoryBreaker") {
    battle.simpleIrregularStreak = 0;
  }

  return question;
}

function showEnemyDamageFloat(amount, label = "") {
  if (!els.battleEnemy || !amount) {
    return;
  }

  const floater = document.createElement("span");
  floater.className = "damage-float";
  if (label === "CRIT") {
    floater.classList.add("crit");
  }
  floater.textContent = `${label}${label ? " " : ""}-${amount}`;
  floater.style.left = `${36 + Math.random() * 28}%`;
  floater.style.top = `${18 + Math.random() * 26}%`;
  els.battleEnemy.appendChild(floater);
  setTimeout(() => floater.remove(), 950);
}

function triggerEnemyHitFeedback(amount = 0, label = "") {
  if (amount <= 0) {
    return;
  }
  if (amount > 0) {
    showEnemyDamageFloat(amount, label);
  }
  if (els.battleEnemy) {
    els.battleEnemy.classList.remove("enemy-hit");
    void els.battleEnemy.offsetWidth;
    els.battleEnemy.classList.add("enemy-hit");
    setTimeout(() => els.battleEnemy.classList.remove("enemy-hit"), 460);
  }
}

function isPastQuestionContext() {
  const battle = state.actBattle;
  if (!battle) {
    return false;
  }
  const question = battle.stage.questions[battle.questionIndex];
  const questionText = `${getQuestionText(question)} ${battle.stage.title}`.toLowerCase();
  return ["past", "v2", "yesterday", "last", "ago", "did"].some(token => questionText.includes(token)) ||
    questionText.includes("อดีต");
}

function isMemoryEnemy(stage) {
  const text = `${stage?.enemy || ""} ${stage?.title || ""}`.toLowerCase();
  return ["memory", "time", "wraith", "shade", "breaker"].some(token => text.includes(token));
}

function rollCritical(extraChance = 0, force = false) {
  const effects = state.battleActiveEffects || {};
  const chance = clamp(BASE_CRITICAL_CHANCE + extraChance + (effects.criticalChanceBonus || 0), 0, 0.95);
  effects.criticalChanceBonus = 0;
  return force || Math.random() < chance;
}

function tryStunBoss(baseChance, lines) {
  const battle = state.actBattle;
  if (!battle || baseChance <= 0) {
    return false;
  }

  let chance = baseChance;
  if (battle.bossWasStunnedLastTurn) {
    chance *= 0.5;
    battle.bossWasStunnedLastTurn = false;
  }

  if (Math.random() < chance) {
    battle.bossStunned = true;
    addBattleMessageLine(lines, "บอสติด Stun! การโจมตีครั้งถัดไปถูกหยุดไว้");
    return true;
  }

  return false;
}

function applyCharmSetupEffect(charm, lines) {
  const effects = state.battleActiveEffects || {};

  switch (charm.effectType) {
    case "bonusGrammaria":
      return { bonusGrammaria: charm.value || 0 };
    case "healFlat":
      state.playerHp = clamp(state.playerHp + (charm.value || 0), 0, 100);
      addBattleMessageLine(lines, `ฟื้น HP +${charm.value || 0}`);
      break;
    case "conditionalHeal":
      if (state.playerHp <= 50) {
        state.playerHp = clamp(state.playerHp + (charm.value || 0), 0, 100);
        addBattleMessageLine(lines, `HP ต่ำกว่า 50% ฟื้น HP +${charm.value || 0}`);
      }
      break;
    case "healOnCorrect":
      state.playerHp = clamp(state.playerHp + (charm.value || 0), 0, 100);
      addBattleMessageLine(lines, `ตอบถูกแล้วฟื้น HP +${charm.value || 0}`);
      break;
    case "parrySlow":
      effects.parrySlow += 1;
      effects.parrySlowMultiplier = Math.min(effects.parrySlowMultiplier || 1, charm.value || 0.9);
      addBattleMessageLine(lines, "Parry ครั้งถัดไปช้าลง");
      break;
    case "parryZoneBonus":
      effects.parryWide += 1;
      effects.parryWideBonus = Math.max(effects.parryWideBonus || 0, charm.value || 0);
      addBattleMessageLine(lines, "ช่อง Parry ครั้งถัดไปกว้างขึ้น");
      break;
    case "nextDamageReduction":
      state.guardShield = Math.max(state.guardShield || 0, charm.value || 0);
      addBattleMessageLine(lines, `ลดดาเมจบอสครั้งถัดไป ${Math.round((charm.value || 0) * 100)}%`);
      break;
    case "memoryCharge":
      effects.memoryCharge += charm.value || 1;
      addBattleMessageLine(lines, `สะสม Memory Charge ${effects.memoryCharge}`);
      break;
    case "nextCorrectBonusGrammaria":
      effects.nextCorrectBonusGrammaria += charm.value || 0;
      addBattleMessageLine(lines, `คำตอบถูกครั้งถัดไปได้ Grammaria +${charm.value || 0}`);
      break;
    case "removeWrongChoice":
    case "showHintBeforeQuestion":
      effects.hint += charm.removeWrongChoice || charm.value || 1;
      addBattleMessageLine(lines, `คำถามถัดไปตัดตัวเลือกผิด ${charm.removeWrongChoice || charm.value || 1} ตัว`);
      break;
    case "secondChanceParry":
      effects.secondChance += 1;
      addBattleMessageLine(lines, "ถ้า Parry พลาด จะลดโทษให้ 1 ครั้ง");
      break;
    case "criticalChanceBonus":
      effects.criticalChanceBonus += charm.value || 0;
      addBattleMessageLine(lines, `เพิ่มโอกาส Critical +${Math.round((charm.value || 0) * 100)}%`);
      break;
    case "retryNextWrong":
      effects.retry += 1;
      addBattleMessageLine(lines, "ตอบผิดครั้งถัดไปจะได้ลองใหม่ 1 ครั้ง");
      break;
    case "applyMark":
      effects.markDamageBonus = Math.max(effects.markDamageBonus || 0, charm.value || 0);
      addBattleMessageLine(lines, "บอสติด Mark รับดาเมจเพิ่มในครั้งนี้");
      break;
    case "counterOnGoodParry":
      effects.counterOnGoodParry = Math.max(effects.counterOnGoodParry || 0, charm.value || 0);
      addBattleMessageLine(lines, "Good/Perfect Parry ครั้งถัดไปจะสวนกลับเพิ่ม");
      break;
    case "stunChance":
      effects.stunChance = Math.max(effects.stunChance || 0, charm.value || 0);
      addBattleMessageLine(lines, `มีโอกาส Stun บอส ${Math.round((charm.value || 0) * 100)}%`);
      break;
    case "stunOnCritical":
      effects.stunOnCriticalChance = Math.max(effects.stunOnCriticalChance || 0, charm.value || 0);
      addBattleMessageLine(lines, "ถ้า Critical จะมีโอกาสทำให้บอส Stun");
      break;
    case "lifesteal":
      effects.lifestealRatio = Math.max(effects.lifestealRatio || 0, charm.value || 0);
      addBattleMessageLine(lines, "โจมตีครั้งนี้จะดูดพลังกลับมา");
      break;
    case "applyWeak":
      effects.bossWeak = Math.max(effects.bossWeak || 0, charm.value || 0);
      effects.bossWeakTurns = Math.max(effects.bossWeakTurns || 0, charm.duration || 1);
      addBattleMessageLine(lines, "บอสติด Weak ดาเมจครั้งถัดไปลดลง");
      break;
    case "perfectParryNextDamage":
      effects.perfectParryNextDamage = Math.max(effects.perfectParryNextDamage || 0, charm.value || 1);
      addBattleMessageLine(lines, "Perfect Parry ครั้งถัดไปจะเร่งพลังโจมตี");
      break;
    case "blockIfGoodParry":
      effects.blockIfGoodParry += 1;
      addBattleMessageLine(lines, "ถ้า Parry ได้อย่างน้อย Good จะบล็อกดาเมจ");
      break;
    case "reflectNextBossAttack":
      effects.reflectNextBossAttack = Math.max(effects.reflectNextBossAttack || 0, charm.value || 0);
      addBattleMessageLine(lines, "บอสจะได้รับดาเมจสะท้อนจากการโจมตีครั้งถัดไป");
      break;
    case "upgradeNextParry":
      effects.upgradeNextParry += 1;
      addBattleMessageLine(lines, "ผล Parry ครั้งถัดไปจะถูกอัปเกรด 1 ระดับ");
      break;
    case "perfectTimeline":
      effects.stunOnPerfectParry = 1;
      effects.perfectTimelineCounterMultiplier = Math.max(effects.perfectTimelineCounterMultiplier || 1, charm.counterMultiplier || 2);
      addBattleMessageLine(lines, "Perfect Parry ครั้งถัดไปจะ Stun และสวนกลับแรงขึ้น");
      break;
    case "surviveFatalOnce":
      effects.surviveFatalOnce = true;
      effects.surviveFatalHealPercent = charm.value || charm.healPercent || 0.4;
      addBattleMessageLine(lines, "ได้รับพร Great Recall ป้องกันการล้ม 1 ครั้ง");
      break;
    case "fullMemoryBurst":
      state.playerHp = clamp(state.playerHp + (charm.healFlat || 25), 0, 100);
      effects.parryWide += 1;
      effects.parryWideBonus = Math.max(effects.parryWideBonus || 0, charm.parryZoneBonus || 10);
      addBattleMessageLine(lines, `ฟื้น HP +${charm.healFlat || 25} และ Parry ครั้งถัดไปกว้างขึ้น`);
      return { damageMultiplier: charm.damageMultiplier || 1.5 };
    case "verionSeal":
      effects.hint += charm.removeWrongChoice || 2;
      effects.forceCriticalNextAttack += 1;
      addBattleMessageLine(lines, "เวรีออนเปิดผนึก: ตัดตัวเลือกผิดและบังคับ Critical");
      break;
    default:
      break;
  }

  return {};
}

function calculateCharmDamage(charm, baseDamage, lines) {
  const battle = state.actBattle;
  const effects = state.battleActiveEffects || {};
  const setup = applyCharmSetupEffect(charm, lines);
  let damage = baseDamage;
  let echoRatio = 0;
  let delayedEchoRatio = 0;
  let extraGrammaria = setup.bonusGrammaria || 0;
  let stunChance = effects.stunChance || 0;
  let forceCritical = Boolean(effects.forceCriticalNextAttack);

  if (setup.damageMultiplier) {
    damage = Math.round(damage * setup.damageMultiplier);
  }

  switch (charm.effectType) {
    case "damageMultiplier":
      damage = Math.round(damage * (charm.value || 1));
      break;
    case "pastDamageBonus":
      if (isPastQuestionContext()) {
        damage = Math.round(damage * (charm.value || 1));
        addBattleMessageLine(lines, "Past/V2 bonus ทำงาน");
      }
      break;
    case "echoDamage":
      echoRatio = Math.max(echoRatio, charm.value || 0);
      break;
    case "firstTurnDamageBonus":
      if ((battle?.turnNumber || 1) === 1) {
        damage = Math.round(damage * (charm.value || 1));
        addBattleMessageLine(lines, "Opening bonus ทำงาน");
      }
      break;
    case "memoryEnemyBonus":
      if (isMemoryEnemy(battle?.stage)) {
        damage = Math.round(damage * (charm.value || 1));
        addBattleMessageLine(lines, "Memory enemy bonus ทำงาน");
      }
      break;
    case "shieldPierceDamage":
      damage = Math.round(damage * (charm.value || 1.2));
      break;
    case "stackingCorrectDamage":
      effects.stackingDamageBonus = clamp((effects.stackingDamageBonus || 0) + (charm.value || 0.05), 0, (charm.value || 0.05) * (charm.maxStacks || 5));
      damage = Math.round(damage * (1 + effects.stackingDamageBonus));
      addBattleMessageLine(lines, `วงเวทสะสมพลัง +${Math.round(effects.stackingDamageBonus * 100)}%`);
      break;
    case "comboCorrectEcho":
      if ((battle?.correctStreak || 0) >= 2) {
        echoRatio = Math.max(echoRatio, charm.value || 0.3);
        addBattleMessageLine(lines, "Echo combo ทำงาน");
      }
      break;
    case "bossQuestionBreak":
      damage = Math.round(damage * 1.15);
      addBattleMessageLine(lines, "Grammar Break เพิ่มดาเมจ");
      break;
    case "crystalCharge":
      effects.crystalCharge += charm.value || 1;
      addBattleMessageLine(lines, `Crystal Charge ${effects.crystalCharge}/3`);
      if (effects.crystalCharge >= (charm.threshold || 3)) {
        damage *= 2;
        effects.crystalCharge = 0;
        addBattleMessageLine(lines, "Crystal Charge ครบ 3: ดาเมจ x2");
      }
      break;
    case "delayedEchoDamage":
      delayedEchoRatio = Math.max(delayedEchoRatio, charm.value || 0.3);
      break;
    case "lowHpCriticalBonus":
      if (getPlayerHpPercent() <= 0.3) {
        effects.criticalChanceBonus += charm.value || 0;
        addBattleMessageLine(lines, "Low HP Critical bonus ทำงาน");
      }
      break;
    case "damageOnStunned":
      if (battle?.bossStunned) {
        damage = Math.round(damage * (charm.value || 1.5));
      }
      break;
    case "correctStreakDamage":
      if ((battle?.correctStreak || 0) >= 3) {
        damage = Math.round(damage * (charm.value || 1.75));
        addBattleMessageLine(lines, "ตอบถูก 3 ครั้งติดกัน: ดาเมจเพิ่ม");
      }
      break;
    case "rouletteDamage": {
      const values = charm.values || [0.7, 1.8];
      const multiplier = sample(values, 1)[0];
      damage = Math.round(damage * multiplier);
      addBattleMessageLine(lines, `Grammar Roulette x${multiplier}`);
      break;
    }
    case "damageAndReward":
      damage = Math.round(damage * (charm.damageMultiplier || 2));
      extraGrammaria += charm.bonusGrammaria || 15;
      break;
    case "v2Judgement":
      damage = Math.round(damage * (charm.damageMultiplier || 1.85));
      effects.bossWeak = Math.max(effects.bossWeak || 0, charm.applyWeak || 0.3);
      effects.bossWeakTurns = Math.max(effects.bossWeakTurns || 0, charm.duration || 1);
      break;
    default:
      break;
  }

  if (effects.markDamageBonus) {
    damage = Math.round(damage * (1 + effects.markDamageBonus));
    effects.markDamageBonus = 0;
  }

  if (effects.perfectParryDamageBonus) {
    damage = Math.round(damage * effects.perfectParryDamageBonus);
    effects.perfectParryDamageBonus = 0;
  }

  if (forceCritical) {
    effects.forceCriticalNextAttack = 0;
  }

  const isCrit = rollCritical(0, forceCritical);
  if (isCrit) {
    damage = Math.round(damage * CRITICAL_DAMAGE_MULTIPLIER);
    addBattleMessageLine(lines, "CRITICAL!");
    stunChance = Math.max(stunChance, effects.stunOnCriticalChance || 0);
  }
  effects.stunOnCriticalChance = 0;
  effects.stunChance = 0;

  const echoDamage = Math.round(damage * echoRatio);
  const totalDamage = damage + echoDamage;
  if (echoDamage) {
    addBattleMessageLine(lines, `Echo Damage +${echoDamage}`);
  }

  if (delayedEchoRatio) {
    effects.echoDamageNextTurn += Math.round(totalDamage * delayedEchoRatio);
    addBattleMessageLine(lines, "Time Echo จะย้อนกลับไปโจมตีอีกครั้งในเทิร์นถัดไป");
  }

  const healFromLifesteal = Math.round(totalDamage * (effects.lifestealRatio || 0));
  if (healFromLifesteal) {
    state.playerHp = clamp(state.playerHp + healFromLifesteal, 0, 100);
    effects.lifestealRatio = 0;
    addBattleMessageLine(lines, `ดูดพลังฟื้น HP +${healFromLifesteal}`);
  }

  return { totalDamage, grammariaBonus: extraGrammaria, isCrit, stunChance };
}

function chooseActCharmV2(charm) {
  const battle = state.actBattle;
  if (!battle || !battle.pendingPlayerAttack) {
    return;
  }

  const rankLabel = charmRankMeta[charm.rank]?.label || `[${charm.rank}]`;
  const bonusLines = [`เลือก ${rankLabel} ${charm.name}`];
  const { totalDamage, grammariaBonus, isCrit, stunChance } = calculateCharmDamage(charm, battle.pendingPlayerAttack.baseDamage, bonusLines);
  const grammariaGain = battle.pendingPlayerAttack.grammariaGain + grammariaBonus;

  triggerMotion(els.battlePlayer, "player-attack-motion");
  state.enemyHp = clamp(state.enemyHp - totalDamage, 0, state.enemyMaxHp);
  triggerEnemyHitFeedback(totalDamage, isCrit ? "CRIT" : "");
  state.grammaria += grammariaGain;
  battle.pendingPlayerAttack = null;

  tryStunBoss(stunChance, bonusLines);

  updateBattleStats();
  syncBattleStateToPlayerData();
  showOnlyBattlePanel(null);
  els.battleMessage.textContent = `${bonusLines.join("\n")}\nผู้พเนจรร่าย Grammaria สร้างดาเมจ ${totalDamage} และได้รับ Grammaria +${grammariaGain}`;

  if (state.enemyHp <= 0) {
    els.continueBattleButton.textContent = "รับรางวัล";
    els.continueBattleButton.onclick = completeActStage;
    els.continueBattleButton.classList.remove("hidden");
    return;
  }

  if (charm.effectType === "extraTurnChance" && Math.random() < (charm.value || 0)) {
    els.battleMessage.textContent += "\nTime Skip ทำงาน! ได้เล่นต่อทันที";
    els.continueBattleButton.textContent = battle.questionIndex >= battle.stage.questions.length - 1 ? "รับรางวัล" : "คำถามถัดไป";
    els.continueBattleButton.onclick = continueActBattle;
    els.continueBattleButton.classList.remove("hidden");
    return;
  }

  els.continueBattleButton.classList.add("hidden");
  setTimeout(startActBossWarning, 900);
}

function chooseActCharm(charm) {
  const battle = state.actBattle;
  if (!battle || !battle.pendingPlayerAttack) {
    return;
  }

  let damage = battle.pendingPlayerAttack.baseDamage;
  let grammariaGain = battle.pendingPlayerAttack.grammariaGain;
  const bonusLines = [`เลือก ${charm.name}`];

  if (charm.id === "actPower") {
    damage = Math.round(damage * 1.25);
    bonusLines.push("พลังโจมตีเพิ่มขึ้น");
  }

  if (charm.id === "actGrammaria") {
    grammariaGain += 10;
    bonusLines.push("Grammaria ฟื้นคืนเพิ่มขึ้น");
  }

  if (charm.id === "actWeaken") {
    state.guardShield = Math.max(state.guardShield, 0.3);
    bonusLines.push("การโจมตีถัดไปของศัตรูอ่อนแรงลง");
  }

  if (charm.id === "actEcho") {
    damage += 7;
    bonusLines.push("เกิดการโจมตีซ้ำเล็กน้อย");
  }

  if (charm.id === "doubleHit") {
    const extraDamage = Math.max(4, Math.round(damage * 0.35));
    damage += extraDamage;
    bonusLines.push(`จังหวะซ้ำสร้างดาเมจเพิ่ม ${extraDamage}`);
  }

  if (charm.id === "heal") {
    state.playerHp = clamp(state.playerHp + 12, 0, 100);
    bonusLines.push("HP ฟื้นฟู 12 หน่วย");
  }

  if (charm.id === "parrySlow") {
    state.battleActiveEffects.parrySlow += 1;
    bonusLines.push("แพรี่ครั้งถัดไปจะช้าลง");
  }

  if (charm.id === "parryWide") {
    state.battleActiveEffects.parryWide += 1;
    bonusLines.push("โซนแพรี่ครั้งถัดไปกว้างขึ้น");
  }

  if (charm.id === "secondChance") {
    state.battleActiveEffects.secondChance += 1;
    bonusLines.push("ถ้าแพรี่พลาด จะลดดาเมจลงครึ่งหนึ่ง");
  }

  if (charm.id === "hint") {
    state.battleActiveEffects.hint += 1;
    bonusLines.push("คำถามถัดไปจะลบตัวเลือกผิด 1 ข้อ");
  }

  if (charm.id === "retry") {
    state.battleActiveEffects.retry += 1;
    bonusLines.push("ตอบผิดครั้งถัดไปจะได้ลองใหม่");
  }

  if (charm.id === "pastBonus") {
    const questionText = `${getQuestionText(battle.stage.questions[battle.questionIndex])} ${battle.stage.title}`.toLowerCase();
    if (questionText.includes("past") || questionText.includes("v2") || questionText.includes("อดีต")) {
      damage = Math.round(damage * 1.3);
      grammariaGain += 6;
      bonusLines.push("พลัง Past/V2 ทำงาน");
    } else {
      state.battleActiveEffects.echoDamageNextTurn += 6;
      bonusLines.push("เก็บเสียงสะท้อนไว้สร้างดาเมจในเทิร์นถัดไป");
    }
  }

  triggerMotion(els.battlePlayer, "player-attack-motion");
  state.enemyHp = clamp(state.enemyHp - damage, 0, state.enemyMaxHp);
  triggerEnemyHitFeedback(damage);
  state.grammaria += grammariaGain;
  battle.pendingPlayerAttack = null;

  updateBattleStats();
  syncBattleStateToPlayerData();
  showOnlyBattlePanel(null);
  els.battleMessage.textContent = `${bonusLines.join("\n")}\nผู้พเนจรร่าย Grammaria สร้างดาเมจ ${damage} และได้รับ Grammaria +${grammariaGain}`;

  if (state.enemyHp <= 0) {
    els.continueBattleButton.textContent = "รับรางวัล";
    els.continueBattleButton.onclick = completeActStage;
    els.continueBattleButton.classList.remove("hidden");
    return;
  }

  els.continueBattleButton.classList.add("hidden");
  setTimeout(startActBossWarning, 900);
}

function chooseActBossAction(battle) {
  const hpPercent = state.enemyHp / state.enemyMaxHp;
  const bossKey = getBossKey(battle.stage);
  const patterns = bossKey ? bossActionPatterns[bossKey] : null;
  let baseAction = BOSS_ACTIONS[0];

  if (battle.stage.type === "final-boss" && (hpPercent <= 0.35 || battle.turnNumber % 5 === 0)) {
    baseAction = BOSS_ACTIONS.find(action => action.type === "ultimate");
  } else if (battle.stage.type.includes("boss") && battle.turnNumber % 5 === 0) {
    baseAction = BOSS_ACTIONS.find(action => action.type === "ultimate");
  } else if (battle.stage.type.includes("boss") && battle.turnNumber % 3 === 0) {
    baseAction = BOSS_ACTIONS.find(action => action.type === "skill");
  }

  if (!patterns) {
    return { ...baseAction, sequence: ["attack"], bossKey: null };
  }

  const pattern = baseAction.type === "ultimate"
    ? (bossKey === "memoryBreaker" ? ["question", "question", "attack"] : ["question", "attack"])
    : sample(patterns, 1)[0];

  return {
    ...baseAction,
    sequence: [...pattern],
    bossKey
  };
}

function startActBossWarning() {
  const battle = state.actBattle;
  if (!battle || !battle.pendingBossAction) {
    return;
  }

  if (battle.bossStunned) {
    battle.bossStunned = false;
    battle.bossWasStunnedLastTurn = true;
    battle.pendingBossAction = null;
    battle.pendingBossTurn = null;
    battle.turnNumber += 1;
    showOnlyBattlePanel(null);
    setBattleTurnOwner("player");
    els.battleMessage.textContent = "บอสติด Stun! การโจมตีครั้งถัดไปถูกหยุดไว้";
    els.continueBattleButton.textContent = battle.questionIndex >= battle.stage.questions.length - 1 ? "รับรางวัล" : "คำถามถัดไป";
    els.continueBattleButton.onclick = continueActBattle;
    els.continueBattleButton.classList.remove("hidden");
    return;
  }

  const action = battle.pendingBossAction;
  battle.pendingBossTurn = {
    action,
    sequence: [...(action.sequence || ["attack"])],
    stepIndex: 0,
    correctQuestions: 0,
    wrongQuestions: 0
  };

  runNextBossTurnStep();
}

function runNextBossTurnStep() {
  const battle = state.actBattle;
  if (!battle || !battle.pendingBossTurn) {
    return;
  }

  const turn = battle.pendingBossTurn;
  if (turn.stepIndex >= turn.sequence.length) {
    finishBossTurn();
    return;
  }

  const step = turn.sequence[turn.stepIndex];
  turn.stepIndex += 1;

  if (step === "question") {
    showBossQuestionStep();
    return;
  }

  showBossAttackStep();
}

function showBossAttackStep() {
  const battle = state.actBattle;
  if (!battle || !battle.pendingBossAction) {
    return;
  }

  const action = battle.pendingBossAction;
  const bossLine = battle.stage.bossDialogueLines
    ? `\n${battle.stage.bossDialogueLines[(battle.turnNumber - 1) % battle.stage.bossDialogueLines.length]}`
    : "";
  const extraWarning = action.type === "ultimate"
    ? "\nอัลติเมทกำลังมา โซนแพรี่จะแคบและไวมาก!"
    : action.type === "skill"
      ? "\nสกิลแรงกำลังมา ตั้งสมาธิก่อนเริ่มแพรี่!"
      : "\nกดเตรียมพร้อมเมื่อพร้อมเข้าสู่จังหวะแพรี่";

  battle.awaitingPrepare = true;
  showOnlyBattlePanel(null);
  setBattleTurnOwner("enemy");
  els.battleMessage.textContent = `${action.warning}${extraWarning}${bossLine}`;
  els.continueBattleButton.textContent = "เตรียมพร้อม";
  els.continueBattleButton.onclick = prepareActParry;
  els.continueBattleButton.classList.remove("hidden");
}

function showBossQuestionStep() {
  const battle = state.actBattle;
  const question = battle && getBossQuestion(battle.stage);
  if (!battle || !question) {
    runNextBossTurnStep();
    return;
  }

  showOnlyBattlePanel(els.questionPanel);
  setBattleTurnOwner("enemy");
  els.continueBattleButton.classList.add("hidden");
  els.battleMessage.textContent = "บอส: “ถ้าเจ้าจำอดีตผิด ความทรงจำก็จะแตกสลาย... ตอบข้ามา!”";
  els.questionText.textContent = getQuestionText(question);
  els.answerOptions.innerHTML = "";

  question.options.forEach(option => {
    const button = document.createElement("button");
    button.className = "answer-button";
    button.textContent = option;
    button.addEventListener("click", () => chooseBossQuestionAnswer(option, question));
    els.answerOptions.appendChild(button);
  });
}

function chooseBossQuestionAnswer(option, question) {
  const battle = state.actBattle;
  if (!battle || !battle.pendingBossTurn || !battle.pendingBossAction) {
    return;
  }

  const isCorrect = option === question.answer;
  const feedback = document.createElement("div");
  feedback.className = "answer-feedback";

  els.answerOptions.querySelectorAll("button").forEach(button => {
    button.disabled = true;
    if (button.textContent === question.answer) {
      button.classList.add("correct");
    }
    if (button.textContent === option && !isCorrect) {
      button.classList.add("wrong");
    }
  });

  if (isCorrect) {
    battle.pendingBossTurn.correctQuestions += 1;
    battle.pendingBossAction.damage = Math.max(4, battle.pendingBossAction.damage - 7);
    feedback.innerHTML = `<strong>คำตอบถูกต้อง!</strong><br>เจ้าต้านพลังของบอสได้<br>${question.explanation}`;
  } else {
    battle.pendingBossTurn.wrongQuestions += 1;
    battle.pendingBossAction.damage += 6;
    const chipDamage = battle.stage.type === "final-boss" ? 10 : 7;
    state.playerHp = clamp(state.playerHp - chipDamage, 0, 100);
    triggerMotion(els.battleEnemy, "enemy-attack-motion");
    feedback.innerHTML = `<strong>ยังไม่ถูกต้อง!</strong><br>บอสโจมตีแรงขึ้น คำตอบที่ถูกคือ <strong>${question.answer}</strong><br>${question.explanation}`;
  }

  els.answerOptions.appendChild(feedback);
  updateBattleStats();
  syncBattleStateToPlayerData();
  els.battleMessage.textContent = isCorrect
    ? "คำตอบถูกต้อง! พลังโจมตีของบอสอ่อนลง"
    : "ยังไม่ถูกต้อง! บอสสะสมพลังโจมตีเพิ่มขึ้น";
  els.continueBattleButton.textContent = "ดำเนินต่อ";
  els.continueBattleButton.onclick = runNextBossTurnStep;
  els.continueBattleButton.classList.remove("hidden");
}

function finishBossTurn() {
  const battle = state.actBattle;
  if (!battle) {
    return;
  }

  finalizeBossTurnState();
  showOnlyBattlePanel(null);
  setBattleTurnOwner("player");

  if (state.playerHp <= 0) {
    state.playerHp = 35;
    updateBattleStats();
    els.battleMessage.textContent += "\nมาสเตอร์เวรีออนประคองความทรงจำไว้ เจ้าลุกขึ้นพร้อมพลังชีวิต 35";
  }

  els.continueBattleButton.textContent = battle.questionIndex >= battle.stage.questions.length - 1 || state.enemyHp <= 0 ? "รับรางวัล" : "คำถามถัดไป";
  els.continueBattleButton.onclick = continueActBattle;
  els.continueBattleButton.classList.remove("hidden");
}

function finalizeBossTurnState() {
  const battle = state.actBattle;
  if (!battle) {
    return;
  }
  battle.awaitingParry = false;
  battle.awaitingPrepare = false;
  battle.pendingBossAction = null;
  battle.pendingBossTurn = null;
  battle.turnNumber += 1;
}

function prepareActParry() {
  const battle = state.actBattle;
  if (!battle || !battle.pendingBossAction || !battle.awaitingPrepare) {
    return;
  }

  battle.awaitingPrepare = false;
  els.continueBattleButton.classList.add("hidden");
  els.battleMessage.textContent = "จับจังหวะเส้นสีขาวให้เข้าโซนเป้าหมาย ส้ม/เหลือง/เขียว...";
  setBattleTurnOwner("enemy");
  setTimeout(beginActParryPhase, battle.pendingBossAction.type === "ultimate" ? 700 : 450);
}

function beginActParryPhase() {
  const battle = state.actBattle;
  if (!battle || !battle.pendingBossAction) {
    return;
  }

  const action = battle.pendingBossAction;
  const effects = state.battleActiveEffects || {};
  const slowBonus = useBattleEffect("parrySlow") ? (1 / Math.max(effects.parrySlowMultiplier || 0.9, 0.5)) : 1;
  const wideBonus = useBattleEffect("parryWide") ? (effects.parryWideBonus || 8) : 0;
  effects.parrySlowMultiplier = 1;
  effects.parryWideBonus = 0;
  const adjustedZoneWidth = Math.min(action.zoneWidth + wideBonus, 46);
  battle.awaitingParry = true;
  setBattleTurnOwner("enemy");
  state.parry = {
    active: true,
    inputLocked: false,
    gaugeProgress: 0,
    gaugeDirection: 1,
    gaugeLastTime: null,
    gaugeFrame: null,
    gaugeSpeed: action.speed * slowBonus,
    zoneMoves: true,
    gaugeZoneInitialWidth: adjustedZoneWidth,
    gaugeZoneWidth: adjustedZoneWidth,
    gaugeZoneMinWidth: action.minZoneWidth,
    gaugeZoneShrinkPerSecond: action.shrinkPerSecond,
    gaugeZoneStart: Math.random() * (100 - adjustedZoneWidth),
    gaugeZoneDirection: Math.random() < 0.5 ? -1 : 1,
    gaugeZoneSpeed: action.zoneSpeed,
    tickTimeout: null,
    resolveTimeout: null
  };

  els.enemyAttackName.textContent = action.label;
  els.parryHitText.textContent = `Turn ${battle.turnNumber}`;
  els.parryCountdown.textContent = action.type === "ultimate" ? "ULT" : "TAP";
  els.parryHitResult.textContent = "";
  els.parryGaugeZone.style.width = `${adjustedZoneWidth}%`;
  els.parryGaugeZone.style.left = `${state.parry.gaugeZoneStart}%`;
  els.parryButton.disabled = false;
  showOnlyBattlePanel(els.parryPanel);
  startParryGauge();
  state.parry.resolveTimeout = setTimeout(() => stopActParry("MISS"), action.parryDuration);
}

function stopActParry(forcedResult = null) {
  const battle = state.actBattle;
  if (!battle || !battle.awaitingParry || !state.parry) {
    return;
  }

  const action = battle.pendingBossAction;
  let parryResult = forcedResult || parryGaugeResult(state.parry.gaugeProgress);
  let damage = action.damage;
  let counterDamage = 0;
  const effects = state.battleActiveEffects || {};

  if (parryResult === "MISS" && useBattleEffect("secondChance")) {
    parryResult = "WEAK";
  }

  if (effects.upgradeNextParry) {
    const upgradeMap = { MISS: "WEAK", WEAK: "GOOD", GOOD: "PERFECT", PERFECT: "PERFECT" };
    parryResult = upgradeMap[parryResult] || parryResult;
    effects.upgradeNextParry -= 1;
  }

  if (parryResult === "PERFECT") {
    damage = 0;
    counterDamage = 8;
  } else if (parryResult === "GOOD") {
    damage = Math.round(action.damage * 0.4);
  } else if (parryResult === "WEAK") {
    damage = Math.round(action.damage * 0.6);
  }

  if (effects.bossWeak) {
    damage = Math.round(damage * (1 - effects.bossWeak));
    effects.bossWeakTurns = Math.max((effects.bossWeakTurns || 1) - 1, 0);
    if (!effects.bossWeakTurns) {
      effects.bossWeak = 0;
    }
  }

  if ((parryResult === "GOOD" || parryResult === "PERFECT") && effects.blockIfGoodParry) {
    damage = 0;
    effects.blockIfGoodParry -= 1;
  }

  if ((parryResult === "GOOD" || parryResult === "PERFECT") && effects.counterOnGoodParry) {
    counterDamage += Math.max(1, Math.round(action.damage * effects.counterOnGoodParry));
    effects.counterOnGoodParry = 0;
  }

  if (parryResult === "PERFECT" && effects.perfectParryNextDamage) {
    effects.perfectParryDamageBonus = Math.max(effects.perfectParryDamageBonus || 0, effects.perfectParryNextDamage);
    effects.perfectParryNextDamage = 0;
  }

  if (parryResult === "PERFECT" && effects.stunOnPerfectParry) {
    counterDamage = Math.round(counterDamage * (effects.perfectTimelineCounterMultiplier || 2));
    tryStunBoss(1, []);
    effects.stunOnPerfectParry = 0;
    effects.perfectTimelineCounterMultiplier = 1;
  }

  if (effects.reflectNextBossAttack) {
    const reflectedDamage = Math.max(1, Math.round(action.damage * effects.reflectNextBossAttack));
    counterDamage += reflectedDamage;
    effects.reflectNextBossAttack = 0;
  }

  if (state.shield > 0) {
    damage = Math.round(damage * (1 - state.shield));
    state.shield = 0;
  }

  if (state.guardShield > 0) {
    damage = Math.round(damage * (1 - state.guardShield));
    state.guardShield = 0;
  }

  state.playerHp = clamp(state.playerHp - damage, 0, 100);
  if (state.playerHp <= 0 && effects.surviveFatalOnce) {
    effects.surviveFatalOnce = false;
    const healAmount = Math.max(1, Math.round(100 * (effects.surviveFatalHealPercent || 0.4)));
    state.playerHp = clamp(1 + healAmount, 1, 100);
    damage = 0;
  }
  state.enemyHp = clamp(state.enemyHp - counterDamage, 0, state.enemyMaxHp);
  battle.awaitingParry = false;
  battle.awaitingPrepare = false;
  stopParryCountdown();
  if (counterDamage) {
    triggerMotion(els.battlePlayer, "player-attack-motion");
    triggerEnemyHitFeedback(counterDamage);
  } else {
    triggerMotion(els.battleEnemy, "enemy-attack-motion");
  }
  updateBattleStats();
  syncBattleStateToPlayerData();
  showOnlyBattlePanel(null);
  setBattleTurnOwner("player");

  els.battleMessage.textContent = `${thaiParryName(parryResult)} - รับดาเมจ ${damage}${counterDamage ? ` และสวนกลับ ${counterDamage}` : ""}`;
  if (state.enemyHp <= 0) {
    els.continueBattleButton.textContent = "รับรางวัล";
    els.continueBattleButton.onclick = completeActStage;
    els.continueBattleButton.classList.remove("hidden");
    return;
  }

  const hasMoreBossSteps = battle.pendingBossTurn && battle.pendingBossTurn.stepIndex < battle.pendingBossTurn.sequence.length;
  if (!hasMoreBossSteps) {
    finalizeBossTurnState();
    if (state.playerHp <= 0) {
      state.playerHp = 35;
      updateBattleStats();
      els.battleMessage.textContent += "\nมาสเตอร์เวรีออนประคองความทรงจำไว้ เจ้าลุกขึ้นพร้อมพลังชีวิต 35";
    }
  }
  els.continueBattleButton.textContent = hasMoreBossSteps ? "ดำเนินต่อ" : (battle.questionIndex >= battle.stage.questions.length - 1 ? "รับรางวัล" : "คำถามถัดไป");
  els.continueBattleButton.onclick = hasMoreBossSteps ? runNextBossTurnStep : continueActBattle;
  els.continueBattleButton.classList.remove("hidden");
}

function continueActBattle() {
  const battle = state.actBattle;
  els.continueBattleButton.classList.add("hidden");
  battle.questionIndex += 1;

  if (battle.questionIndex >= battle.stage.questions.length && battle.stage.type === "final-boss" && state.enemyHp > 0) {
    els.battleMessage.textContent = "The Memory Breaker ยังไม่สลาย ความทรงจำต้องการคำตอบที่ถูกต้องมากกว่านี้";
    state.playerHp = 100;
    state.enemyHp = state.enemyMaxHp;
    battle.questionIndex = 0;
    battle.correctAnswers = 0;
    updateBattleStats();
    els.continueBattleButton.textContent = "ลองต่อสู้อีกครั้ง";
    els.continueBattleButton.onclick = showActBattleQuestion;
    els.continueBattleButton.classList.remove("hidden");
    return;
  }

  if (battle.questionIndex >= battle.stage.questions.length || state.enemyHp <= 0) {
    completeActStage();
    return;
  }

  if (state.playerHp <= 0) {
    state.playerHp = 35;
    updateBattleStats();
    els.battleMessage.textContent = "มาสเตอร์เวรีออนประคองความทรงจำไว้ เจ้าลุกขึ้นพร้อมพลังชีวิต 35";
  }

  showActBattleQuestion();
}

function addUniqueActValue(list, value) {
  if (!list.includes(value)) {
    list.push(value);
  }
}

function grantActReward(stage) {
  const progress = ensureActProgress();
  if (!progress) {
    return;
  }

  const alreadyCompleted = progress.completedStages.includes(stage.id);
  addUniqueActValue(progress.completedStages, stage.id);
  if (stage.completionKey) {
    progress[stage.completionKey] = true;
  }
  if (stage.reward && stage.reward.fragment) {
    addUniqueActValue(progress.fragments, stage.reward.fragment);
    addUniqueActValue(progress.rewards, stage.reward.fragment);
  }
  if (!alreadyCompleted && stage.reward) {
    progress.grammariaEarned += stage.reward.grammaria || 0;
    playerData.grammaria = (playerData.grammaria || 0) + (stage.reward.grammaria || 0);
  }
  if (stage.reward && stage.reward.badge) {
    progress.badge = stage.reward.badge;
    addUniqueActValue(progress.rewards, `Badge: ${stage.reward.badge}`);
  }

  playerData.progress.currentScene = stage.id === "final-boss" ? "pastFragmentVictory" : "pastFragmentStageComplete";
  savePlayerData();
}

function completeActStage() {
  const battle = state.actBattle;
  const stage = battle.stage;
  state.lastStageResult = {
    correctAnswers: battle.correctAnswers,
    totalQuestions: stage.questions.length
  };
  grantActReward(stage);
  state.actBattle = null;
  state.grammaria = playerData ? playerData.grammaria || state.grammaria : state.grammaria;

  if (stage.type === "final-boss") {
    showActEnding();
    return;
  }

  runSceneTransition(`ได้รับ ${stage.reward.fragment}`, () => showStageReward(stage));
}

function showStageReward(stage) {
  const nextIndex = state.actStageIndex + 1;
  state.isLessonSummaryOpen = false;
  const rewardLines = [
    state.lastStageResult.totalQuestions
      ? `คำตอบถูกต้อง: ${state.lastStageResult.correctAnswers} / ${state.lastStageResult.totalQuestions}`
      : "บทเรียนเสร็จสิ้น",
    `Fragment: ${stage.reward.fragment}`,
    `Grammaria: +${stage.reward.grammaria}`
  ];

  if (stage.id === "ed-mini-boss") {
    rewardLines.push(
      "มาสเตอร์เวรีออน: ดีมาก ผู้พเนจร โรงหลอม -ed เริ่มกลับมาจดจำกฎของมันได้อีกครั้งแล้ว",
      "มาสเตอร์เวรีออน: แต่เส้นทางของอดีตยังไม่สิ้นสุด คำกริยาบางคำไม่ยอมเดินตามกฎของ -ed",
      "มาสเตอร์เวรีออน: ต่อจากนี้ เจ้าจะได้พบกับคำกริยาที่เปลี่ยนรูปไปเอง กริยาเหล่านั้นเรียกว่า Irregular Verbs"
    );
  }

  updateLessonChrome(stage, state.actStageIndex, "lesson");
  els.nounActivityVisual.querySelector("h3").textContent = "ได้รับ Fragment";
  els.activityFeedback.textContent = `ได้รับ ${stage.reward.fragment} และ Grammaria +${stage.reward.grammaria}`;
  renderActionCards(rewardLines, "lesson-card");
  const nextStage = getPlayableStages()[nextIndex];
  els.battleButton.textContent = stage.id === "ed-mini-boss"
    ? "ไปยัง Irregular Verbs"
    : nextStage && nextStage.type === "final-boss"
      ? "ต่อสู้บอสปรากฏตัว"
      : "ด่านถัดไป";
  els.battleButton.classList.remove("hidden");
  els.battleButton.onclick = () => showStageLesson(nextIndex);
  showScene("story");
}

function resetBattle() {
  clearEnemyTurnTimer();
  stopTimer("charge");
  stopParryCountdown();

  state.playerHp = 100;
  state.enemyHp = 80;
  state.enemyMaxHp = 80;
  state.grammaria = 0;
  state.sparkBonus = 0;
  state.currentQuestion = null;
  state.answerCorrect = false;
  state.selectedCharm = null;
  state.shield = 0;
  state.guardShield = 0;
  state.parryAttack = null;
  resetBattleActiveEffects();

  updateBattleStats();
  updateBattleEnemyVisual();
  updatePlayerProgress({
    hp: state.playerHp,
    progress: { currentScene: "battle" }
  });
  setActionButtonsEnabled(true);
  els.battleMessage.textContent = "Memory Shade ลอยออกมาจากเศษประโยคอดีต";
  showOnlyBattlePanel(els.actionMenu);
  setBattleTurnOwner("player");
  showScene("battle");
}

function updateBattleEnemyVisual(stage = null) {
  const enemyName = stage && stage.enemy ? stage.enemy : "Memory Shade";
  const thaiName = stage && stage.thaiEnemy ? stage.thaiEnemy : enemyName;
  const sprite = enemySpriteMap[enemyName] || "assets/memory-shade.png";

  if (els.battleEnemySprite) {
    els.battleEnemySprite.src = sprite;
    els.battleEnemySprite.alt = enemyName;
  }

  if (els.battleEnemyName) {
    els.battleEnemyName.textContent = thaiName;
  }

  if (els.battleEnemyDescription) {
    els.battleEnemyDescription.textContent = enemyDescriptions[enemyName] || "เงาความทรงจำจาก Past Fragment";
  }
}

function updateBattleStats() {
  const playerPercent = (state.playerHp / 100) * 100;
  const enemyMaxHp = state.enemyMaxHp || 80;
  const enemyPercent = (state.enemyHp / enemyMaxHp) * 100;

  els.playerHpFill.style.width = `${playerPercent}%`;
  els.enemyHpFill.style.width = `${enemyPercent}%`;
  els.playerHpText.textContent = `พลังชีวิต ${state.playerHp} / 100`;
  els.enemyHpText.textContent = `พลังชีวิต ${state.enemyHp} / ${enemyMaxHp}`;
  els.grammariaText.textContent = state.grammaria;

  if (state.shield > 0) {
    els.shieldText.textContent = "สมาธิ";
  } else if (state.guardShield > 0) {
    els.shieldText.textContent = "พิทักษ์";
  } else {
    els.shieldText.textContent = "ไม่มี";
  }
}

function startAttack() {
  setBattleTurnOwner("player");
  state.currentQuestion = sample(questions, 1)[0];
  state.answerCorrect = false;
  state.selectedCharm = null;

  els.questionText.textContent = state.currentQuestion.text;
  els.answerOptions.innerHTML = "";

  state.currentQuestion.options.forEach(option => {
    const button = document.createElement("button");
    button.className = "answer-button";
    button.textContent = option;
    button.addEventListener("click", () => chooseAnswer(option));
    els.answerOptions.appendChild(button);
  });

  els.battleMessage.textContent = "ระบุความหมายก่อนร่ายเวท";
  showOnlyBattlePanel(els.questionPanel);
}

function chooseAnswer(option) {
  state.answerCorrect = option === state.currentQuestion.correct;
  els.battleMessage.textContent = state.answerCorrect
    ? "คำนั้นเปล่งแสงแห่งความหมาย เลือกเครื่องรางหนึ่งชิ้น"
    : "ความหมายเริ่มสั่นไหว เครื่องรางอาจยังช่วยปกป้องเจ้าได้";
  showCharmChoices();
}

function showCharmChoices() {
  els.charmOptions.innerHTML = "";

  sample(charms, 3).forEach(charm => {
    const button = document.createElement("button");
    button.className = "charm-card";
    button.innerHTML = `<strong>${charm.name}</strong><span>${charm.effect}</span>`;
    button.addEventListener("click", () => chooseCharm(charm));
    els.charmOptions.appendChild(button);
  });

  showOnlyBattlePanel(els.charmPanel);
}

function chooseCharm(charm) {
  state.selectedCharm = charm;
  els.battleMessage.textContent = `เลือก ${charm.name} แล้ว หยุดชาร์จให้ถูกจังหวะ`;
  startCharge();
}

function startCharge() {
  const widerPerfect = state.selectedCharm && state.selectedCharm.id === "focusGlyph";
  const zoneWidth = widerPerfect ? 30 : 18;
  const zoneStart = (100 - zoneWidth) / 2;

  els.perfectZone.style.width = `${zoneWidth}%`;
  els.perfectZone.style.left = `${zoneStart}%`;
  showOnlyBattlePanel(els.chargePanel);
  state.charge = createTimer(els.chargeMarker, 1050);
}

function createTimer(marker, duration) {
  const timer = {
    marker,
    duration,
    direction: 1,
    progress: 0,
    lastTime: null,
    frame: null
  };

  const step = timestamp => {
    if (!timer.lastTime) {
      timer.lastTime = timestamp;
    }

    const elapsed = timestamp - timer.lastTime;
    timer.lastTime = timestamp;
    timer.progress += (elapsed / timer.duration) * 100 * timer.direction;

    if (timer.progress >= 100) {
      timer.progress = 100;
      timer.direction = -1;
    }

    if (timer.progress <= 0) {
      timer.progress = 0;
      timer.direction = 1;
    }

    marker.style.left = `calc(${timer.progress}% - 4px)`;
    timer.frame = requestAnimationFrame(step);
  };

  timer.frame = requestAnimationFrame(step);
  return timer;
}

function stopTimer(type) {
  const timer = state[type];
  if (timer && timer.frame) {
    cancelAnimationFrame(timer.frame);
  }
  state[type] = null;
}

function stopParryCountdown() {
  if (!state.parry) {
    return;
  }

  if (state.parry.tickTimeout) {
    clearTimeout(state.parry.tickTimeout);
  }

  if (state.parry.resolveTimeout) {
    clearTimeout(state.parry.resolveTimeout);
  }

  if (state.parry.gaugeFrame) {
    cancelAnimationFrame(state.parry.gaugeFrame);
  }

  state.parry = null;
  els.parryButton.disabled = false;
}

function timingResult(progress, perfectWidth) {
  const perfectStart = (100 - perfectWidth) / 2;
  const perfectEnd = perfectStart + perfectWidth;
  const greatStart = perfectStart - 12;
  const greatEnd = perfectEnd + 12;
  const goodStart = perfectStart - 24;
  const goodEnd = perfectEnd + 24;

  if (progress >= perfectStart && progress <= perfectEnd) {
    return "PERFECT";
  }

  if (progress >= greatStart && progress <= greatEnd) {
    return "GREAT";
  }

  if (progress >= goodStart && progress <= goodEnd) {
    return "GOOD";
  }

  return "MISS";
}

function thaiTimingName(result) {
  const names = {
    PERFECT: "สมบูรณ์แบบ",
    GREAT: "ยอดเยี่ยม",
    GOOD: "ดี",
    MISS: "พลาด"
  };

  return names[result] || result;
}

function stopCharge() {
  if (!state.charge) {
    return;
  }

  const progress = state.charge.progress;
  const perfectWidth = state.selectedCharm && state.selectedCharm.id === "focusGlyph" ? 30 : 18;
  const result = timingResult(progress, perfectWidth);
  stopTimer("charge");
  resolvePlayerAttack(result);
}

function resolvePlayerAttack(chargeResult) {
  const chargeModifiers = {
    PERFECT: 1.5,
    GREAT: 1.25,
    GOOD: 1,
    MISS: 0.75
  };

  let damage = 0;
  let message = "";

  if (state.answerCorrect) {
    triggerMotion(els.battlePlayer, "player-attack-motion");
    damage = 25;

    if (state.selectedCharm.id === "minorPower") {
      damage *= 1.1;
    }

    if (state.selectedCharm.id === "attackRune") {
      damage *= 1.25;
    }

    damage = Math.round(damage * chargeModifiers[chargeResult]);
    state.enemyHp = clamp(state.enemyHp - damage, 0, 80);
    triggerEnemyHitFeedback(damage);
    state.grammaria += 20;

    if (state.selectedCharm.id === "tinyHeal") {
      state.playerHp = clamp(state.playerHp + 8, 0, 100);
    }

    if (state.selectedCharm.id === "grammariaSpark") {
      state.sparkBonus += 5;
    }

    message = `ผู้พเนจรร่ายแกรมมาเรีย! ชาร์จระดับ ${thaiTimingName(chargeResult)} สร้างดาเมจ ${damage}`;
  } else {
    if (state.selectedCharm.id === "guardWord") {
      state.guardShield = 0.3;
    }

    message = `แกรมมาเรียเลือนหาย ความหมายยังไม่ชัดเจน ชาร์จระดับ ${thaiTimingName(chargeResult)} จึงโจมตีไม่ได้`;
  }

  updateBattleStats();
  syncBattleStateToPlayerData();
  endPlayerTurn(message);
}

function useItem() {
  endPlayerTurn("เจ้ายังไม่มีไอเทมต่อสู้ จังหวะลังเลเปิดช่องให้ศัตรูโจมตี");
}

function endPlayerTurn(message) {
  clearEnemyTurnTimer();
  showOnlyBattlePanel(null);
  els.battleMessage.textContent = message;

  if (state.enemyHp <= 0) {
    setTimeout(showVictory, 900);
    return;
  }

  setActionButtonsEnabled(false);
  state.enemyTurnTimer = setTimeout(() => {
    state.enemyTurnTimer = null;
    startEnemyTurn();
  }, 900);
}

function focusTurn() {
  state.shield = 0.4;
  updateBattleStats();
  endPlayerTurn("ผู้พเนจรตั้งสมาธิและทำให้กระแสแกรมมาเรียนิ่งขึ้น");
}

function startEnemyTurn(pattern = enemyAttackPatterns.normal) {
  startEnemyAttack(pattern);
}

function startEnemyAttack(pattern) {
  clearEnemyTurnTimer();
  stopParryCountdown();
  setActionButtonsEnabled(false);
  setBattleTurnOwner("enemy");
  triggerMotion(els.battleEnemy, "enemy-attack-motion");
  state.parryAttack = {
    pattern,
    hitIndex: 0,
    results: [],
    totalDamage: 0,
    totalCounterDamage: 0,
    perfectStreak: 0,
    maxPerfectStreak: 0,
    streakBonus: false,
    fullPerfectBonus: false
  };

  els.battleMessage.textContent = pattern.hits > 1
    ? `${pattern.announce}\nเตรียมปัดป้อง ${pattern.hits} hit ติดต่อกัน!`
    : pattern.announce;

  els.continueBattleButton.textContent = "เตรียมพร้อม";
  els.continueBattleButton.onclick = () => {
    els.continueBattleButton.classList.add("hidden");
    els.battleMessage.textContent = "จับจังหวะเส้นสีขาวให้เข้าโซนเป้าหมาย ส้ม/เหลือง/เขียว...";
    setTimeout(beginNextParryHit, 420);
  };
  els.continueBattleButton.classList.remove("hidden");
}

function beginNextParryHit() {
  const attack = state.parryAttack;
  if (!attack) {
    return;
  }

  if (attack.hitIndex >= attack.pattern.hits) {
    finishEnemyAttackSequence();
    return;
  }

  attack.hitIndex += 1;
  const hitNumber = attack.hitIndex;
  const pattern = attack.pattern;
  const gaugeZoneWidth = Math.max(12, pattern.gaugeZoneWidth - ((hitNumber - 1) * pattern.gaugeZoneShrinkPerHit));
  const gaugeSpeed = Math.max(720, pattern.gaugeSpeed - ((hitNumber - 1) * pattern.gaugeSpeedUpPerHit));

  state.parry = {
    active: true,
    inputLocked: false,
    hitNumber,
    totalHits: pattern.hits,
    tickTimeout: null,
    resolveTimeout: null,
    gaugeProgress: 0,
    gaugeDirection: 1,
    gaugeLastTime: null,
    gaugeFrame: null,
    gaugeSpeed,
    zoneMoves: true,
    gaugeZoneWidth,
    gaugeZoneMinWidth: Math.max(8, gaugeZoneWidth - 12),
    gaugeZoneShrinkPerSecond: 4 + hitNumber,
    gaugeZoneStart: Math.random() * (100 - gaugeZoneWidth),
    gaugeZoneDirection: Math.random() < 0.5 ? -1 : 1,
    gaugeZoneSpeed: Math.max(1100, pattern.gaugeSpeed + 650 - (hitNumber * 90))
  };

  els.enemyAttackName.textContent = pattern.name;
  els.parryHitText.textContent = `Hit ${hitNumber} / ${pattern.hits}`;
  els.parryCountdown.textContent = "TAP";
  els.parryHitResult.textContent = attack.results.length
    ? `ผลล่าสุด: ${thaiParryName(attack.results[attack.results.length - 1].result)}`
    : "";
  els.parryGaugeZone.style.width = `${gaugeZoneWidth}%`;
  els.parryGaugeZone.style.left = `${state.parry.gaugeZoneStart}%`;
  els.parryButton.disabled = false;
  showOnlyBattlePanel(els.parryPanel);
  startParryGauge();
  state.parry.resolveTimeout = setTimeout(() => {
    resolveCountdownParry("MISS");
  }, Math.max(2600, 3800 - (hitNumber * 250)));
}

function startParryGauge() {
  const step = timestamp => {
    if (!state.parry || !state.parry.active) {
      return;
    }

    if (!state.parry.gaugeLastTime) {
      state.parry.gaugeLastTime = timestamp;
    }

    const elapsed = timestamp - state.parry.gaugeLastTime;
    state.parry.gaugeLastTime = timestamp;
    state.parry.gaugeProgress += (elapsed / state.parry.gaugeSpeed) * 100 * state.parry.gaugeDirection;

    if (state.parry.zoneMoves) {
      const shrinkAmount = (elapsed / 1000) * state.parry.gaugeZoneShrinkPerSecond;
      state.parry.gaugeZoneWidth = Math.max(
        state.parry.gaugeZoneMinWidth,
        state.parry.gaugeZoneWidth - shrinkAmount
      );

      state.parry.gaugeZoneStart += (elapsed / state.parry.gaugeZoneSpeed) * 100 * state.parry.gaugeZoneDirection;

      const maxZoneStart = 100 - state.parry.gaugeZoneWidth;
      if (state.parry.gaugeZoneStart >= maxZoneStart) {
        state.parry.gaugeZoneStart = maxZoneStart;
        state.parry.gaugeZoneDirection = -1;
      }

      if (state.parry.gaugeZoneStart <= 0) {
        state.parry.gaugeZoneStart = 0;
        state.parry.gaugeZoneDirection = 1;
      }

      els.parryGaugeZone.style.width = `${state.parry.gaugeZoneWidth}%`;
      els.parryGaugeZone.style.left = `${state.parry.gaugeZoneStart}%`;
    }

    if (state.parry.gaugeProgress >= 100) {
      state.parry.gaugeProgress = 100;
      state.parry.gaugeDirection = -1;
    }

    if (state.parry.gaugeProgress <= 0) {
      state.parry.gaugeProgress = 0;
      state.parry.gaugeDirection = 1;
    }

    els.parryGaugeMarker.style.left = `calc(${state.parry.gaugeProgress}% - 5px)`;
    state.parry.gaugeFrame = requestAnimationFrame(step);
  };

  els.parryGaugeMarker.style.left = "0";
  state.parry.gaugeFrame = requestAnimationFrame(step);
}

function showParryCount(count) {
  els.parryCountdown.textContent = count;
  els.parryCountdown.classList.remove("pulse");
  void els.parryCountdown.offsetWidth;
  els.parryCountdown.classList.add("pulse");
}

function scheduleParryCount(count) {
  if (!state.parry || !state.parry.active) {
    return;
  }

  if (count > 1) {
    state.parry.tickTimeout = setTimeout(() => {
      showParryCount(count - 1);
      scheduleParryCount(count - 1);
    }, state.parry.stepDuration);
    return;
  }

  state.parry.resolveTimeout = setTimeout(() => {
    resolveCountdownParry("MISS");
  }, state.parry.stepDuration + 650);
}

function stopParry(event = null) {
  if (event) {
    event.preventDefault();
  }

  if (!state.parry || !state.parry.active || state.parry.inputLocked) {
    return;
  }

  state.parry.inputLocked = true;
  const frozenProgress = state.parry.gaugeProgress;
  els.parryGaugeMarker.style.left = `calc(${frozenProgress}% - 5px)`;
  const frozenResult = parryGaugeResult(frozenProgress, HIT_TOLERANCE);
  els.parryButton.disabled = true;

  if (state.actBattle && state.actBattle.awaitingParry) {
    freezeParryFeedback(frozenResult, () => stopActParry(frozenResult));
    return;
  }

  const result = state.parry.targetTime
    ? countdownParryResult(performance.now(), frozenResult)
    : frozenResult;
  freezeParryFeedback(result, () => resolveCountdownParry(result));
}

function freezeParryFeedback(result, onDone) {
  if (!state.parry) {
    onDone();
    return;
  }

  if (state.parry.tickTimeout) {
    clearTimeout(state.parry.tickTimeout);
    state.parry.tickTimeout = null;
  }

  if (state.parry.resolveTimeout) {
    clearTimeout(state.parry.resolveTimeout);
    state.parry.resolveTimeout = null;
  }

  if (state.parry.gaugeFrame) {
    cancelAnimationFrame(state.parry.gaugeFrame);
    state.parry.gaugeFrame = null;
  }

  const gauge = document.getElementById("parryGauge");
  els.parryGaugeZone.classList.remove("flash-perfect", "flash-good", "flash-weak");
  if (gauge) {
    gauge.classList.remove("flash-miss");
  }

  if (result === "PERFECT") {
    els.parryGaugeZone.classList.add("flash-perfect");
  } else if (result === "GOOD") {
    els.parryGaugeZone.classList.add("flash-good");
  } else if (result === "WEAK") {
    els.parryGaugeZone.classList.add("flash-weak");
  } else if (gauge) {
    gauge.classList.add("flash-miss");
  }

  els.parryHitResult.textContent = `${thaiParryName(result)}!`;
  setTimeout(() => {
    els.parryGaugeZone.classList.remove("flash-perfect", "flash-good", "flash-weak");
    if (gauge) {
      gauge.classList.remove("flash-miss");
    }
    onDone();
  }, 680);
}

function countdownParryResult(clickTime, frozenGaugeResult = null) {
  if (!state.parry.targetTime) {
    return frozenGaugeResult || parryGaugeResult(state.parry.gaugeProgress, HIT_TOLERANCE);
  }

  const diff = Math.abs(clickTime - state.parry.targetTime);
  const tooEarly = clickTime < state.parry.targetTime - 700;
  const tooLate = clickTime > state.parry.targetTime + 1050;
  const gaugeResult = frozenGaugeResult || parryGaugeResult(state.parry.gaugeProgress, HIT_TOLERANCE);

  if (tooEarly || tooLate) {
    return "MISS";
  }

  if (diff <= 250) {
    return gaugeResult === "MISS" ? "GOOD" : gaugeResult;
  }

  if (diff <= 550) {
    return gaugeResult === "MISS" ? "WEAK" : gaugeResult === "PERFECT" ? "GOOD" : gaugeResult;
  }

  return gaugeResult === "MISS" ? "WEAK" : gaugeResult;
}

function parryGaugeResult(progress, tolerance = 0) {
  const zoneStart = state.parry.gaugeZoneStart;
  const width = state.parry.gaugeZoneWidth;
  const weakStart = zoneStart - tolerance;
  const weakEnd = zoneStart + width + tolerance;
  const goodStart = zoneStart + (width * 0.24) - tolerance;
  const goodEnd = zoneStart + (width * 0.76) + tolerance;
  const perfectStart = zoneStart + (width * 0.38) - tolerance;
  const perfectEnd = zoneStart + (width * 0.62) + tolerance;

  if (progress >= perfectStart && progress <= perfectEnd) {
    return "PERFECT";
  }

  if (progress >= goodStart && progress <= goodEnd) {
    return "GOOD";
  }

  if (progress >= weakStart && progress <= weakEnd) {
    return "WEAK";
  }

  return "MISS";
}

function resolveCountdownParry(result) {
  if (!state.parry || !state.parry.active) {
    return;
  }

  const hitNumber = state.parry.hitNumber;
  state.parry.active = false;
  els.parryButton.disabled = true;
  stopParryCountdown();
  resolveEnemyHit(result, hitNumber);
}

function resolveEnemyHit(parryResult, hitNumber) {
  const attack = state.parryAttack;
  if (!attack) {
    return;
  }

  const hit = calculateParryHit(parryResult, attack.pattern.baseDamage);
  attack.results.push({ hit: hitNumber, result: parryResult, damage: hit.damage, counterDamage: hit.counterDamage });
  attack.totalDamage += hit.damage;
  attack.totalCounterDamage += hit.counterDamage;

  if (parryResult === "PERFECT") {
    attack.perfectStreak += 1;
    attack.maxPerfectStreak = Math.max(attack.maxPerfectStreak, attack.perfectStreak);
  } else {
    attack.perfectStreak = 0;
  }

  els.parryHitResult.textContent = `${thaiParryName(parryResult)} - ดาเมจที่รับ ${hit.damage}`;

  if (attack.hitIndex >= attack.pattern.hits) {
    setTimeout(finishEnemyAttackSequence, 700);
    return;
  }

  setTimeout(beginNextParryHit, 700);
}

function calculateParryHit(parryResult, baseDamage) {
  if (parryResult === "PERFECT") {
    return { damage: 0, counterDamage: 5 };
  }

  if (parryResult === "GOOD") {
    return { damage: Math.round(baseDamage * 0.4), counterDamage: 0 };
  }

  if (parryResult === "WEAK") {
    return { damage: Math.round(baseDamage * 0.7), counterDamage: 0 };
  }

  if (parryResult === "MISS" && useBattleEffect("secondChance")) {
    return { damage: Math.round(baseDamage * 0.5), counterDamage: 0 };
  }

  return { damage: baseDamage, counterDamage: 0 };
}

function finishEnemyAttackSequence() {
  const attack = state.parryAttack;
  if (!attack) {
    return;
  }

  let totalDamage = attack.totalDamage;
  let totalCounterDamage = attack.totalCounterDamage;
  const counts = countParryResults(attack.results);
  const summaryLines = [];

  if (attack.maxPerfectStreak >= 3) {
    attack.streakBonus = true;
    totalCounterDamage += 10;
    summaryLines.push("Perfect Streak! Grammaria Counter is charging!");
  }

  if (attack.pattern.hits > 1 && counts.PERFECT === attack.pattern.hits) {
    attack.fullPerfectBonus = true;
    totalCounterDamage += 20;
    summaryLines.push("GRAMMARIA COUNTER BURST!");
  }

  if (state.shield > 0) {
    totalDamage *= 1 - state.shield;
    state.shield = 0;
  }

  if (state.guardShield > 0) {
    totalDamage *= 1 - state.guardShield;
    state.guardShield = 0;
  }

  totalDamage = Math.round(totalDamage);
  state.playerHp = clamp(state.playerHp - totalDamage, 0, 100);
  state.enemyHp = clamp(state.enemyHp - totalCounterDamage, 0, 80);
  triggerEnemyHitFeedback(totalCounterDamage);

  updateBattleStats();
  syncBattleStateToPlayerData();
  showOnlyBattlePanel(null);
  els.battleMessage.textContent = buildParrySummary(attack, counts, totalDamage, totalCounterDamage, summaryLines);
  state.parryAttack = null;
  setBattleTurnOwner("player");

  if (state.enemyHp <= 0) {
    setTimeout(showVictory, 900);
    return;
  }

  if (state.playerHp <= 0) {
    state.playerHp = 35;
    updateBattleStats();
    els.battleMessage.textContent += "\nอาจารย์เวเรียนประคองบทเรียนไว้ ผู้พเนจรลุกขึ้นพร้อมพลังชีวิต 35";
  }

  els.continueBattleButton.textContent = "ตาผู้เล่น";
  els.continueBattleButton.onclick = () => {
    els.battleMessage.textContent = "เลือกการกระทำของเจ้า";
    setActionButtonsEnabled(true);
    setBattleTurnOwner("player");
    showOnlyBattlePanel(els.actionMenu);
  };
  els.continueBattleButton.classList.remove("hidden");
}

function countParryResults(results) {
  return results.reduce((counts, item) => {
    counts[item.result] += 1;
    return counts;
  }, { PERFECT: 0, GOOD: 0, WEAK: 0, MISS: 0 });
}

function buildParrySummary(attack, counts, totalDamage, totalCounterDamage, bonusLines) {
  const title = attack.pattern.hits > 1 ? "สรุปผล Multi-Hit Parry" : thaiParryName(attack.results[0].result);
  const lines = [
    title,
    `ท่าโจมตี: ${attack.pattern.name}`,
    `Perfect: ${counts.PERFECT}`,
    `Good: ${counts.GOOD}`,
    `Weak: ${counts.WEAK}`,
    `Miss: ${counts.MISS}`,
    `Total Damage Taken: ${totalDamage}`
  ];

  if (totalCounterDamage > 0) {
    lines.push(`Counter Damage: ${totalCounterDamage}`);
  }

  return lines.concat(bonusLines).join("\n");
}

function thaiParryName(result) {
  const names = {
    PERFECT: "Perfect Parry",
    GOOD: "Good Parry",
    WEAK: "Weak Parry",
    MISS: "Miss"
  };

  return names[result] || result;
}

function showActEnding() {
  runSceneTransition("Past Fragment กำลังฟื้นคืน...", completeActVictoryScene);
}

function completeActVictoryScene() {
  clearEnemyTurnTimer();
  stopTimer("charge");
  stopParryCountdown();
  const progress = ensureActProgress();
  const rewards = progress ? progress.rewards.join(", ") : "Time Spark, Tense Spark, Ed Fragment, Irregular Fragment, Past Fragment";

  els.victoryTitle.textContent = "ได้รับ Past Fragment";
  els.victoryEnemy.textContent = "The Memory Breaker";
  els.victoryStory.textContent = PAST_FRAGMENT_ACT.endingLines.join(" ");
  els.victoryGrammaria.textContent = playerData ? playerData.grammaria || 0 : state.grammaria;
  els.victoryExtra.textContent = rewards;
  els.victoryBadge.textContent = PAST_FRAGMENT_ACT.badge;
  els.victoryFragmentText.innerHTML = `สรุปบทเรียนโดยมาสเตอร์เวรีออน<br>${PAST_FRAGMENT_ACT.summary.map(item => `• ${item}`).join("<br>")}`;

  if (playerData) {
    playerData.progress.currentScene = "pastFragmentVictory";
    savePlayerData();
  }

  showScene("victory");
}

function showVictory() {
  runSceneTransition("Past Fragment กำลังฟื้นคืน...", completeVictoryScene);
}

function completeVictoryScene() {
  clearEnemyTurnTimer();
  stopTimer("charge");
  stopParryCountdown();
  els.victoryGrammaria.textContent = state.grammaria + state.sparkBonus;
  els.victoryExtra.textContent = state.sparkBonus;

  if (playerData) {
    playerData.grammaria = state.grammaria + state.sparkBonus;
    playerData.hp = state.playerHp;
    playerData.progress.currentScene = "victory";
    addUniqueProgressItem("unlockedFragments", "Past Spark ชิ้นที่ 1");
    addUniqueProgressItem("defeatedEnemies", "Memory Shade");
    savePlayerData();
  }

  showScene("victory");
}

function handleLessonBack() {
  if (isGameModalOpen()) {
    closeGameModal();
    return;
  }

  if (state.isLessonSummaryOpen && !els.nounActivityVisual.classList.contains("hidden")) {
    closeExplanationPanel();
    return;
  }

  if (scenes.battle.classList.contains("active")) {
    confirmExitBattle();
    return;
  }

  if (state.lessonStoryMode) {
    stopTypewriter();
    if (state.lessonStoryStepIndex > 0) {
      state.lessonStoryStepIndex -= 1;
      renderLessonStoryStep();
      return;
    }

    showActInfoScreen();
    return;
  }

  if (state.lessonStepIndex > 0) {
    state.lessonStepIndex -= 1;
    renderLessonStep();
    return;
  }

  showActInfoScreen();
}

function confirmExitBattle() {
  openGameModal({
    title: "ออกจากการต่อสู้นี้หรือไม่?",
    body: "ต้องการออกจากการต่อสู้และกลับไปหน้าบทเรียนหรือไม่?",
    actions: [
      {
        label: "อยู่ต่อ",
        onClick: closeGameModal
      },
      {
        label: "ออกจากการต่อสู้",
        primary: true,
        onClick: () => {
          closeGameModal();
          clearEnemyTurnTimer();
          stopTimer("charge");
          stopParryCountdown();
          state.actBattle = null;
          state.parryAttack = null;
          runSceneTransition("กลับสู่แผนที่บทเรียน...", () => {
            showScene("story");
            showActInfoScreen();
          });
        }
      }
    ]
  });
}

function openSkipBattleModal() {
  openGameModal({
    title: "ข้ามไปต่อสู้",
    body: "ต้องการข้ามบทเรียนไปสู่การต่อสู้ใช่หรือไม่?",
    actions: [
      {
        label: "ยกเลิก",
        onClick: closeGameModal
      },
      {
        label: "ข้ามไปต่อสู้",
        primary: true,
        onClick: renderBattleSelect
      }
    ]
  });
}

function renderBattleSelect() {
  const wrapper = document.createElement("div");
  wrapper.className = "skip-enemy-grid";

  skipBattleEnemies.forEach(enemy => {
    const card = document.createElement("article");
    card.className = "skip-enemy-card";
    card.innerHTML = `
      <img src="${enemySpriteMap[enemy.name] || "assets/memory-shade.png"}" alt="${enemy.name}">
      <div>
        <h4>${enemy.thaiName}</h4>
        <p>${enemy.description}</p>
        <p>${enemy.lesson}</p>
      </div>
    `;

    const button = document.createElement("button");
    button.type = "button";
    button.className = "primary-button";
    button.textContent = "เริ่มต่อสู้";
    button.addEventListener("click", () => startBattleByEnemy(enemy.id));
    card.appendChild(button);
    wrapper.appendChild(card);
  });

  openGameModal({
    title: "เลือกศัตรู",
    body: "เลือกการต่อสู้ที่ต้องการฝึก",
    content: wrapper,
    actions: [
      {
        label: "ย้อนกลับ",
        onClick: openSkipBattleModal
      }
    ]
  });
}

function startBattleByEnemy(enemyId) {
  const enemy = skipBattleEnemies.find(item => item.id === enemyId);
  if (!enemy) {
    return;
  }

  const stageIndex = getPlayableStages().findIndex(stage => stage.id === enemy.stageId);
  if (stageIndex < 0) {
    return;
  }

  closeGameModal();
  state.currentLessonStage = getPlayableStages()[stageIndex];
  runSceneTransition(`${enemy.name} ปรากฏตัว!`, () => startActBattle(stageIndex));
}

els.googleMockButton.addEventListener("click", loginWithGoogleMock);
els.guestLoginButton.addEventListener("click", loginAsGuest);
els.enterLinguaButton.addEventListener("click", loginWithGoogleMock);
els.createCharacterButton.addEventListener("click", createCharacterFromForm);
els.confirmNameButton.addEventListener("click", confirmStoryName);
els.storyNameInput.addEventListener("keydown", event => {
  if (event.key === "Enter") {
    confirmStoryName();
  }
});
els.startButton.addEventListener("click", startStory);
els.nextDialogueButton.addEventListener("click", advanceDialogue);
els.explanationCloseButton.addEventListener("click", closeExplanationPanel);
els.lessonBackButton.addEventListener("click", handleLessonBack);
els.battleExitButton.addEventListener("click", confirmExitBattle);
els.lessonDictionaryButton.addEventListener("click", () => {
  els.activityFeedback.textContent = "พจนานุกรมแกรมมาเรียจะเปิดใช้ใน Prototype ถัดไป";
  els.nounActivityVisual.classList.remove("hidden");
});
els.lessonExplainButton.addEventListener("click", () => {
  showLessonSummaryModal(state.currentLessonStage || getPlayableStages()[state.actStageIndex]);
});
els.lessonReviewButton.addEventListener("click", () => {
  const stage = getPlayableStages()[state.actStageIndex];
  if (stage) {
    state.currentLessonStage = stage;
    showLessonSummaryModal(stage);
  }
});
els.skipBattleButton.addEventListener("click", openSkipBattleModal);
els.attackButton.addEventListener("click", startAttack);
els.itemButton.addEventListener("click", useItem);
els.focusButton.addEventListener("click", focusTurn);
els.stopChargeButton.addEventListener("click", stopCharge);
els.parryButton.addEventListener("pointerdown", stopParry);
els.parryButton.addEventListener("keydown", event => {
  if (event.key === "Enter" || event.key === " ") {
    stopParry(event);
  }
});
els.gameModalClose.addEventListener("click", closeGameModal);
els.returnTitleButton.addEventListener("click", () => showScene("login"));
bindAvatarPreviewInputs();
